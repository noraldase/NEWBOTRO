/*!
 * Webflow: Front-end site library
 * @license MIT
 * Inline scripts may access the api using an async handler:
 *   var Webflow = Webflow || [];
 *   Webflow.push(readyFunction);
 */

(() => {
    var u = (e, t) => () => (t || e((t = {
        exports: {}
    }).exports, t), t.exports);
    var bi = u(() => {
        "use strict";
        window.tram = function(e) {
            function t(l, y) {
                var _ = new ye.Bare;
                return _.init(l, y)
            }

            function n(l) {
                return l.replace(/[A-Z]/g, function(y) {
                    return "-" + y.toLowerCase()
                })
            }

            function i(l) {
                var y = parseInt(l.slice(1), 16),
                    _ = y >> 16 & 255,
                    S = y >> 8 & 255,
                    w = 255 & y;
                return [_, S, w]
            }

            function a(l, y, _) {
                return "#" + (1 << 24 | l << 16 | y << 8 | _).toString(16).slice(1)
            }

            function r() {}

            function o(l, y) {
                d("Type warning: Expected: [" + l + "] Got: [" + typeof y + "] " + y)
            }

            function s(l, y, _) {
                d("Units do not match [" + l + "]: " + y + ", " + _)
            }

            function c(l, y, _) {
                if (y !== void 0 && (_ = y), l === void 0) return _;
                var S = _;
                return Je.test(l) || !ke.test(l) ? S = parseInt(l, 10) : ke.test(l) && (S = 1e3 * parseFloat(l)), 0 > S && (S = 0), S === S ? S : _
            }

            function d(l) {
                H.debug && window && window.console.warn(l)
            }

            function I(l) {
                for (var y = -1, _ = l ? l.length : 0, S = []; ++y < _;) {
                    var w = l[y];
                    w && S.push(w)
                }
                return S
            }
            var E = function(l, y, _) {
                    function S(te) {
                        return typeof te == "object"
                    }

                    function w(te) {
                        return typeof te == "function"
                    }

                    function R() {}

                    function j(te, K) {
                        function D() {
                            var he = new ie;
                            return w(he.init) && he.init.apply(he, arguments), he
                        }

                        function ie() {}
                        K === _ && (K = te, te = Object), D.Bare = ie;
                        var ae, Ee = R[l] = te[l],
                            we = ie[l] = D[l] = new R;
                        return we.constructor = D, D.mixin = function(he) {
                            return ie[l] = D[l] = j(D, he)[l], D
                        }, D.open = function(he) {
                            if (ae = {}, w(he) ? ae = he.call(D, we, Ee, D, te) : S(he) && (ae = he), S(ae))
                                for (var Bt in ae) y.call(ae, Bt) && (we[Bt] = ae[Bt]);
                            return w(we.init) || (we.init = te), D
                        }, D.open(K)
                    }
                    return j
                }("prototype", {}.hasOwnProperty),
                p = {
                    ease: ["ease", function(l, y, _, S) {
                        var w = (l /= S) * l,
                            R = w * l;
                        return y + _ * (-2.75 * R * w + 11 * w * w + -15.5 * R + 8 * w + .25 * l)
                    }],
                    "ease-in": ["ease-in", function(l, y, _, S) {
                        var w = (l /= S) * l,
                            R = w * l;
                        return y + _ * (-1 * R * w + 3 * w * w + -3 * R + 2 * w)
                    }],
                    "ease-out": ["ease-out", function(l, y, _, S) {
                        var w = (l /= S) * l,
                            R = w * l;
                        return y + _ * (.3 * R * w + -1.6 * w * w + 2.2 * R + -1.8 * w + 1.9 * l)
                    }],
                    "ease-in-out": ["ease-in-out", function(l, y, _, S) {
                        var w = (l /= S) * l,
                            R = w * l;
                        return y + _ * (2 * R * w + -5 * w * w + 2 * R + 2 * w)
                    }],
                    linear: ["linear", function(l, y, _, S) {
                        return _ * l / S + y
                    }],
                    "ease-in-quad": ["cubic-bezier(0.550, 0.085, 0.680, 0.530)", function(l, y, _, S) {
                        return _ * (l /= S) * l + y
                    }],
                    "ease-out-quad": ["cubic-bezier(0.250, 0.460, 0.450, 0.940)", function(l, y, _, S) {
                        return -_ * (l /= S) * (l - 2) + y
                    }],
                    "ease-in-out-quad": ["cubic-bezier(0.455, 0.030, 0.515, 0.955)", function(l, y, _, S) {
                        return (l /= S / 2) < 1 ? _ / 2 * l * l + y : -_ / 2 * (--l * (l - 2) - 1) + y
                    }],
                    "ease-in-cubic": ["cubic-bezier(0.550, 0.055, 0.675, 0.190)", function(l, y, _, S) {
                        return _ * (l /= S) * l * l + y
                    }],
                    "ease-out-cubic": ["cubic-bezier(0.215, 0.610, 0.355, 1)", function(l, y, _, S) {
                        return _ * ((l = l / S - 1) * l * l + 1) + y
                    }],
                    "ease-in-out-cubic": ["cubic-bezier(0.645, 0.045, 0.355, 1)", function(l, y, _, S) {
                        return (l /= S / 2) < 1 ? _ / 2 * l * l * l + y : _ / 2 * ((l -= 2) * l * l + 2) + y
                    }],
                    "ease-in-quart": ["cubic-bezier(0.895, 0.030, 0.685, 0.220)", function(l, y, _, S) {
                        return _ * (l /= S) * l * l * l + y
                    }],
                    "ease-out-quart": ["cubic-bezier(0.165, 0.840, 0.440, 1)", function(l, y, _, S) {
                        return -_ * ((l = l / S - 1) * l * l * l - 1) + y
                    }],
                    "ease-in-out-quart": ["cubic-bezier(0.770, 0, 0.175, 1)", function(l, y, _, S) {
                        return (l /= S / 2) < 1 ? _ / 2 * l * l * l * l + y : -_ / 2 * ((l -= 2) * l * l * l - 2) + y
                    }],
                    "ease-in-quint": ["cubic-bezier(0.755, 0.050, 0.855, 0.060)", function(l, y, _, S) {
                        return _ * (l /= S) * l * l * l * l + y
                    }],
                    "ease-out-quint": ["cubic-bezier(0.230, 1, 0.320, 1)", function(l, y, _, S) {
                        return _ * ((l = l / S - 1) * l * l * l * l + 1) + y
                    }],
                    "ease-in-out-quint": ["cubic-bezier(0.860, 0, 0.070, 1)", function(l, y, _, S) {
                        return (l /= S / 2) < 1 ? _ / 2 * l * l * l * l * l + y : _ / 2 * ((l -= 2) * l * l * l * l + 2) + y
                    }],
                    "ease-in-sine": ["cubic-bezier(0.470, 0, 0.745, 0.715)", function(l, y, _, S) {
                        return -_ * Math.cos(l / S * (Math.PI / 2)) + _ + y
                    }],
                    "ease-out-sine": ["cubic-bezier(0.390, 0.575, 0.565, 1)", function(l, y, _, S) {
                        return _ * Math.sin(l / S * (Math.PI / 2)) + y
                    }],
                    "ease-in-out-sine": ["cubic-bezier(0.445, 0.050, 0.550, 0.950)", function(l, y, _, S) {
                        return -_ / 2 * (Math.cos(Math.PI * l / S) - 1) + y
                    }],
                    "ease-in-expo": ["cubic-bezier(0.950, 0.050, 0.795, 0.035)", function(l, y, _, S) {
                        return l === 0 ? y : _ * Math.pow(2, 10 * (l / S - 1)) + y
                    }],
                    "ease-out-expo": ["cubic-bezier(0.190, 1, 0.220, 1)", function(l, y, _, S) {
                        return l === S ? y + _ : _ * (-Math.pow(2, -10 * l / S) + 1) + y
                    }],
                    "ease-in-out-expo": ["cubic-bezier(1, 0, 0, 1)", function(l, y, _, S) {
                        return l === 0 ? y : l === S ? y + _ : (l /= S / 2) < 1 ? _ / 2 * Math.pow(2, 10 * (l - 1)) + y : _ / 2 * (-Math.pow(2, -10 * --l) + 2) + y
                    }],
                    "ease-in-circ": ["cubic-bezier(0.600, 0.040, 0.980, 0.335)", function(l, y, _, S) {
                        return -_ * (Math.sqrt(1 - (l /= S) * l) - 1) + y
                    }],
                    "ease-out-circ": ["cubic-bezier(0.075, 0.820, 0.165, 1)", function(l, y, _, S) {
                        return _ * Math.sqrt(1 - (l = l / S - 1) * l) + y
                    }],
                    "ease-in-out-circ": ["cubic-bezier(0.785, 0.135, 0.150, 0.860)", function(l, y, _, S) {
                        return (l /= S / 2) < 1 ? -_ / 2 * (Math.sqrt(1 - l * l) - 1) + y : _ / 2 * (Math.sqrt(1 - (l -= 2) * l) + 1) + y
                    }],
                    "ease-in-back": ["cubic-bezier(0.600, -0.280, 0.735, 0.045)", function(l, y, _, S, w) {
                        return w === void 0 && (w = 1.70158), _ * (l /= S) * l * ((w + 1) * l - w) + y
                    }],
                    "ease-out-back": ["cubic-bezier(0.175, 0.885, 0.320, 1.275)", function(l, y, _, S, w) {
                        return w === void 0 && (w = 1.70158), _ * ((l = l / S - 1) * l * ((w + 1) * l + w) + 1) + y
                    }],
                    "ease-in-out-back": ["cubic-bezier(0.680, -0.550, 0.265, 1.550)", function(l, y, _, S, w) {
                        return w === void 0 && (w = 1.70158), (l /= S / 2) < 1 ? _ / 2 * l * l * (((w *= 1.525) + 1) * l - w) + y : _ / 2 * ((l -= 2) * l * (((w *= 1.525) + 1) * l + w) + 2) + y
                    }]
                },
                g = {
                    "ease-in-back": "cubic-bezier(0.600, 0, 0.735, 0.045)",
                    "ease-out-back": "cubic-bezier(0.175, 0.885, 0.320, 1)",
                    "ease-in-out-back": "cubic-bezier(0.680, 0, 0.265, 1)"
                },
                v = document,
                m = window,
                h = "bkwld-tram",
                T = /[\-\.0-9]/g,
                A = /[A-Z]/,
                b = "number",
                N = /^(rgb|#)/,
                P = /(em|cm|mm|in|pt|pc|px)$/,
                C = /(em|cm|mm|in|pt|pc|px|%)$/,
                G = /(deg|rad|turn)$/,
                X = "unitless",
                B = /(all|none) 0s ease 0s/,
                z = /^(width|height)$/,
                J = " ",
                x = v.createElement("a"),
                O = ["Webkit", "Moz", "O", "ms"],
                M = ["-webkit-", "-moz-", "-o-", "-ms-"],
                Y = function(l) {
                    if (l in x.style) return {
                        dom: l,
                        css: l
                    };
                    var y, _, S = "",
                        w = l.split("-");
                    for (y = 0; y < w.length; y++) S += w[y].charAt(0).toUpperCase() + w[y].slice(1);
                    for (y = 0; y < O.length; y++)
                        if (_ = O[y] + S, _ in x.style) return {
                            dom: _,
                            css: M[y] + l
                        }
                },
                q = t.support = {
                    bind: Function.prototype.bind,
                    transform: Y("transform"),
                    transition: Y("transition"),
                    backface: Y("backface-visibility"),
                    timing: Y("transition-timing-function")
                };
            if (q.transition) {
                var ee = q.timing.dom;
                if (x.style[ee] = p["ease-in-back"][0], !x.style[ee])
                    for (var Z in g) p[Z][0] = g[Z]
            }
            var se = t.frame = function() {
                    var l = m.requestAnimationFrame || m.webkitRequestAnimationFrame || m.mozRequestAnimationFrame || m.oRequestAnimationFrame || m.msRequestAnimationFrame;
                    return l && q.bind ? l.bind(m) : function(y) {
                        m.setTimeout(y, 16)
                    }
                }(),
                ve = t.now = function() {
                    var l = m.performance,
                        y = l && (l.now || l.webkitNow || l.msNow || l.mozNow);
                    return y && q.bind ? y.bind(l) : Date.now || function() {
                        return +new Date
                    }
                }(),
                Ce = E(function(l) {
                    function y($, ce) {
                        var pe = I(("" + $).split(J)),
                            ue = pe[0];
                        ce = ce || {};
                        var be = V[ue];
                        if (!be) return d("Unsupported property: " + ue);
                        if (!ce.weak || !this.props[ue]) {
                            var Fe = be[0],
                                Ae = this.props[ue];
                            return Ae || (Ae = this.props[ue] = new Fe.Bare), Ae.init(this.$el, pe, be, ce), Ae
                        }
                    }

                    function _($, ce, pe) {
                        if ($) {
                            var ue = typeof $;
                            if (ce || (this.timer && this.timer.destroy(), this.queue = [], this.active = !1), ue == "number" && ce) return this.timer = new re({
                                duration: $,
                                context: this,
                                complete: R
                            }), void(this.active = !0);
                            if (ue == "string" && ce) {
                                switch ($) {
                                    case "hide":
                                        D.call(this);
                                        break;
                                    case "stop":
                                        j.call(this);
                                        break;
                                    case "redraw":
                                        ie.call(this);
                                        break;
                                    default:
                                        y.call(this, $, pe && pe[1])
                                }
                                return R.call(this)
                            }
                            if (ue == "function") return void $.call(this, this);
                            if (ue == "object") {
                                var be = 0;
                                we.call(this, $, function(Te, oE) {
                                    Te.span > be && (be = Te.span), Te.stop(), Te.animate(oE)
                                }, function(Te) {
                                    "wait" in Te && (be = c(Te.wait, 0))
                                }), Ee.call(this), be > 0 && (this.timer = new re({
                                    duration: be,
                                    context: this
                                }), this.active = !0, ce && (this.timer.complete = R));
                                var Fe = this,
                                    Ae = !1,
                                    En = {};
                                se(function() {
                                    we.call(Fe, $, function(Te) {
                                        Te.active && (Ae = !0, En[Te.name] = Te.nextStyle)
                                    }), Ae && Fe.$el.css(En)
                                })
                            }
                        }
                    }

                    function S($) {
                        $ = c($, 0), this.active ? this.queue.push({
                            options: $
                        }) : (this.timer = new re({
                            duration: $,
                            context: this,
                            complete: R
                        }), this.active = !0)
                    }

                    function w($) {
                        return this.active ? (this.queue.push({
                            options: $,
                            args: arguments
                        }), void(this.timer.complete = R)) : d("No active transition timer. Use start() or wait() before then().")
                    }

                    function R() {
                        if (this.timer && this.timer.destroy(), this.active = !1, this.queue.length) {
                            var $ = this.queue.shift();
                            _.call(this, $.options, !0, $.args)
                        }
                    }

                    function j($) {
                        this.timer && this.timer.destroy(), this.queue = [], this.active = !1;
                        var ce;
                        typeof $ == "string" ? (ce = {}, ce[$] = 1) : ce = typeof $ == "object" && $ != null ? $ : this.props, we.call(this, ce, he), Ee.call(this)
                    }

                    function te($) {
                        j.call(this, $), we.call(this, $, Bt, rE)
                    }

                    function K($) {
                        typeof $ != "string" && ($ = "block"), this.el.style.display = $
                    }

                    function D() {
                        j.call(this), this.el.style.display = "none"
                    }

                    function ie() {
                        this.el.offsetHeight
                    }

                    function ae() {
                        j.call(this), e.removeData(this.el, h), this.$el = this.el = null
                    }

                    function Ee() {
                        var $, ce, pe = [];
                        this.upstream && pe.push(this.upstream);
                        for ($ in this.props) ce = this.props[$], ce.active && pe.push(ce.string);
                        pe = pe.join(","), this.style !== pe && (this.style = pe, this.el.style[q.transition.dom] = pe)
                    }

                    function we($, ce, pe) {
                        var ue, be, Fe, Ae, En = ce !== he,
                            Te = {};
                        for (ue in $) Fe = $[ue], ue in de ? (Te.transform || (Te.transform = {}), Te.transform[ue] = Fe) : (A.test(ue) && (ue = n(ue)), ue in V ? Te[ue] = Fe : (Ae || (Ae = {}), Ae[ue] = Fe));
                        for (ue in Te) {
                            if (Fe = Te[ue], be = this.props[ue], !be) {
                                if (!En) continue;
                                be = y.call(this, ue)
                            }
                            ce.call(this, be, Fe)
                        }
                        pe && Ae && pe.call(this, Ae)
                    }

                    function he($) {
                        $.stop()
                    }

                    function Bt($, ce) {
                        $.set(ce)
                    }

                    function rE($) {
                        this.$el.css($)
                    }

                    function xe($, ce) {
                        l[$] = function() {
                            return this.children ? aE.call(this, ce, arguments) : (this.el && ce.apply(this, arguments), this)
                        }
                    }

                    function aE($, ce) {
                        var pe, ue = this.children.length;
                        for (pe = 0; ue > pe; pe++) $.apply(this.children[pe], ce);
                        return this
                    }
                    l.init = function($) {
                        if (this.$el = e($), this.el = this.$el[0], this.props = {}, this.queue = [], this.style = "", this.active = !1, H.keepInherited && !H.fallback) {
                            var ce = F(this.el, "transition");
                            ce && !B.test(ce) && (this.upstream = ce)
                        }
                        q.backface && H.hideBackface && f(this.el, q.backface.css, "hidden")
                    }, xe("add", y), xe("start", _), xe("wait", S), xe("then", w), xe("next", R), xe("stop", j), xe("set", te), xe("show", K), xe("hide", D), xe("redraw", ie), xe("destroy", ae)
                }),
                ye = E(Ce, function(l) {
                    function y(_, S) {
                        var w = e.data(_, h) || e.data(_, h, new Ce.Bare);
                        return w.el || w.init(_), S ? w.start(S) : w
                    }
                    l.init = function(_, S) {
                        var w = e(_);
                        if (!w.length) return this;
                        if (w.length === 1) return y(w[0], S);
                        var R = [];
                        return w.each(function(j, te) {
                            R.push(y(te, S))
                        }), this.children = R, this
                    }
                }),
                L = E(function(l) {
                    function y() {
                        var R = this.get();
                        this.update("auto");
                        var j = this.get();
                        return this.update(R), j
                    }

                    function _(R, j, te) {
                        return j !== void 0 && (te = j), R in p ? R : te
                    }

                    function S(R) {
                        var j = /rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(R);
                        return (j ? a(j[1], j[2], j[3]) : R).replace(/#(\w)(\w)(\w)$/, "#$1$1$2$2$3$3")
                    }
                    var w = {
                        duration: 500,
                        ease: "ease",
                        delay: 0
                    };
                    l.init = function(R, j, te, K) {
                        this.$el = R, this.el = R[0];
                        var D = j[0];
                        te[2] && (D = te[2]), W[D] && (D = W[D]), this.name = D, this.type = te[1], this.duration = c(j[1], this.duration, w.duration), this.ease = _(j[2], this.ease, w.ease), this.delay = c(j[3], this.delay, w.delay), this.span = this.duration + this.delay, this.active = !1, this.nextStyle = null, this.auto = z.test(this.name), this.unit = K.unit || this.unit || H.defaultUnit, this.angle = K.angle || this.angle || H.defaultAngle, H.fallback || K.fallback ? this.animate = this.fallback : (this.animate = this.transition, this.string = this.name + J + this.duration + "ms" + (this.ease != "ease" ? J + p[this.ease][0] : "") + (this.delay ? J + this.delay + "ms" : ""))
                    }, l.set = function(R) {
                        R = this.convert(R, this.type), this.update(R), this.redraw()
                    }, l.transition = function(R) {
                        this.active = !0, R = this.convert(R, this.type), this.auto && (this.el.style[this.name] == "auto" && (this.update(this.get()), this.redraw()), R == "auto" && (R = y.call(this))), this.nextStyle = R
                    }, l.fallback = function(R) {
                        var j = this.el.style[this.name] || this.convert(this.get(), this.type);
                        R = this.convert(R, this.type), this.auto && (j == "auto" && (j = this.convert(this.get(), this.type)), R == "auto" && (R = y.call(this))), this.tween = new ne({
                            from: j,
                            to: R,
                            duration: this.duration,
                            delay: this.delay,
                            ease: this.ease,
                            update: this.update,
                            context: this
                        })
                    }, l.get = function() {
                        return F(this.el, this.name)
                    }, l.update = function(R) {
                        f(this.el, this.name, R)
                    }, l.stop = function() {
                        (this.active || this.nextStyle) && (this.active = !1, this.nextStyle = null, f(this.el, this.name, this.get()));
                        var R = this.tween;
                        R && R.context && R.destroy()
                    }, l.convert = function(R, j) {
                        if (R == "auto" && this.auto) return R;
                        var te, K = typeof R == "number",
                            D = typeof R == "string";
                        switch (j) {
                            case b:
                                if (K) return R;
                                if (D && R.replace(T, "") === "") return +R;
                                te = "number(unitless)";
                                break;
                            case N:
                                if (D) {
                                    if (R === "" && this.original) return this.original;
                                    if (j.test(R)) return R.charAt(0) == "#" && R.length == 7 ? R : S(R)
                                }
                                te = "hex or rgb string";
                                break;
                            case P:
                                if (K) return R + this.unit;
                                if (D && j.test(R)) return R;
                                te = "number(px) or string(unit)";
                                break;
                            case C:
                                if (K) return R + this.unit;
                                if (D && j.test(R)) return R;
                                te = "number(px) or string(unit or %)";
                                break;
                            case G:
                                if (K) return R + this.angle;
                                if (D && j.test(R)) return R;
                                te = "number(deg) or string(angle)";
                                break;
                            case X:
                                if (K || D && C.test(R)) return R;
                                te = "number(unitless) or string(unit or %)"
                        }
                        return o(te, R), R
                    }, l.redraw = function() {
                        this.el.offsetHeight
                    }
                }),
                k = E(L, function(l, y) {
                    l.init = function() {
                        y.init.apply(this, arguments), this.original || (this.original = this.convert(this.get(), N))
                    }
                }),
                Q = E(L, function(l, y) {
                    l.init = function() {
                        y.init.apply(this, arguments), this.animate = this.fallback
                    }, l.get = function() {
                        return this.$el[this.name]()
                    }, l.update = function(_) {
                        this.$el[this.name](_)
                    }
                }),
                U = E(L, function(l, y) {
                    function _(S, w) {
                        var R, j, te, K, D;
                        for (R in S) K = de[R], te = K[0], j = K[1] || R, D = this.convert(S[R], te), w.call(this, j, D, te)
                    }
                    l.init = function() {
                        y.init.apply(this, arguments), this.current || (this.current = {}, de.perspective && H.perspective && (this.current.perspective = H.perspective, f(this.el, this.name, this.style(this.current)), this.redraw()))
                    }, l.set = function(S) {
                        _.call(this, S, function(w, R) {
                            this.current[w] = R
                        }), f(this.el, this.name, this.style(this.current)), this.redraw()
                    }, l.transition = function(S) {
                        var w = this.values(S);
                        this.tween = new oe({
                            current: this.current,
                            values: w,
                            duration: this.duration,
                            delay: this.delay,
                            ease: this.ease
                        });
                        var R, j = {};
                        for (R in this.current) j[R] = R in w ? w[R] : this.current[R];
                        this.active = !0, this.nextStyle = this.style(j)
                    }, l.fallback = function(S) {
                        var w = this.values(S);
                        this.tween = new oe({
                            current: this.current,
                            values: w,
                            duration: this.duration,
                            delay: this.delay,
                            ease: this.ease,
                            update: this.update,
                            context: this
                        })
                    }, l.update = function() {
                        f(this.el, this.name, this.style(this.current))
                    }, l.style = function(S) {
                        var w, R = "";
                        for (w in S) R += w + "(" + S[w] + ") ";
                        return R
                    }, l.values = function(S) {
                        var w, R = {};
                        return _.call(this, S, function(j, te, K) {
                            R[j] = te, this.current[j] === void 0 && (w = 0, ~j.indexOf("scale") && (w = 1), this.current[j] = this.convert(w, K))
                        }), R
                    }
                }),
                ne = E(function(l) {
                    function y(D) {
                        te.push(D) === 1 && se(_)
                    }

                    function _() {
                        var D, ie, ae, Ee = te.length;
                        if (Ee)
                            for (se(_), ie = ve(), D = Ee; D--;) ae = te[D], ae && ae.render(ie)
                    }

                    function S(D) {
                        var ie, ae = e.inArray(D, te);
                        ae >= 0 && (ie = te.slice(ae + 1), te.length = ae, ie.length && (te = te.concat(ie)))
                    }

                    function w(D) {
                        return Math.round(D * K) / K
                    }

                    function R(D, ie, ae) {
                        return a(D[0] + ae * (ie[0] - D[0]), D[1] + ae * (ie[1] - D[1]), D[2] + ae * (ie[2] - D[2]))
                    }
                    var j = {
                        ease: p.ease[1],
                        from: 0,
                        to: 1
                    };
                    l.init = function(D) {
                        this.duration = D.duration || 0, this.delay = D.delay || 0;
                        var ie = D.ease || j.ease;
                        p[ie] && (ie = p[ie][1]), typeof ie != "function" && (ie = j.ease), this.ease = ie, this.update = D.update || r, this.complete = D.complete || r, this.context = D.context || this, this.name = D.name;
                        var ae = D.from,
                            Ee = D.to;
                        ae === void 0 && (ae = j.from), Ee === void 0 && (Ee = j.to), this.unit = D.unit || "", typeof ae == "number" && typeof Ee == "number" ? (this.begin = ae, this.change = Ee - ae) : this.format(Ee, ae), this.value = this.begin + this.unit, this.start = ve(), D.autoplay !== !1 && this.play()
                    }, l.play = function() {
                        this.active || (this.start || (this.start = ve()), this.active = !0, y(this))
                    }, l.stop = function() {
                        this.active && (this.active = !1, S(this))
                    }, l.render = function(D) {
                        var ie, ae = D - this.start;
                        if (this.delay) {
                            if (ae <= this.delay) return;
                            ae -= this.delay
                        }
                        if (ae < this.duration) {
                            var Ee = this.ease(ae, 0, 1, this.duration);
                            return ie = this.startRGB ? R(this.startRGB, this.endRGB, Ee) : w(this.begin + Ee * this.change), this.value = ie + this.unit, void this.update.call(this.context, this.value)
                        }
                        ie = this.endHex || this.begin + this.change, this.value = ie + this.unit, this.update.call(this.context, this.value), this.complete.call(this.context), this.destroy()
                    }, l.format = function(D, ie) {
                        if (ie += "", D += "", D.charAt(0) == "#") return this.startRGB = i(ie), this.endRGB = i(D), this.endHex = D, this.begin = 0, void(this.change = 1);
                        if (!this.unit) {
                            var ae = ie.replace(T, ""),
                                Ee = D.replace(T, "");
                            ae !== Ee && s("tween", ie, D), this.unit = ae
                        }
                        ie = parseFloat(ie), D = parseFloat(D), this.begin = this.value = ie, this.change = D - ie
                    }, l.destroy = function() {
                        this.stop(), this.context = null, this.ease = this.update = this.complete = r
                    };
                    var te = [],
                        K = 1e3
                }),
                re = E(ne, function(l) {
                    l.init = function(y) {
                        this.duration = y.duration || 0, this.complete = y.complete || r, this.context = y.context, this.play()
                    }, l.render = function(y) {
                        var _ = y - this.start;
                        _ < this.duration || (this.complete.call(this.context), this.destroy())
                    }
                }),
                oe = E(ne, function(l, y) {
                    l.init = function(_) {
                        this.context = _.context, this.update = _.update, this.tweens = [], this.current = _.current;
                        var S, w;
                        for (S in _.values) w = _.values[S], this.current[S] !== w && this.tweens.push(new ne({
                            name: S,
                            from: this.current[S],
                            to: w,
                            duration: _.duration,
                            delay: _.delay,
                            ease: _.ease,
                            autoplay: !1
                        }));
                        this.play()
                    }, l.render = function(_) {
                        var S, w, R = this.tweens.length,
                            j = !1;
                        for (S = R; S--;) w = this.tweens[S], w.context && (w.render(_), this.current[w.name] = w.value, j = !0);
                        return j ? void(this.update && this.update.call(this.context)) : this.destroy()
                    }, l.destroy = function() {
                        if (y.destroy.call(this), this.tweens) {
                            var _, S = this.tweens.length;
                            for (_ = S; _--;) this.tweens[_].destroy();
                            this.tweens = null, this.current = null
                        }
                    }
                }),
                H = t.config = {
                    debug: !1,
                    defaultUnit: "px",
                    defaultAngle: "deg",
                    keepInherited: !1,
                    hideBackface: !1,
                    perspective: "",
                    fallback: !q.transition,
                    agentTests: []
                };
            t.fallback = function(l) {
                if (!q.transition) return H.fallback = !0;
                H.agentTests.push("(" + l + ")");
                var y = new RegExp(H.agentTests.join("|"), "i");
                H.fallback = y.test(navigator.userAgent)
            }, t.fallback("6.0.[2-5] Safari"), t.tween = function(l) {
                return new ne(l)
            }, t.delay = function(l, y, _) {
                return new re({
                    complete: y,
                    duration: l,
                    context: _
                })
            }, e.fn.tram = function(l) {
                return t.call(null, this, l)
            };
            var f = e.style,
                F = e.css,
                W = {
                    transform: q.transform && q.transform.css
                },
                V = {
                    color: [k, N],
                    background: [k, N, "background-color"],
                    "outline-color": [k, N],
                    "border-color": [k, N],
                    "border-top-color": [k, N],
                    "border-right-color": [k, N],
                    "border-bottom-color": [k, N],
                    "border-left-color": [k, N],
                    "border-width": [L, P],
                    "border-top-width": [L, P],
                    "border-right-width": [L, P],
                    "border-bottom-width": [L, P],
                    "border-left-width": [L, P],
                    "border-spacing": [L, P],
                    "letter-spacing": [L, P],
                    margin: [L, P],
                    "margin-top": [L, P],
                    "margin-right": [L, P],
                    "margin-bottom": [L, P],
                    "margin-left": [L, P],
                    padding: [L, P],
                    "padding-top": [L, P],
                    "padding-right": [L, P],
                    "padding-bottom": [L, P],
                    "padding-left": [L, P],
                    "outline-width": [L, P],
                    opacity: [L, b],
                    top: [L, C],
                    right: [L, C],
                    bottom: [L, C],
                    left: [L, C],
                    "font-size": [L, C],
                    "text-indent": [L, C],
                    "word-spacing": [L, C],
                    width: [L, C],
                    "min-width": [L, C],
                    "max-width": [L, C],
                    height: [L, C],
                    "min-height": [L, C],
                    "max-height": [L, C],
                    "line-height": [L, X],
                    "scroll-top": [Q, b, "scrollTop"],
                    "scroll-left": [Q, b, "scrollLeft"]
                },
                de = {};
            q.transform && (V.transform = [U], de = {
                x: [C, "translateX"],
                y: [C, "translateY"],
                rotate: [G],
                rotateX: [G],
                rotateY: [G],
                scale: [b],
                scaleX: [b],
                scaleY: [b],
                skew: [G],
                skewX: [G],
                skewY: [G]
            }), q.transform && q.backface && (de.z = [C, "translateZ"], de.rotateZ = [G], de.scaleZ = [b], de.perspective = [P]);
            var Je = /ms/,
                ke = /s|\./;
            return e.tram = t
        }(window.jQuery)
    });
    var Ka = u((LC, ja) => {
        "use strict";
        var sE = window.$,
            cE = bi() && sE.tram;
        ja.exports = function() {
            var e = {};
            e.VERSION = "1.6.0-Webflow";
            var t = {},
                n = Array.prototype,
                i = Object.prototype,
                a = Function.prototype,
                r = n.push,
                o = n.slice,
                s = n.concat,
                c = i.toString,
                d = i.hasOwnProperty,
                I = n.forEach,
                E = n.map,
                p = n.reduce,
                g = n.reduceRight,
                v = n.filter,
                m = n.every,
                h = n.some,
                T = n.indexOf,
                A = n.lastIndexOf,
                b = Array.isArray,
                N = Object.keys,
                P = a.bind,
                C = e.each = e.forEach = function(O, M, Y) {
                    if (O == null) return O;
                    if (I && O.forEach === I) O.forEach(M, Y);
                    else if (O.length === +O.length) {
                        for (var q = 0, ee = O.length; q < ee; q++)
                            if (M.call(Y, O[q], q, O) === t) return
                    } else
                        for (var Z = e.keys(O), q = 0, ee = Z.length; q < ee; q++)
                            if (M.call(Y, O[Z[q]], Z[q], O) === t) return;
                    return O
                };
            e.map = e.collect = function(O, M, Y) {
                var q = [];
                return O == null ? q : E && O.map === E ? O.map(M, Y) : (C(O, function(ee, Z, se) {
                    q.push(M.call(Y, ee, Z, se))
                }), q)
            }, e.find = e.detect = function(O, M, Y) {
                var q;
                return G(O, function(ee, Z, se) {
                    if (M.call(Y, ee, Z, se)) return q = ee, !0
                }), q
            }, e.filter = e.select = function(O, M, Y) {
                var q = [];
                return O == null ? q : v && O.filter === v ? O.filter(M, Y) : (C(O, function(ee, Z, se) {
                    M.call(Y, ee, Z, se) && q.push(ee)
                }), q)
            };
            var G = e.some = e.any = function(O, M, Y) {
                M || (M = e.identity);
                var q = !1;
                return O == null ? q : h && O.some === h ? O.some(M, Y) : (C(O, function(ee, Z, se) {
                    if (q || (q = M.call(Y, ee, Z, se))) return t
                }), !!q)
            };
            e.contains = e.include = function(O, M) {
                return O == null ? !1 : T && O.indexOf === T ? O.indexOf(M) != -1 : G(O, function(Y) {
                    return Y === M
                })
            }, e.delay = function(O, M) {
                var Y = o.call(arguments, 2);
                return setTimeout(function() {
                    return O.apply(null, Y)
                }, M)
            }, e.defer = function(O) {
                return e.delay.apply(e, [O, 1].concat(o.call(arguments, 1)))
            }, e.throttle = function(O) {
                var M, Y, q;
                return function() {
                    M || (M = !0, Y = arguments, q = this, cE.frame(function() {
                        M = !1, O.apply(q, Y)
                    }))
                }
            }, e.debounce = function(O, M, Y) {
                var q, ee, Z, se, ve, Ce = function() {
                    var ye = e.now() - se;
                    ye < M ? q = setTimeout(Ce, M - ye) : (q = null, Y || (ve = O.apply(Z, ee), Z = ee = null))
                };
                return function() {
                    Z = this, ee = arguments, se = e.now();
                    var ye = Y && !q;
                    return q || (q = setTimeout(Ce, M)), ye && (ve = O.apply(Z, ee), Z = ee = null), ve
                }
            }, e.defaults = function(O) {
                if (!e.isObject(O)) return O;
                for (var M = 1, Y = arguments.length; M < Y; M++) {
                    var q = arguments[M];
                    for (var ee in q) O[ee] === void 0 && (O[ee] = q[ee])
                }
                return O
            }, e.keys = function(O) {
                if (!e.isObject(O)) return [];
                if (N) return N(O);
                var M = [];
                for (var Y in O) e.has(O, Y) && M.push(Y);
                return M
            }, e.has = function(O, M) {
                return d.call(O, M)
            }, e.isObject = function(O) {
                return O === Object(O)
            }, e.now = Date.now || function() {
                return new Date().getTime()
            }, e.templateSettings = {
                evaluate: /<%([\s\S]+?)%>/g,
                interpolate: /<%=([\s\S]+?)%>/g,
                escape: /<%-([\s\S]+?)%>/g
            };
            var X = /(.)^/,
                B = {
                    "'": "'",
                    "\\": "\\",
                    "\r": "r",
                    "\n": "n",
                    "\u2028": "u2028",
                    "\u2029": "u2029"
                },
                z = /\\|'|\r|\n|\u2028|\u2029/g,
                J = function(O) {
                    return "\\" + B[O]
                },
                x = /^\s*(\w|\$)+\s*$/;
            return e.template = function(O, M, Y) {
                !M && Y && (M = Y), M = e.defaults({}, M, e.templateSettings);
                var q = RegExp([(M.escape || X).source, (M.interpolate || X).source, (M.evaluate || X).source].join("|") + "|$", "g"),
                    ee = 0,
                    Z = "__p+='";
                O.replace(q, function(ye, L, k, Q, U) {
                    return Z += O.slice(ee, U).replace(z, J), ee = U + ye.length, L ? Z += `'+
((__t=(` + L + `))==null?'':_.escape(__t))+
'` : k ? Z += `'+
((__t=(` + k + `))==null?'':__t)+
'` : Q && (Z += `';
` + Q + `
__p+='`), ye
                }), Z += `';
`;
                var se = M.variable;
                if (se) {
                    if (!x.test(se)) throw new Error("variable is not a bare identifier: " + se)
                } else Z = `with(obj||{}){
` + Z + `}
`, se = "obj";
                Z = `var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};
` + Z + `return __p;
`;
                var ve;
                try {
                    ve = new Function(M.variable || "obj", "_", Z)
                } catch (ye) {
                    throw ye.source = Z, ye
                }
                var Ce = function(ye) {
                    return ve.call(this, ye, e)
                };
                return Ce.source = "function(" + se + `){
` + Z + "}", Ce
            }, e
        }()
    });
    var Ue = u((NC, ro) => {
        "use strict";
        var le = {},
            Tt = {},
            mt = [],
            Ai = window.Webflow || [],
            et = window.jQuery,
            Ve = et(window),
            uE = et(document),
            Xe = et.isFunction,
            De = le._ = Ka(),
            Za = le.tram = bi() && et.tram,
            yn = !1,
            Ri = !1;
        Za.config.hideBackface = !1;
        Za.config.keepInherited = !0;
        le.define = function(e, t, n) {
            Tt[e] && eo(Tt[e]);
            var i = Tt[e] = t(et, De, n) || {};
            return Ja(i), i
        };
        le.require = function(e) {
            return Tt[e]
        };

        function Ja(e) {
            le.env() && (Xe(e.design) && Ve.on("__wf_design", e.design), Xe(e.preview) && Ve.on("__wf_preview", e.preview)), Xe(e.destroy) && Ve.on("__wf_destroy", e.destroy), e.ready && Xe(e.ready) && lE(e)
        }

        function lE(e) {
            if (yn) {
                e.ready();
                return
            }
            De.contains(mt, e.ready) || mt.push(e.ready)
        }

        function eo(e) {
            Xe(e.design) && Ve.off("__wf_design", e.design), Xe(e.preview) && Ve.off("__wf_preview", e.preview), Xe(e.destroy) && Ve.off("__wf_destroy", e.destroy), e.ready && Xe(e.ready) && dE(e)
        }

        function dE(e) {
            mt = De.filter(mt, function(t) {
                return t !== e.ready
            })
        }
        le.push = function(e) {
            if (yn) {
                Xe(e) && e();
                return
            }
            Ai.push(e)
        };
        le.env = function(e) {
            var t = window.__wf_design,
                n = typeof t < "u";
            if (!e) return n;
            if (e === "design") return n && t;
            if (e === "preview") return n && !t;
            if (e === "slug") return n && window.__wf_slug;
            if (e === "editor") return window.WebflowEditor;
            if (e === "test") return window.__wf_test;
            if (e === "frame") return window !== window.top
        };
        var In = navigator.userAgent.toLowerCase(),
            to = le.env.touch = "ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch,
            fE = le.env.chrome = /chrome/.test(In) && /Google/.test(navigator.vendor) && parseInt(In.match(/chrome\/(\d+)\./)[1], 10),
            pE = le.env.ios = /(ipod|iphone|ipad)/.test(In);
        le.env.safari = /safari/.test(In) && !fE && !pE;
        var Si;
        to && uE.on("touchstart mousedown", function(e) {
            Si = e.target
        });
        le.validClick = to ? function(e) {
            return e === Si || et.contains(e, Si)
        } : function() {
            return !0
        };
        var no = "resize.webflow orientationchange.webflow load.webflow",
            gE = "scroll.webflow " + no;
        le.resize = Li(Ve, no);
        le.scroll = Li(Ve, gE);
        le.redraw = Li();

        function Li(e, t) {
            var n = [],
                i = {};
            return i.up = De.throttle(function(a) {
                De.each(n, function(r) {
                    r(a)
                })
            }), e && t && e.on(t, i.up), i.on = function(a) {
                typeof a == "function" && (De.contains(n, a) || n.push(a))
            }, i.off = function(a) {
                if (!arguments.length) {
                    n = [];
                    return
                }
                n = De.filter(n, function(r) {
                    return r !== a
                })
            }, i
        }
        le.location = function(e) {
            window.location = e
        };
        le.env() && (le.location = function() {});
        le.ready = function() {
            yn = !0, Ri ? EE() : De.each(mt, $a), De.each(Ai, $a), le.resize.up()
        };

        function $a(e) {
            Xe(e) && e()
        }

        function EE() {
            Ri = !1, De.each(Tt, Ja)
        }
        var ct;
        le.load = function(e) {
            ct.then(e)
        };

        function io() {
            ct && (ct.reject(), Ve.off("load", ct.resolve)), ct = new et.Deferred, Ve.on("load", ct.resolve)
        }
        le.destroy = function(e) {
            e = e || {}, Ri = !0, Ve.triggerHandler("__wf_destroy"), e.domready != null && (yn = e.domready), De.each(Tt, eo), le.resize.off(), le.scroll.off(), le.redraw.off(), mt = [], Ai = [], ct.state() === "pending" && io()
        };
        et(le.ready);
        io();
        ro.exports = window.Webflow = le
    });
    var so = u((CC, oo) => {
        "use strict";
        var ao = Ue();
        ao.define("brand", oo.exports = function(e) {
            var t = {},
                n = document,
                i = e("html"),
                a = e("body"),
                r = ".w-webflow-badge",
                o = window.location,
                s = /PhantomJS/i.test(navigator.userAgent),
                c = "fullscreenchange webkitfullscreenchange mozfullscreenchange msfullscreenchange",
                d;
            t.ready = function() {
                var g = i.attr("data-wf-status"),
                    v = i.attr("data-wf-domain") || "";
                /\.webflow\.io$/i.test(v) && o.hostname !== v && (g = !0), g && !s && (d = d || E(), p(), setTimeout(p, 500), e(n).off(c, I).on(c, I))
            };

            function I() {
                var g = n.fullScreen || n.mozFullScreen || n.webkitIsFullScreen || n.msFullscreenElement || !!n.webkitFullscreenElement;
                e(d).attr("style", g ? "display: none !important;" : "")
            }
            
            function p() {
                var g = a.children(r),
                    v = g.length && g.get(0) === d,
                    m = ao.env("editor");
                if (v) {
                    m && g.remove();
                    return
                }
                g.length && g.remove(), m || a.append(d)
            }
            return t
        })
    });
    var uo = u((wC, co) => {
        "use strict";
        var vt = Ue();
        vt.define("links", co.exports = function(e, t) {
            var n = {},
                i = e(window),
                a, r = vt.env(),
                o = window.location,
                s = document.createElement("a"),
                c = "w--current",
                d = /index\.(html|php)$/,
                I = /\/$/,
                E, p;
            n.ready = n.design = n.preview = g;

            function g() {
                a = r && vt.env("design"), p = vt.env("slug") || o.pathname || "", vt.scroll.off(m), E = [];
                for (var T = document.links, A = 0; A < T.length; ++A) v(T[A]);
                E.length && (vt.scroll.on(m), m())
            }

            function v(T) {
                if (!T.getAttribute("hreflang")) {
                    var A = a && T.getAttribute("href-disabled") || T.getAttribute("href");
                    if (s.href = A, !(A.indexOf(":") >= 0)) {
                        var b = e(T);
                        if (s.hash.length > 1 && s.host + s.pathname === o.host + o.pathname) {
                            if (!/^#[a-zA-Z0-9\-\_]+$/.test(s.hash)) return;
                            var N = e(s.hash);
                            N.length && E.push({
                                link: b,
                                sec: N,
                                active: !1
                            });
                            return
                        }
                        if (!(A === "#" || A === "")) {
                            var P = s.href === o.href || A === p || d.test(A) && I.test(p);
                            h(b, c, P)
                        }
                    }
                }
            }

            function m() {
                var T = i.scrollTop(),
                    A = i.height();
                t.each(E, function(b) {
                    if (!b.link.attr("hreflang")) {
                        var N = b.link,
                            P = b.sec,
                            C = P.offset().top,
                            G = P.outerHeight(),
                            X = A * .5,
                            B = P.is(":visible") && C + G - X >= T && C + X <= T + A;
                        b.active !== B && (b.active = B, h(N, c, B))
                    }
                })
            }

            function h(T, A, b) {
                var N = T.hasClass(A);
                b && N || !b && !N || (b ? T.addClass(A) : T.removeClass(A))
            }
            return n
        })
    });
    var fo = u((PC, lo) => {
        "use strict";
        var Tn = Ue();
        Tn.define("scroll", lo.exports = function(e) {
            var t = {
                    WF_CLICK_EMPTY: "click.wf-empty-link",
                    WF_CLICK_SCROLL: "click.wf-scroll"
                },
                n = window.location,
                i = v() ? null : window.history,
                a = e(window),
                r = e(document),
                o = e(document.body),
                s = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || function(x) {
                    window.setTimeout(x, 15)
                },
                c = Tn.env("editor") ? ".w-editor-body" : "body",
                d = "header, " + c + " > .header, " + c + " > .w-nav:not([data-no-scroll])",
                I = 'a[href="#"]',
                E = 'a[href*="#"]:not(.w-tab-link):not(' + I + ")",
                p = '.wf-force-outline-none[tabindex="-1"]:focus{outline:none;}',
                g = document.createElement("style");
            g.appendChild(document.createTextNode(p));

            function v() {
                try {
                    return !!window.frameElement
                } catch {
                    return !0
                }
            }
            var m = /^#[a-zA-Z0-9][\w:.-]*$/;

            function h(x) {
                return m.test(x.hash) && x.host + x.pathname === n.host + n.pathname
            }
            let T = typeof window.matchMedia == "function" && window.matchMedia("(prefers-reduced-motion: reduce)");

            function A() {
                return document.body.getAttribute("data-wf-scroll-motion") === "none" || T.matches
            }

            function b(x, O) {
                var M;
                switch (O) {
                    case "add":
                        M = x.attr("tabindex"), M ? x.attr("data-wf-tabindex-swap", M) : x.attr("tabindex", "-1");
                        break;
                    case "remove":
                        M = x.attr("data-wf-tabindex-swap"), M ? (x.attr("tabindex", M), x.removeAttr("data-wf-tabindex-swap")) : x.removeAttr("tabindex");
                        break
                }
                x.toggleClass("wf-force-outline-none", O === "add")
            }

            function N(x) {
                var O = x.currentTarget;
                if (!(Tn.env("design") || window.$.mobile && /(?:^|\s)ui-link(?:$|\s)/.test(O.className))) {
                    var M = h(O) ? O.hash : "";
                    if (M !== "") {
                        var Y = e(M);
                        Y.length && (x && (x.preventDefault(), x.stopPropagation()), P(M, x), window.setTimeout(function() {
                            C(Y, function() {
                                b(Y, "add"), Y.get(0).focus({
                                    preventScroll: !0
                                }), b(Y, "remove")
                            })
                        }, x ? 0 : 300))
                    }
                }
            }

            function P(x) {
                if (n.hash !== x && i && i.pushState && !(Tn.env.chrome && n.protocol === "file:")) {
                    var O = i.state && i.state.hash;
                    O !== x && i.pushState({
                        hash: x
                    }, "", x)
                }
            }

            function C(x, O) {
                var M = a.scrollTop(),
                    Y = G(x);
                if (M !== Y) {
                    var q = X(x, M, Y),
                        ee = Date.now(),
                        Z = function() {
                            var se = Date.now() - ee;
                            window.scroll(0, B(M, Y, se, q)), se <= q ? s(Z) : typeof O == "function" && O()
                        };
                    s(Z)
                }
            }

            function G(x) {
                var O = e(d),
                    M = O.css("position") === "fixed" ? O.outerHeight() : 0,
                    Y = x.offset().top - M;
                if (x.data("scroll") === "mid") {
                    var q = a.height() - M,
                        ee = x.outerHeight();
                    ee < q && (Y -= Math.round((q - ee) / 2))
                }
                return Y
            }

            function X(x, O, M) {
                if (A()) return 0;
                var Y = 1;
                return o.add(x).each(function(q, ee) {
                    var Z = parseFloat(ee.getAttribute("data-scroll-time"));
                    !isNaN(Z) && Z >= 0 && (Y = Z)
                }), (472.143 * Math.log(Math.abs(O - M) + 125) - 2e3) * Y
            }

            function B(x, O, M, Y) {
                return M > Y ? O : x + (O - x) * z(M / Y)
            }

            function z(x) {
                return x < .5 ? 4 * x * x * x : (x - 1) * (2 * x - 2) * (2 * x - 2) + 1
            }

            function J() {
                var {
                    WF_CLICK_EMPTY: x,
                    WF_CLICK_SCROLL: O
                } = t;
                r.on(O, E, N), r.on(x, I, function(M) {
                    M.preventDefault()
                }), document.head.insertBefore(g, document.head.firstChild)
            }
            return {
                ready: J
            }
        })
    });
    var Eo = u((MC, go) => {
        "use strict";
        var po = Ue();
        po.define("focus", go.exports = function() {
            var e = [],
                t = !1;

            function n(o) {
                t && (o.preventDefault(), o.stopPropagation(), o.stopImmediatePropagation(), e.unshift(o))
            }

            function i(o) {
                var s = o.target,
                    c = s.tagName;
                return /^a$/i.test(c) && s.href != null || /^(button|textarea)$/i.test(c) && s.disabled !== !0 || /^input$/i.test(c) && /^(button|reset|submit|radio|checkbox)$/i.test(s.type) && !s.disabled || !/^(button|input|textarea|select|a)$/i.test(c) && !Number.isNaN(Number.parseFloat(s.tabIndex)) || /^audio$/i.test(c) || /^video$/i.test(c) && s.controls === !0
            }

            function a(o) {
                i(o) && (t = !0, setTimeout(() => {
                    for (t = !1, o.target.focus(); e.length > 0;) {
                        var s = e.pop();
                        s.target.dispatchEvent(new MouseEvent(s.type, s))
                    }
                }, 0))
            }

            function r() {
                typeof document < "u" && document.body.hasAttribute("data-wf-focus-within") && po.env.safari && (document.addEventListener("mousedown", a, !0), document.addEventListener("mouseup", n, !0), document.addEventListener("click", n, !0))
            }
            return {
                ready: r
            }
        })
    });
    var yo = u((xC, Io) => {
        "use strict";
        var IE = Ue();
        IE.define("focus-visible", Io.exports = function() {
            function e(n) {
                var i = !0,
                    a = !1,
                    r = null,
                    o = {
                        text: !0,
                        search: !0,
                        url: !0,
                        tel: !0,
                        email: !0,
                        password: !0,
                        number: !0,
                        date: !0,
                        month: !0,
                        week: !0,
                        time: !0,
                        datetime: !0,
                        "datetime-local": !0
                    };

                function s(b) {
                    return !!(b && b !== document && b.nodeName !== "HTML" && b.nodeName !== "BODY" && "classList" in b && "contains" in b.classList)
                }

                function c(b) {
                    var N = b.type,
                        P = b.tagName;
                    return !!(P === "INPUT" && o[N] && !b.readOnly || P === "TEXTAREA" && !b.readOnly || b.isContentEditable)
                }

                function d(b) {
                    b.getAttribute("data-wf-focus-visible") || b.setAttribute("data-wf-focus-visible", "true")
                }

                function I(b) {
                    b.getAttribute("data-wf-focus-visible") && b.removeAttribute("data-wf-focus-visible")
                }

                function E(b) {
                    b.metaKey || b.altKey || b.ctrlKey || (s(n.activeElement) && d(n.activeElement), i = !0)
                }

                function p() {
                    i = !1
                }

                function g(b) {
                    s(b.target) && (i || c(b.target)) && d(b.target)
                }

                function v(b) {
                    s(b.target) && b.target.hasAttribute("data-wf-focus-visible") && (a = !0, window.clearTimeout(r), r = window.setTimeout(function() {
                        a = !1
                    }, 100), I(b.target))
                }

                function m() {
                    document.visibilityState === "hidden" && (a && (i = !0), h())
                }

                function h() {
                    document.addEventListener("mousemove", A), document.addEventListener("mousedown", A), document.addEventListener("mouseup", A), document.addEventListener("pointermove", A), document.addEventListener("pointerdown", A), document.addEventListener("pointerup", A), document.addEventListener("touchmove", A), document.addEventListener("touchstart", A), document.addEventListener("touchend", A)
                }

                function T() {
                    document.removeEventListener("mousemove", A), document.removeEventListener("mousedown", A), document.removeEventListener("mouseup", A), document.removeEventListener("pointermove", A), document.removeEventListener("pointerdown", A), document.removeEventListener("pointerup", A), document.removeEventListener("touchmove", A), document.removeEventListener("touchstart", A), document.removeEventListener("touchend", A)
                }

                function A(b) {
                    b.target.nodeName && b.target.nodeName.toLowerCase() === "html" || (i = !1, T())
                }
                document.addEventListener("keydown", E, !0), document.addEventListener("mousedown", p, !0), document.addEventListener("pointerdown", p, !0), document.addEventListener("touchstart", p, !0), document.addEventListener("visibilitychange", m, !0), h(), n.addEventListener("focus", g, !0), n.addEventListener("blur", v, !0)
            }

            function t() {
                if (typeof document < "u") try {
                    document.querySelector(":focus-visible")
                } catch {
                    e(document)
                }
            }
            return {
                ready: t
            }
        })
    });
    var mo = u((FC, To) => {
        "use strict";
        var yE = Ue();
        yE.define("touch", To.exports = function(e) {
            var t = {},
                n = window.getSelection;
            e.event.special.tap = {
                bindType: "click",
                delegateType: "click"
            }, t.init = function(r) {
                return r = typeof r == "string" ? e(r).get(0) : r, r ? new i(r) : null
            };

            function i(r) {
                var o = !1,
                    s = !1,
                    c = Math.min(Math.round(window.innerWidth * .04), 40),
                    d, I;
                r.addEventListener("touchstart", E, !1), r.addEventListener("touchmove", p, !1), r.addEventListener("touchend", g, !1), r.addEventListener("touchcancel", v, !1), r.addEventListener("mousedown", E, !1), r.addEventListener("mousemove", p, !1), r.addEventListener("mouseup", g, !1), r.addEventListener("mouseout", v, !1);

                function E(h) {
                    var T = h.touches;
                    T && T.length > 1 || (o = !0, T ? (s = !0, d = T[0].clientX) : d = h.clientX, I = d)
                }

                function p(h) {
                    if (o) {
                        if (s && h.type === "mousemove") {
                            h.preventDefault(), h.stopPropagation();
                            return
                        }
                        var T = h.touches,
                            A = T ? T[0].clientX : h.clientX,
                            b = A - I;
                        I = A, Math.abs(b) > c && n && String(n()) === "" && (a("swipe", h, {
                            direction: b > 0 ? "right" : "left"
                        }), v())
                    }
                }

                function g(h) {
                    if (o && (o = !1, s && h.type === "mouseup")) {
                        h.preventDefault(), h.stopPropagation(), s = !1;
                        return
                    }
                }

                function v() {
                    o = !1
                }

                function m() {
                    r.removeEventListener("touchstart", E, !1), r.removeEventListener("touchmove", p, !1), r.removeEventListener("touchend", g, !1), r.removeEventListener("touchcancel", v, !1), r.removeEventListener("mousedown", E, !1), r.removeEventListener("mousemove", p, !1), r.removeEventListener("mouseup", g, !1), r.removeEventListener("mouseout", v, !1), r = null
                }
                this.destroy = m
            }

            function a(r, o, s) {
                var c = e.Event(r, {
                    originalEvent: o
                });
                e(o.target).trigger(c, s)
            }
            return t.instance = t.init(document), t
        })
    });
    var _o = u((DC, vo) => {
        "use strict";
        var Ni = Ue();
        Ni.define("edit", vo.exports = function(e, t, n) {
            if (n = n || {}, (Ni.env("test") || Ni.env("frame")) && !n.fixture && !TE()) return {
                exit: 1
            };
            var i = {},
                a = e(window),
                r = e(document.documentElement),
                o = document.location,
                s = "hashchange",
                c, d = n.load || p,
                I = !1;
            try {
                I = localStorage && localStorage.getItem && localStorage.getItem("WebflowEditor")
            } catch {}
            I ? d() : o.search ? (/[?&](edit)(?:[=&?]|$)/.test(o.search) || /\?edit$/.test(o.href)) && d() : a.on(s, E).triggerHandler(s);

            function E() {
                c || /\?edit/.test(o.hash) && d()
            }

            function p() {
                c = !0, window.WebflowEditor = !0, a.off(s, E), A(function(N) {
                    e.ajax({
                        url: T("https://editor-api.webflow.com/api/editor/view"),
                        data: {
                            siteId: r.attr("data-wf-site")
                        },
                        xhrFields: {
                            withCredentials: !0
                        },
                        dataType: "json",
                        crossDomain: !0,
                        success: g(N)
                    })
                })
            }

            function g(N) {
                return function(P) {
                    if (!P) {
                        console.error("Could not load editor data");
                        return
                    }
                    P.thirdPartyCookiesSupported = N, v(h(P.scriptPath), function() {
                        window.WebflowEditor(P)
                    })
                }
            }

            function v(N, P) {
                e.ajax({
                    type: "GET",
                    url: N,
                    dataType: "script",
                    cache: !0
                }).then(P, m)
            }

            function m(N, P, C) {
                throw console.error("Could not load editor script: " + P), C
            }

            function h(N) {
                return N.indexOf("//") >= 0 ? N : T("https://editor-api.webflow.com" + N)
            }

            function T(N) {
                return N.replace(/([^:])\/\//g, "$1/")
            }

            function A(N) {
                var P = window.document.createElement("iframe");
                P.src = "https://webflow.com/site/third-party-cookie-check.html", P.style.display = "none", P.sandbox = "allow-scripts allow-same-origin";
                var C = function(G) {
                    G.data === "WF_third_party_cookies_unsupported" ? (b(P, C), N(!1)) : G.data === "WF_third_party_cookies_supported" && (b(P, C), N(!0))
                };
                P.onerror = function() {
                    b(P, C), N(!1)
                }, window.addEventListener("message", C, !1), window.document.body.appendChild(P)
            }

            function b(N, P) {
                window.removeEventListener("message", P, !1), N.remove()
            }
            return i
        });

        function TE() {
            try {
                return window.top.__Cypress__
            } catch {
                return !1
            }
        }
    });
    var Ci = u((VC, Oo) => {
        var mE = typeof global == "object" && global && global.Object === Object && global;
        Oo.exports = mE
    });
    var Ge = u((UC, ho) => {
        var vE = Ci(),
            _E = typeof self == "object" && self && self.Object === Object && self,
            OE = vE || _E || Function("return this")();
        ho.exports = OE
    });
    var _t = u((GC, bo) => {
        var hE = Ge(),
            bE = hE.Symbol;
        bo.exports = bE
    });
    var Lo = u((qC, Ro) => {
        var So = _t(),
            Ao = Object.prototype,
            SE = Ao.hasOwnProperty,
            AE = Ao.toString,
            Yt = So ? So.toStringTag : void 0;

        function RE(e) {
            var t = SE.call(e, Yt),
                n = e[Yt];
            try {
                e[Yt] = void 0;
                var i = !0
            } catch {}
            var a = AE.call(e);
            return i && (t ? e[Yt] = n : delete e[Yt]), a
        }
        Ro.exports = RE
    });
    var Co = u((kC, No) => {
        var LE = Object.prototype,
            NE = LE.toString;

        function CE(e) {
            return NE.call(e)
        }
        No.exports = CE
    });
    var tt = u((XC, Mo) => {
        var wo = _t(),
            wE = Lo(),
            PE = Co(),
            ME = "[object Null]",
            xE = "[object Undefined]",
            Po = wo ? wo.toStringTag : void 0;

        function FE(e) {
            return e == null ? e === void 0 ? xE : ME : Po && Po in Object(e) ? wE(e) : PE(e)
        }
        Mo.exports = FE
    });
    var wi = u((BC, xo) => {
        function DE(e, t) {
            return function(n) {
                return e(t(n))
            }
        }
        xo.exports = DE
    });
    var Pi = u((YC, Fo) => {
        var VE = wi(),
            UE = VE(Object.getPrototypeOf, Object);
        Fo.exports = UE
    });
    var Ke = u((WC, Do) => {
        function GE(e) {
            return e != null && typeof e == "object"
        }
        Do.exports = GE
    });
    var Mi = u((HC, Uo) => {
        var qE = tt(),
            kE = Pi(),
            XE = Ke(),
            BE = "[object Object]",
            YE = Function.prototype,
            WE = Object.prototype,
            Vo = YE.toString,
            HE = WE.hasOwnProperty,
            zE = Vo.call(Object);

        function QE(e) {
            if (!XE(e) || qE(e) != BE) return !1;
            var t = kE(e);
            if (t === null) return !0;
            var n = HE.call(t, "constructor") && t.constructor;
            return typeof n == "function" && n instanceof n && Vo.call(n) == zE
        }
        Uo.exports = QE
    });
    var Go = u(xi => {
        "use strict";
        Object.defineProperty(xi, "__esModule", {
            value: !0
        });
        xi.default = jE;

        function jE(e) {
            var t, n = e.Symbol;
            return typeof n == "function" ? n.observable ? t = n.observable : (t = n("observable"), n.observable = t) : t = "@@observable", t
        }
    });
    var qo = u((Di, Fi) => {
        "use strict";
        Object.defineProperty(Di, "__esModule", {
            value: !0
        });
        var KE = Go(),
            $E = ZE(KE);

        function ZE(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var Ot;
        typeof self < "u" ? Ot = self : typeof window < "u" ? Ot = window : typeof global < "u" ? Ot = global : typeof Fi < "u" ? Ot = Fi : Ot = Function("return this")();
        var JE = (0, $E.default)(Ot);
        Di.default = JE
    });
    var Vi = u(Wt => {
        "use strict";
        Wt.__esModule = !0;
        Wt.ActionTypes = void 0;
        Wt.default = Yo;
        var eI = Mi(),
            tI = Bo(eI),
            nI = qo(),
            ko = Bo(nI);

        function Bo(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var Xo = Wt.ActionTypes = {
            INIT: "@@redux/INIT"
        };

        function Yo(e, t, n) {
            var i;
            if (typeof t == "function" && typeof n > "u" && (n = t, t = void 0), typeof n < "u") {
                if (typeof n != "function") throw new Error("Expected the enhancer to be a function.");
                return n(Yo)(e, t)
            }
            if (typeof e != "function") throw new Error("Expected the reducer to be a function.");
            var a = e,
                r = t,
                o = [],
                s = o,
                c = !1;

            function d() {
                s === o && (s = o.slice())
            }

            function I() {
                return r
            }

            function E(m) {
                if (typeof m != "function") throw new Error("Expected listener to be a function.");
                var h = !0;
                return d(), s.push(m),
                    function() {
                        if (h) {
                            h = !1, d();
                            var A = s.indexOf(m);
                            s.splice(A, 1)
                        }
                    }
            }

            function p(m) {
                if (!(0, tI.default)(m)) throw new Error("Actions must be plain objects. Use custom middleware for async actions.");
                if (typeof m.type > "u") throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');
                if (c) throw new Error("Reducers may not dispatch actions.");
                try {
                    c = !0, r = a(r, m)
                } finally {
                    c = !1
                }
                for (var h = o = s, T = 0; T < h.length; T++) h[T]();
                return m
            }

            function g(m) {
                if (typeof m != "function") throw new Error("Expected the nextReducer to be a function.");
                a = m, p({
                    type: Xo.INIT
                })
            }

            function v() {
                var m, h = E;
                return m = {
                    subscribe: function(A) {
                        if (typeof A != "object") throw new TypeError("Expected the observer to be an object.");

                        function b() {
                            A.next && A.next(I())
                        }
                        b();
                        var N = h(b);
                        return {
                            unsubscribe: N
                        }
                    }
                }, m[ko.default] = function() {
                    return this
                }, m
            }
            return p({
                type: Xo.INIT
            }), i = {
                dispatch: p,
                subscribe: E,
                getState: I,
                replaceReducer: g
            }, i[ko.default] = v, i
        }
    });
    var Gi = u(Ui => {
        "use strict";
        Ui.__esModule = !0;
        Ui.default = iI;

        function iI(e) {
            typeof console < "u" && typeof console.error == "function" && console.error(e);
            try {
                throw new Error(e)
            } catch {}
        }
    });
    var zo = u(qi => {
        "use strict";
        qi.__esModule = !0;
        qi.default = cI;
        var Wo = Vi(),
            rI = Mi(),
            KC = Ho(rI),
            aI = Gi(),
            $C = Ho(aI);

        function Ho(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function oI(e, t) {
            var n = t && t.type,
                i = n && '"' + n.toString() + '"' || "an action";
            return "Given action " + i + ', reducer "' + e + '" returned undefined. To ignore an action, you must explicitly return the previous state.'
        }

        function sI(e) {
            Object.keys(e).forEach(function(t) {
                var n = e[t],
                    i = n(void 0, {
                        type: Wo.ActionTypes.INIT
                    });
                if (typeof i > "u") throw new Error('Reducer "' + t + '" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined.');
                var a = "@@redux/PROBE_UNKNOWN_ACTION_" + Math.random().toString(36).substring(7).split("").join(".");
                if (typeof n(void 0, {
                        type: a
                    }) > "u") throw new Error('Reducer "' + t + '" returned undefined when probed with a random type. ' + ("Don't try to handle " + Wo.ActionTypes.INIT + ' or other actions in "redux/*" ') + "namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined.")
            })
        }

        function cI(e) {
            for (var t = Object.keys(e), n = {}, i = 0; i < t.length; i++) {
                var a = t[i];
                typeof e[a] == "function" && (n[a] = e[a])
            }
            var r = Object.keys(n);
            if (!1) var o;
            var s;
            try {
                sI(n)
            } catch (c) {
                s = c
            }
            return function() {
                var d = arguments.length <= 0 || arguments[0] === void 0 ? {} : arguments[0],
                    I = arguments[1];
                if (s) throw s;
                if (!1) var E;
                for (var p = !1, g = {}, v = 0; v < r.length; v++) {
                    var m = r[v],
                        h = n[m],
                        T = d[m],
                        A = h(T, I);
                    if (typeof A > "u") {
                        var b = oI(m, I);
                        throw new Error(b)
                    }
                    g[m] = A, p = p || A !== T
                }
                return p ? g : d
            }
        }
    });
    var jo = u(ki => {
        "use strict";
        ki.__esModule = !0;
        ki.default = uI;

        function Qo(e, t) {
            return function() {
                return t(e.apply(void 0, arguments))
            }
        }

        function uI(e, t) {
            if (typeof e == "function") return Qo(e, t);
            if (typeof e != "object" || e === null) throw new Error("bindActionCreators expected an object or a function, instead received " + (e === null ? "null" : typeof e) + '. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?');
            for (var n = Object.keys(e), i = {}, a = 0; a < n.length; a++) {
                var r = n[a],
                    o = e[r];
                typeof o == "function" && (i[r] = Qo(o, t))
            }
            return i
        }
    });
    var Bi = u(Xi => {
        "use strict";
        Xi.__esModule = !0;
        Xi.default = lI;

        function lI() {
            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            if (t.length === 0) return function(r) {
                return r
            };
            if (t.length === 1) return t[0];
            var i = t[t.length - 1],
                a = t.slice(0, -1);
            return function() {
                return a.reduceRight(function(r, o) {
                    return o(r)
                }, i.apply(void 0, arguments))
            }
        }
    });
    var Ko = u(Yi => {
        "use strict";
        Yi.__esModule = !0;
        var dI = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i])
            }
            return e
        };
        Yi.default = EI;
        var fI = Bi(),
            pI = gI(fI);

        function gI(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function EI() {
            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            return function(i) {
                return function(a, r, o) {
                    var s = i(a, r, o),
                        c = s.dispatch,
                        d = [],
                        I = {
                            getState: s.getState,
                            dispatch: function(p) {
                                return c(p)
                            }
                        };
                    return d = t.map(function(E) {
                        return E(I)
                    }), c = pI.default.apply(void 0, d)(s.dispatch), dI({}, s, {
                        dispatch: c
                    })
                }
            }
        }
    });
    var Wi = u(Pe => {
        "use strict";
        Pe.__esModule = !0;
        Pe.compose = Pe.applyMiddleware = Pe.bindActionCreators = Pe.combineReducers = Pe.createStore = void 0;
        var II = Vi(),
            yI = ht(II),
            TI = zo(),
            mI = ht(TI),
            vI = jo(),
            _I = ht(vI),
            OI = Ko(),
            hI = ht(OI),
            bI = Bi(),
            SI = ht(bI),
            AI = Gi(),
            n8 = ht(AI);

        function ht(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        Pe.createStore = yI.default;
        Pe.combineReducers = mI.default;
        Pe.bindActionCreators = _I.default;
        Pe.applyMiddleware = hI.default;
        Pe.compose = SI.default
    });
    var $o = u(Hi => {
        "use strict";
        Object.defineProperty(Hi, "__esModule", {
            value: !0
        });

        function RI(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        RI(Hi, {
            EventAppliesTo: function() {
                return NI
            },
            EventBasedOn: function() {
                return CI
            },
            EventContinuousMouseAxes: function() {
                return wI
            },
            EventLimitAffectedElements: function() {
                return PI
            },
            EventTypeConsts: function() {
                return LI
            },
            QuickEffectDirectionConsts: function() {
                return xI
            },
            QuickEffectIds: function() {
                return MI
            }
        });
        var LI = {
                NAVBAR_OPEN: "NAVBAR_OPEN",
                NAVBAR_CLOSE: "NAVBAR_CLOSE",
                TAB_ACTIVE: "TAB_ACTIVE",
                TAB_INACTIVE: "TAB_INACTIVE",
                SLIDER_ACTIVE: "SLIDER_ACTIVE",
                SLIDER_INACTIVE: "SLIDER_INACTIVE",
                DROPDOWN_OPEN: "DROPDOWN_OPEN",
                DROPDOWN_CLOSE: "DROPDOWN_CLOSE",
                MOUSE_CLICK: "MOUSE_CLICK",
                MOUSE_SECOND_CLICK: "MOUSE_SECOND_CLICK",
                MOUSE_DOWN: "MOUSE_DOWN",
                MOUSE_UP: "MOUSE_UP",
                MOUSE_OVER: "MOUSE_OVER",
                MOUSE_OUT: "MOUSE_OUT",
                MOUSE_MOVE: "MOUSE_MOVE",
                MOUSE_MOVE_IN_VIEWPORT: "MOUSE_MOVE_IN_VIEWPORT",
                SCROLL_INTO_VIEW: "SCROLL_INTO_VIEW",
                SCROLL_OUT_OF_VIEW: "SCROLL_OUT_OF_VIEW",
                SCROLLING_IN_VIEW: "SCROLLING_IN_VIEW",
                ECOMMERCE_CART_OPEN: "ECOMMERCE_CART_OPEN",
                ECOMMERCE_CART_CLOSE: "ECOMMERCE_CART_CLOSE",
                PAGE_START: "PAGE_START",
                PAGE_FINISH: "PAGE_FINISH",
                PAGE_SCROLL_UP: "PAGE_SCROLL_UP",
                PAGE_SCROLL_DOWN: "PAGE_SCROLL_DOWN",
                PAGE_SCROLL: "PAGE_SCROLL"
            },
            NI = {
                ELEMENT: "ELEMENT",
                CLASS: "CLASS",
                PAGE: "PAGE"
            },
            CI = {
                ELEMENT: "ELEMENT",
                VIEWPORT: "VIEWPORT"
            },
            wI = {
                X_AXIS: "X_AXIS",
                Y_AXIS: "Y_AXIS"
            },
            PI = {
                CHILDREN: "CHILDREN",
                SIBLINGS: "SIBLINGS",
                IMMEDIATE_CHILDREN: "IMMEDIATE_CHILDREN"
            },
            MI = {
                FADE_EFFECT: "FADE_EFFECT",
                SLIDE_EFFECT: "SLIDE_EFFECT",
                GROW_EFFECT: "GROW_EFFECT",
                SHRINK_EFFECT: "SHRINK_EFFECT",
                SPIN_EFFECT: "SPIN_EFFECT",
                FLY_EFFECT: "FLY_EFFECT",
                POP_EFFECT: "POP_EFFECT",
                FLIP_EFFECT: "FLIP_EFFECT",
                JIGGLE_EFFECT: "JIGGLE_EFFECT",
                PULSE_EFFECT: "PULSE_EFFECT",
                DROP_EFFECT: "DROP_EFFECT",
                BLINK_EFFECT: "BLINK_EFFECT",
                BOUNCE_EFFECT: "BOUNCE_EFFECT",
                FLIP_LEFT_TO_RIGHT_EFFECT: "FLIP_LEFT_TO_RIGHT_EFFECT",
                FLIP_RIGHT_TO_LEFT_EFFECT: "FLIP_RIGHT_TO_LEFT_EFFECT",
                RUBBER_BAND_EFFECT: "RUBBER_BAND_EFFECT",
                JELLO_EFFECT: "JELLO_EFFECT",
                GROW_BIG_EFFECT: "GROW_BIG_EFFECT",
                SHRINK_BIG_EFFECT: "SHRINK_BIG_EFFECT",
                PLUGIN_LOTTIE_EFFECT: "PLUGIN_LOTTIE_EFFECT"
            },
            xI = {
                LEFT: "LEFT",
                RIGHT: "RIGHT",
                BOTTOM: "BOTTOM",
                TOP: "TOP",
                BOTTOM_LEFT: "BOTTOM_LEFT",
                BOTTOM_RIGHT: "BOTTOM_RIGHT",
                TOP_RIGHT: "TOP_RIGHT",
                TOP_LEFT: "TOP_LEFT",
                CLOCKWISE: "CLOCKWISE",
                COUNTER_CLOCKWISE: "COUNTER_CLOCKWISE"
            }
    });
    var Qi = u(zi => {
        "use strict";
        Object.defineProperty(zi, "__esModule", {
            value: !0
        });

        function FI(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        FI(zi, {
            ActionAppliesTo: function() {
                return VI
            },
            ActionTypeConsts: function() {
                return DI
            }
        });
        var DI = {
                TRANSFORM_MOVE: "TRANSFORM_MOVE",
                TRANSFORM_SCALE: "TRANSFORM_SCALE",
                TRANSFORM_ROTATE: "TRANSFORM_ROTATE",
                TRANSFORM_SKEW: "TRANSFORM_SKEW",
                STYLE_OPACITY: "STYLE_OPACITY",
                STYLE_SIZE: "STYLE_SIZE",
                STYLE_FILTER: "STYLE_FILTER",
                STYLE_FONT_VARIATION: "STYLE_FONT_VARIATION",
                STYLE_BACKGROUND_COLOR: "STYLE_BACKGROUND_COLOR",
                STYLE_BORDER: "STYLE_BORDER",
                STYLE_TEXT_COLOR: "STYLE_TEXT_COLOR",
                OBJECT_VALUE: "OBJECT_VALUE",
                PLUGIN_LOTTIE: "PLUGIN_LOTTIE",
                PLUGIN_SPLINE: "PLUGIN_SPLINE",
                PLUGIN_RIVE: "PLUGIN_RIVE",
                PLUGIN_VARIABLE: "PLUGIN_VARIABLE",
                GENERAL_DISPLAY: "GENERAL_DISPLAY",
                GENERAL_START_ACTION: "GENERAL_START_ACTION",
                GENERAL_CONTINUOUS_ACTION: "GENERAL_CONTINUOUS_ACTION",
                GENERAL_COMBO_CLASS: "GENERAL_COMBO_CLASS",
                GENERAL_STOP_ACTION: "GENERAL_STOP_ACTION",
                GENERAL_LOOP: "GENERAL_LOOP",
                STYLE_BOX_SHADOW: "STYLE_BOX_SHADOW"
            },
            VI = {
                ELEMENT: "ELEMENT",
                ELEMENT_CLASS: "ELEMENT_CLASS",
                TRIGGER_ELEMENT: "TRIGGER_ELEMENT"
            }
    });
    var Zo = u(ji => {
        "use strict";
        Object.defineProperty(ji, "__esModule", {
            value: !0
        });
        Object.defineProperty(ji, "InteractionTypeConsts", {
            enumerable: !0,
            get: function() {
                return UI
            }
        });
        var UI = {
            MOUSE_CLICK_INTERACTION: "MOUSE_CLICK_INTERACTION",
            MOUSE_HOVER_INTERACTION: "MOUSE_HOVER_INTERACTION",
            MOUSE_MOVE_INTERACTION: "MOUSE_MOVE_INTERACTION",
            SCROLL_INTO_VIEW_INTERACTION: "SCROLL_INTO_VIEW_INTERACTION",
            SCROLLING_IN_VIEW_INTERACTION: "SCROLLING_IN_VIEW_INTERACTION",
            MOUSE_MOVE_IN_VIEWPORT_INTERACTION: "MOUSE_MOVE_IN_VIEWPORT_INTERACTION",
            PAGE_IS_SCROLLING_INTERACTION: "PAGE_IS_SCROLLING_INTERACTION",
            PAGE_LOAD_INTERACTION: "PAGE_LOAD_INTERACTION",
            PAGE_SCROLLED_INTERACTION: "PAGE_SCROLLED_INTERACTION",
            NAVBAR_INTERACTION: "NAVBAR_INTERACTION",
            DROPDOWN_INTERACTION: "DROPDOWN_INTERACTION",
            ECOMMERCE_CART_INTERACTION: "ECOMMERCE_CART_INTERACTION",
            TAB_INTERACTION: "TAB_INTERACTION",
            SLIDER_INTERACTION: "SLIDER_INTERACTION"
        }
    });
    var Jo = u(Ki => {
        "use strict";
        Object.defineProperty(Ki, "__esModule", {
            value: !0
        });
        Object.defineProperty(Ki, "ReducedMotionTypes", {
            enumerable: !0,
            get: function() {
                return zI
            }
        });
        var GI = Qi(),
            {
                TRANSFORM_MOVE: qI,
                TRANSFORM_SCALE: kI,
                TRANSFORM_ROTATE: XI,
                TRANSFORM_SKEW: BI,
                STYLE_SIZE: YI,
                STYLE_FILTER: WI,
                STYLE_FONT_VARIATION: HI
            } = GI.ActionTypeConsts,
            zI = {
                [qI]: !0,
                [kI]: !0,
                [XI]: !0,
                [BI]: !0,
                [YI]: !0,
                [WI]: !0,
                [HI]: !0
            }
    });
    var es = u($i => {
        "use strict";
        Object.defineProperty($i, "__esModule", {
            value: !0
        });

        function QI(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        QI($i, {
            IX2_ACTION_LIST_PLAYBACK_CHANGED: function() {
                return dy
            },
            IX2_ANIMATION_FRAME_CHANGED: function() {
                return ay
            },
            IX2_CLEAR_REQUESTED: function() {
                return ny
            },
            IX2_ELEMENT_STATE_CHANGED: function() {
                return ly
            },
            IX2_EVENT_LISTENER_ADDED: function() {
                return iy
            },
            IX2_EVENT_STATE_CHANGED: function() {
                return ry
            },
            IX2_INSTANCE_ADDED: function() {
                return sy
            },
            IX2_INSTANCE_REMOVED: function() {
                return uy
            },
            IX2_INSTANCE_STARTED: function() {
                return cy
            },
            IX2_MEDIA_QUERIES_DEFINED: function() {
                return py
            },
            IX2_PARAMETER_CHANGED: function() {
                return oy
            },
            IX2_PLAYBACK_REQUESTED: function() {
                return ey
            },
            IX2_PREVIEW_REQUESTED: function() {
                return JI
            },
            IX2_RAW_DATA_IMPORTED: function() {
                return jI
            },
            IX2_SESSION_INITIALIZED: function() {
                return KI
            },
            IX2_SESSION_STARTED: function() {
                return $I
            },
            IX2_SESSION_STOPPED: function() {
                return ZI
            },
            IX2_STOP_REQUESTED: function() {
                return ty
            },
            IX2_TEST_FRAME_RENDERED: function() {
                return gy
            },
            IX2_VIEWPORT_WIDTH_CHANGED: function() {
                return fy
            }
        });
        var jI = "IX2_RAW_DATA_IMPORTED",
            KI = "IX2_SESSION_INITIALIZED",
            $I = "IX2_SESSION_STARTED",
            ZI = "IX2_SESSION_STOPPED",
            JI = "IX2_PREVIEW_REQUESTED",
            ey = "IX2_PLAYBACK_REQUESTED",
            ty = "IX2_STOP_REQUESTED",
            ny = "IX2_CLEAR_REQUESTED",
            iy = "IX2_EVENT_LISTENER_ADDED",
            ry = "IX2_EVENT_STATE_CHANGED",
            ay = "IX2_ANIMATION_FRAME_CHANGED",
            oy = "IX2_PARAMETER_CHANGED",
            sy = "IX2_INSTANCE_ADDED",
            cy = "IX2_INSTANCE_STARTED",
            uy = "IX2_INSTANCE_REMOVED",
            ly = "IX2_ELEMENT_STATE_CHANGED",
            dy = "IX2_ACTION_LIST_PLAYBACK_CHANGED",
            fy = "IX2_VIEWPORT_WIDTH_CHANGED",
            py = "IX2_MEDIA_QUERIES_DEFINED",
            gy = "IX2_TEST_FRAME_RENDERED"
    });
    var ts = u(Zi => {
        "use strict";
        Object.defineProperty(Zi, "__esModule", {
            value: !0
        });

        function Ey(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        Ey(Zi, {
            ABSTRACT_NODE: function() {
                return pT
            },
            AUTO: function() {
                return nT
            },
            BACKGROUND: function() {
                return Ky
            },
            BACKGROUND_COLOR: function() {
                return jy
            },
            BAR_DELIMITER: function() {
                return aT
            },
            BORDER_COLOR: function() {
                return $y
            },
            BOUNDARY_SELECTOR: function() {
                return vy
            },
            CHILDREN: function() {
                return oT
            },
            COLON_DELIMITER: function() {
                return rT
            },
            COLOR: function() {
                return Zy
            },
            COMMA_DELIMITER: function() {
                return iT
            },
            CONFIG_UNIT: function() {
                return Ly
            },
            CONFIG_VALUE: function() {
                return by
            },
            CONFIG_X_UNIT: function() {
                return Sy
            },
            CONFIG_X_VALUE: function() {
                return _y
            },
            CONFIG_Y_UNIT: function() {
                return Ay
            },
            CONFIG_Y_VALUE: function() {
                return Oy
            },
            CONFIG_Z_UNIT: function() {
                return Ry
            },
            CONFIG_Z_VALUE: function() {
                return hy
            },
            DISPLAY: function() {
                return Jy
            },
            FILTER: function() {
                return Wy
            },
            FLEX: function() {
                return eT
            },
            FONT_VARIATION_SETTINGS: function() {
                return Hy
            },
            HEIGHT: function() {
                return Qy
            },
            HTML_ELEMENT: function() {
                return dT
            },
            IMMEDIATE_CHILDREN: function() {
                return sT
            },
            IX2_ID_DELIMITER: function() {
                return Iy
            },
            OPACITY: function() {
                return Yy
            },
            PARENT: function() {
                return uT
            },
            PLAIN_OBJECT: function() {
                return fT
            },
            PRESERVE_3D: function() {
                return lT
            },
            RENDER_GENERAL: function() {
                return ET
            },
            RENDER_PLUGIN: function() {
                return yT
            },
            RENDER_STYLE: function() {
                return IT
            },
            RENDER_TRANSFORM: function() {
                return gT
            },
            ROTATE_X: function() {
                return Uy
            },
            ROTATE_Y: function() {
                return Gy
            },
            ROTATE_Z: function() {
                return qy
            },
            SCALE_3D: function() {
                return Vy
            },
            SCALE_X: function() {
                return xy
            },
            SCALE_Y: function() {
                return Fy
            },
            SCALE_Z: function() {
                return Dy
            },
            SIBLINGS: function() {
                return cT
            },
            SKEW: function() {
                return ky
            },
            SKEW_X: function() {
                return Xy
            },
            SKEW_Y: function() {
                return By
            },
            TRANSFORM: function() {
                return Ny
            },
            TRANSLATE_3D: function() {
                return My
            },
            TRANSLATE_X: function() {
                return Cy
            },
            TRANSLATE_Y: function() {
                return wy
            },
            TRANSLATE_Z: function() {
                return Py
            },
            WF_PAGE: function() {
                return yy
            },
            WIDTH: function() {
                return zy
            },
            WILL_CHANGE: function() {
                return tT
            },
            W_MOD_IX: function() {
                return my
            },
            W_MOD_JS: function() {
                return Ty
            }
        });
        var Iy = "|",
            yy = "data-wf-page",
            Ty = "w-mod-js",
            my = "w-mod-ix",
            vy = ".w-dyn-item",
            _y = "xValue",
            Oy = "yValue",
            hy = "zValue",
            by = "value",
            Sy = "xUnit",
            Ay = "yUnit",
            Ry = "zUnit",
            Ly = "unit",
            Ny = "transform",
            Cy = "translateX",
            wy = "translateY",
            Py = "translateZ",
            My = "translate3d",
            xy = "scaleX",
            Fy = "scaleY",
            Dy = "scaleZ",
            Vy = "scale3d",
            Uy = "rotateX",
            Gy = "rotateY",
            qy = "rotateZ",
            ky = "skew",
            Xy = "skewX",
            By = "skewY",
            Yy = "opacity",
            Wy = "filter",
            Hy = "font-variation-settings",
            zy = "width",
            Qy = "height",
            jy = "backgroundColor",
            Ky = "background",
            $y = "borderColor",
            Zy = "color",
            Jy = "display",
            eT = "flex",
            tT = "willChange",
            nT = "AUTO",
            iT = ",",
            rT = ":",
            aT = "|",
            oT = "CHILDREN",
            sT = "IMMEDIATE_CHILDREN",
            cT = "SIBLINGS",
            uT = "PARENT",
            lT = "preserve-3d",
            dT = "HTML_ELEMENT",
            fT = "PLAIN_OBJECT",
            pT = "ABSTRACT_NODE",
            gT = "RENDER_TRANSFORM",
            ET = "RENDER_GENERAL",
            IT = "RENDER_STYLE",
            yT = "RENDER_PLUGIN"
    });
    var Re = u(ut => {
        "use strict";
        Object.defineProperty(ut, "__esModule", {
            value: !0
        });

        function TT(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        TT(ut, {
            ActionTypeConsts: function() {
                return vT.ActionTypeConsts
            },
            IX2EngineActionTypes: function() {
                return _T
            },
            IX2EngineConstants: function() {
                return OT
            },
            QuickEffectIds: function() {
                return mT.QuickEffectIds
            }
        });
        var mT = mn($o(), ut),
            vT = mn(Qi(), ut);
        mn(Zo(), ut);
        mn(Jo(), ut);
        var _T = is(es()),
            OT = is(ts());

        function mn(e, t) {
            return Object.keys(e).forEach(function(n) {
                n !== "default" && !Object.prototype.hasOwnProperty.call(t, n) && Object.defineProperty(t, n, {
                    enumerable: !0,
                    get: function() {
                        return e[n]
                    }
                })
            }), e
        }

        function ns(e) {
            if (typeof WeakMap != "function") return null;
            var t = new WeakMap,
                n = new WeakMap;
            return (ns = function(i) {
                return i ? n : t
            })(e)
        }

        function is(e, t) {
            if (!t && e && e.__esModule) return e;
            if (e === null || typeof e != "object" && typeof e != "function") return {
                default: e
            };
            var n = ns(t);
            if (n && n.has(e)) return n.get(e);
            var i = {
                    __proto__: null
                },
                a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var r in e)
                if (r !== "default" && Object.prototype.hasOwnProperty.call(e, r)) {
                    var o = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    o && (o.get || o.set) ? Object.defineProperty(i, r, o) : i[r] = e[r]
                }
            return i.default = e, n && n.set(e, i), i
        }
    });
    var rs = u(Ji => {
        "use strict";
        Object.defineProperty(Ji, "__esModule", {
            value: !0
        });
        Object.defineProperty(Ji, "ixData", {
            enumerable: !0,
            get: function() {
                return ST
            }
        });
        var hT = Re(),
            {
                IX2_RAW_DATA_IMPORTED: bT
            } = hT.IX2EngineActionTypes,
            ST = (e = Object.freeze({}), t) => {
                switch (t.type) {
                    case bT:
                        return t.payload.ixData || Object.freeze({});
                    default:
                        return e
                }
            }
    });
    var bt = u(ge => {
        "use strict";
        Object.defineProperty(ge, "__esModule", {
            value: !0
        });
        var AT = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
            return typeof e
        } : function(e) {
            return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        };
        ge.clone = _n;
        ge.addLast = ss;
        ge.addFirst = cs;
        ge.removeLast = us;
        ge.removeFirst = ls;
        ge.insert = ds;
        ge.removeAt = fs;
        ge.replaceAt = ps;
        ge.getIn = On;
        ge.set = hn;
        ge.setIn = bn;
        ge.update = Es;
        ge.updateIn = Is;
        ge.merge = ys;
        ge.mergeDeep = Ts;
        ge.mergeIn = ms;
        ge.omit = vs;
        ge.addDefaults = _s;
        var as = "INVALID_ARGS";

        function os(e) {
            throw new Error(e)
        }

        function er(e) {
            var t = Object.keys(e);
            return Object.getOwnPropertySymbols ? t.concat(Object.getOwnPropertySymbols(e)) : t
        }
        var RT = {}.hasOwnProperty;

        function _n(e) {
            if (Array.isArray(e)) return e.slice();
            for (var t = er(e), n = {}, i = 0; i < t.length; i++) {
                var a = t[i];
                n[a] = e[a]
            }
            return n
        }

        function Le(e, t, n) {
            var i = n;
            i == null && os(as);
            for (var a = !1, r = arguments.length, o = Array(r > 3 ? r - 3 : 0), s = 3; s < r; s++) o[s - 3] = arguments[s];
            for (var c = 0; c < o.length; c++) {
                var d = o[c];
                if (d != null) {
                    var I = er(d);
                    if (I.length)
                        for (var E = 0; E <= I.length; E++) {
                            var p = I[E];
                            if (!(e && i[p] !== void 0)) {
                                var g = d[p];
                                t && vn(i[p]) && vn(g) && (g = Le(e, t, i[p], g)), !(g === void 0 || g === i[p]) && (a || (a = !0, i = _n(i)), i[p] = g)
                            }
                        }
                }
            }
            return i
        }

        function vn(e) {
            var t = typeof e > "u" ? "undefined" : AT(e);
            return e != null && (t === "object" || t === "function")
        }

        function ss(e, t) {
            return Array.isArray(t) ? e.concat(t) : e.concat([t])
        }

        function cs(e, t) {
            return Array.isArray(t) ? t.concat(e) : [t].concat(e)
        }

        function us(e) {
            return e.length ? e.slice(0, e.length - 1) : e
        }

        function ls(e) {
            return e.length ? e.slice(1) : e
        }

        function ds(e, t, n) {
            return e.slice(0, t).concat(Array.isArray(n) ? n : [n]).concat(e.slice(t))
        }

        function fs(e, t) {
            return t >= e.length || t < 0 ? e : e.slice(0, t).concat(e.slice(t + 1))
        }

        function ps(e, t, n) {
            if (e[t] === n) return e;
            for (var i = e.length, a = Array(i), r = 0; r < i; r++) a[r] = e[r];
            return a[t] = n, a
        }

        function On(e, t) {
            if (!Array.isArray(t) && os(as), e != null) {
                for (var n = e, i = 0; i < t.length; i++) {
                    var a = t[i];
                    if (n = n ? .[a], n === void 0) return n
                }
                return n
            }
        }

        function hn(e, t, n) {
            var i = typeof t == "number" ? [] : {},
                a = e ? ? i;
            if (a[t] === n) return a;
            var r = _n(a);
            return r[t] = n, r
        }

        function gs(e, t, n, i) {
            var a = void 0,
                r = t[i];
            if (i === t.length - 1) a = n;
            else {
                var o = vn(e) && vn(e[r]) ? e[r] : typeof t[i + 1] == "number" ? [] : {};
                a = gs(o, t, n, i + 1)
            }
            return hn(e, r, a)
        }

        function bn(e, t, n) {
            return t.length ? gs(e, t, n, 0) : n
        }

        function Es(e, t, n) {
            var i = e ? .[t],
                a = n(i);
            return hn(e, t, a)
        }

        function Is(e, t, n) {
            var i = On(e, t),
                a = n(i);
            return bn(e, t, a)
        }

        function ys(e, t, n, i, a, r) {
            for (var o = arguments.length, s = Array(o > 6 ? o - 6 : 0), c = 6; c < o; c++) s[c - 6] = arguments[c];
            return s.length ? Le.call.apply(Le, [null, !1, !1, e, t, n, i, a, r].concat(s)) : Le(!1, !1, e, t, n, i, a, r)
        }

        function Ts(e, t, n, i, a, r) {
            for (var o = arguments.length, s = Array(o > 6 ? o - 6 : 0), c = 6; c < o; c++) s[c - 6] = arguments[c];
            return s.length ? Le.call.apply(Le, [null, !1, !0, e, t, n, i, a, r].concat(s)) : Le(!1, !0, e, t, n, i, a, r)
        }

        function ms(e, t, n, i, a, r, o) {
            var s = On(e, t);
            s == null && (s = {});
            for (var c = void 0, d = arguments.length, I = Array(d > 7 ? d - 7 : 0), E = 7; E < d; E++) I[E - 7] = arguments[E];
            return I.length ? c = Le.call.apply(Le, [null, !1, !1, s, n, i, a, r, o].concat(I)) : c = Le(!1, !1, s, n, i, a, r, o), bn(e, t, c)
        }

        function vs(e, t) {
            for (var n = Array.isArray(t) ? t : [t], i = !1, a = 0; a < n.length; a++)
                if (RT.call(e, n[a])) {
                    i = !0;
                    break
                }
            if (!i) return e;
            for (var r = {}, o = er(e), s = 0; s < o.length; s++) {
                var c = o[s];
                n.indexOf(c) >= 0 || (r[c] = e[c])
            }
            return r
        }

        function _s(e, t, n, i, a, r) {
            for (var o = arguments.length, s = Array(o > 6 ? o - 6 : 0), c = 6; c < o; c++) s[c - 6] = arguments[c];
            return s.length ? Le.call.apply(Le, [null, !0, !1, e, t, n, i, a, r].concat(s)) : Le(!0, !1, e, t, n, i, a, r)
        }
        var LT = {
            clone: _n,
            addLast: ss,
            addFirst: cs,
            removeLast: us,
            removeFirst: ls,
            insert: ds,
            removeAt: fs,
            replaceAt: ps,
            getIn: On,
            set: hn,
            setIn: bn,
            update: Es,
            updateIn: Is,
            merge: ys,
            mergeDeep: Ts,
            mergeIn: ms,
            omit: vs,
            addDefaults: _s
        };
        ge.default = LT
    });
    var hs = u(tr => {
        "use strict";
        Object.defineProperty(tr, "__esModule", {
            value: !0
        });
        Object.defineProperty(tr, "ixRequest", {
            enumerable: !0,
            get: function() {
                return DT
            }
        });
        var NT = Re(),
            CT = bt(),
            {
                IX2_PREVIEW_REQUESTED: wT,
                IX2_PLAYBACK_REQUESTED: PT,
                IX2_STOP_REQUESTED: MT,
                IX2_CLEAR_REQUESTED: xT
            } = NT.IX2EngineActionTypes,
            FT = {
                preview: {},
                playback: {},
                stop: {},
                clear: {}
            },
            Os = Object.create(null, {
                [wT]: {
                    value: "preview"
                },
                [PT]: {
                    value: "playback"
                },
                [MT]: {
                    value: "stop"
                },
                [xT]: {
                    value: "clear"
                }
            }),
            DT = (e = FT, t) => {
                if (t.type in Os) {
                    let n = [Os[t.type]];
                    return (0, CT.setIn)(e, [n], { ...t.payload
                    })
                }
                return e
            }
    });
    var Ss = u(nr => {
        "use strict";
        Object.defineProperty(nr, "__esModule", {
            value: !0
        });
        Object.defineProperty(nr, "ixSession", {
            enumerable: !0,
            get: function() {
                return jT
            }
        });
        var VT = Re(),
            Be = bt(),
            {
                IX2_SESSION_INITIALIZED: UT,
                IX2_SESSION_STARTED: GT,
                IX2_TEST_FRAME_RENDERED: qT,
                IX2_SESSION_STOPPED: kT,
                IX2_EVENT_LISTENER_ADDED: XT,
                IX2_EVENT_STATE_CHANGED: BT,
                IX2_ANIMATION_FRAME_CHANGED: YT,
                IX2_ACTION_LIST_PLAYBACK_CHANGED: WT,
                IX2_VIEWPORT_WIDTH_CHANGED: HT,
                IX2_MEDIA_QUERIES_DEFINED: zT
            } = VT.IX2EngineActionTypes,
            bs = {
                active: !1,
                tick: 0,
                eventListeners: [],
                eventState: {},
                playbackState: {},
                viewportWidth: 0,
                mediaQueryKey: null,
                hasBoundaryNodes: !1,
                hasDefinedMediaQueries: !1,
                reducedMotion: !1
            },
            QT = 20,
            jT = (e = bs, t) => {
                switch (t.type) {
                    case UT:
                        {
                            let {
                                hasBoundaryNodes: n,
                                reducedMotion: i
                            } = t.payload;
                            return (0, Be.merge)(e, {
                                hasBoundaryNodes: n,
                                reducedMotion: i
                            })
                        }
                    case GT:
                        return (0, Be.set)(e, "active", !0);
                    case qT:
                        {
                            let {
                                payload: {
                                    step: n = QT
                                }
                            } = t;
                            return (0, Be.set)(e, "tick", e.tick + n)
                        }
                    case kT:
                        return bs;
                    case YT:
                        {
                            let {
                                payload: {
                                    now: n
                                }
                            } = t;
                            return (0, Be.set)(e, "tick", n)
                        }
                    case XT:
                        {
                            let n = (0, Be.addLast)(e.eventListeners, t.payload);
                            return (0, Be.set)(e, "eventListeners", n)
                        }
                    case BT:
                        {
                            let {
                                stateKey: n,
                                newState: i
                            } = t.payload;
                            return (0, Be.setIn)(e, ["eventState", n], i)
                        }
                    case WT:
                        {
                            let {
                                actionListId: n,
                                isPlaying: i
                            } = t.payload;
                            return (0, Be.setIn)(e, ["playbackState", n], i)
                        }
                    case HT:
                        {
                            let {
                                width: n,
                                mediaQueries: i
                            } = t.payload,
                            a = i.length,
                            r = null;
                            for (let o = 0; o < a; o++) {
                                let {
                                    key: s,
                                    min: c,
                                    max: d
                                } = i[o];
                                if (n >= c && n <= d) {
                                    r = s;
                                    break
                                }
                            }
                            return (0, Be.merge)(e, {
                                viewportWidth: n,
                                mediaQueryKey: r
                            })
                        }
                    case zT:
                        return (0, Be.set)(e, "hasDefinedMediaQueries", !0);
                    default:
                        return e
                }
            }
    });
    var Rs = u((E8, As) => {
        function KT() {
            this.__data__ = [], this.size = 0
        }
        As.exports = KT
    });
    var Sn = u((I8, Ls) => {
        function $T(e, t) {
            return e === t || e !== e && t !== t
        }
        Ls.exports = $T
    });
    var Ht = u((y8, Ns) => {
        var ZT = Sn();

        function JT(e, t) {
            for (var n = e.length; n--;)
                if (ZT(e[n][0], t)) return n;
            return -1
        }
        Ns.exports = JT
    });
    var ws = u((T8, Cs) => {
        var em = Ht(),
            tm = Array.prototype,
            nm = tm.splice;

        function im(e) {
            var t = this.__data__,
                n = em(t, e);
            if (n < 0) return !1;
            var i = t.length - 1;
            return n == i ? t.pop() : nm.call(t, n, 1), --this.size, !0
        }
        Cs.exports = im
    });
    var Ms = u((m8, Ps) => {
        var rm = Ht();

        function am(e) {
            var t = this.__data__,
                n = rm(t, e);
            return n < 0 ? void 0 : t[n][1]
        }
        Ps.exports = am
    });
    var Fs = u((v8, xs) => {
        var om = Ht();

        function sm(e) {
            return om(this.__data__, e) > -1
        }
        xs.exports = sm
    });
    var Vs = u((_8, Ds) => {
        var cm = Ht();

        function um(e, t) {
            var n = this.__data__,
                i = cm(n, e);
            return i < 0 ? (++this.size, n.push([e, t])) : n[i][1] = t, this
        }
        Ds.exports = um
    });
    var zt = u((O8, Us) => {
        var lm = Rs(),
            dm = ws(),
            fm = Ms(),
            pm = Fs(),
            gm = Vs();

        function St(e) {
            var t = -1,
                n = e == null ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var i = e[t];
                this.set(i[0], i[1])
            }
        }
        St.prototype.clear = lm;
        St.prototype.delete = dm;
        St.prototype.get = fm;
        St.prototype.has = pm;
        St.prototype.set = gm;
        Us.exports = St
    });
    var qs = u((h8, Gs) => {
        var Em = zt();

        function Im() {
            this.__data__ = new Em, this.size = 0
        }
        Gs.exports = Im
    });
    var Xs = u((b8, ks) => {
        function ym(e) {
            var t = this.__data__,
                n = t.delete(e);
            return this.size = t.size, n
        }
        ks.exports = ym
    });
    var Ys = u((S8, Bs) => {
        function Tm(e) {
            return this.__data__.get(e)
        }
        Bs.exports = Tm
    });
    var Hs = u((A8, Ws) => {
        function mm(e) {
            return this.__data__.has(e)
        }
        Ws.exports = mm
    });
    var Ye = u((R8, zs) => {
        function vm(e) {
            var t = typeof e;
            return e != null && (t == "object" || t == "function")
        }
        zs.exports = vm
    });
    var ir = u((L8, Qs) => {
        var _m = tt(),
            Om = Ye(),
            hm = "[object AsyncFunction]",
            bm = "[object Function]",
            Sm = "[object GeneratorFunction]",
            Am = "[object Proxy]";

        function Rm(e) {
            if (!Om(e)) return !1;
            var t = _m(e);
            return t == bm || t == Sm || t == hm || t == Am
        }
        Qs.exports = Rm
    });
    var Ks = u((N8, js) => {
        var Lm = Ge(),
            Nm = Lm["__core-js_shared__"];
        js.exports = Nm
    });
    var Js = u((C8, Zs) => {
        var rr = Ks(),
            $s = function() {
                var e = /[^.]+$/.exec(rr && rr.keys && rr.keys.IE_PROTO || "");
                return e ? "Symbol(src)_1." + e : ""
            }();

        function Cm(e) {
            return !!$s && $s in e
        }
        Zs.exports = Cm
    });
    var ar = u((w8, ec) => {
        var wm = Function.prototype,
            Pm = wm.toString;

        function Mm(e) {
            if (e != null) {
                try {
                    return Pm.call(e)
                } catch {}
                try {
                    return e + ""
                } catch {}
            }
            return ""
        }
        ec.exports = Mm
    });
    var nc = u((P8, tc) => {
        var xm = ir(),
            Fm = Js(),
            Dm = Ye(),
            Vm = ar(),
            Um = /[\\^$.*+?()[\]{}|]/g,
            Gm = /^\[object .+?Constructor\]$/,
            qm = Function.prototype,
            km = Object.prototype,
            Xm = qm.toString,
            Bm = km.hasOwnProperty,
            Ym = RegExp("^" + Xm.call(Bm).replace(Um, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

        function Wm(e) {
            if (!Dm(e) || Fm(e)) return !1;
            var t = xm(e) ? Ym : Gm;
            return t.test(Vm(e))
        }
        tc.exports = Wm
    });
    var rc = u((M8, ic) => {
        function Hm(e, t) {
            return e ? .[t]
        }
        ic.exports = Hm
    });
    var nt = u((x8, ac) => {
        var zm = nc(),
            Qm = rc();

        function jm(e, t) {
            var n = Qm(e, t);
            return zm(n) ? n : void 0
        }
        ac.exports = jm
    });
    var An = u((F8, oc) => {
        var Km = nt(),
            $m = Ge(),
            Zm = Km($m, "Map");
        oc.exports = Zm
    });
    var Qt = u((D8, sc) => {
        var Jm = nt(),
            ev = Jm(Object, "create");
        sc.exports = ev
    });
    var lc = u((V8, uc) => {
        var cc = Qt();

        function tv() {
            this.__data__ = cc ? cc(null) : {}, this.size = 0
        }
        uc.exports = tv
    });
    var fc = u((U8, dc) => {
        function nv(e) {
            var t = this.has(e) && delete this.__data__[e];
            return this.size -= t ? 1 : 0, t
        }
        dc.exports = nv
    });
    var gc = u((G8, pc) => {
        var iv = Qt(),
            rv = "__lodash_hash_undefined__",
            av = Object.prototype,
            ov = av.hasOwnProperty;

        function sv(e) {
            var t = this.__data__;
            if (iv) {
                var n = t[e];
                return n === rv ? void 0 : n
            }
            return ov.call(t, e) ? t[e] : void 0
        }
        pc.exports = sv
    });
    var Ic = u((q8, Ec) => {
        var cv = Qt(),
            uv = Object.prototype,
            lv = uv.hasOwnProperty;

        function dv(e) {
            var t = this.__data__;
            return cv ? t[e] !== void 0 : lv.call(t, e)
        }
        Ec.exports = dv
    });
    var Tc = u((k8, yc) => {
        var fv = Qt(),
            pv = "__lodash_hash_undefined__";

        function gv(e, t) {
            var n = this.__data__;
            return this.size += this.has(e) ? 0 : 1, n[e] = fv && t === void 0 ? pv : t, this
        }
        yc.exports = gv
    });
    var vc = u((X8, mc) => {
        var Ev = lc(),
            Iv = fc(),
            yv = gc(),
            Tv = Ic(),
            mv = Tc();

        function At(e) {
            var t = -1,
                n = e == null ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var i = e[t];
                this.set(i[0], i[1])
            }
        }
        At.prototype.clear = Ev;
        At.prototype.delete = Iv;
        At.prototype.get = yv;
        At.prototype.has = Tv;
        At.prototype.set = mv;
        mc.exports = At
    });
    var hc = u((B8, Oc) => {
        var _c = vc(),
            vv = zt(),
            _v = An();

        function Ov() {
            this.size = 0, this.__data__ = {
                hash: new _c,
                map: new(_v || vv),
                string: new _c
            }
        }
        Oc.exports = Ov
    });
    var Sc = u((Y8, bc) => {
        function hv(e) {
            var t = typeof e;
            return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null
        }
        bc.exports = hv
    });
    var jt = u((W8, Ac) => {
        var bv = Sc();

        function Sv(e, t) {
            var n = e.__data__;
            return bv(t) ? n[typeof t == "string" ? "string" : "hash"] : n.map
        }
        Ac.exports = Sv
    });
    var Lc = u((H8, Rc) => {
        var Av = jt();

        function Rv(e) {
            var t = Av(this, e).delete(e);
            return this.size -= t ? 1 : 0, t
        }
        Rc.exports = Rv
    });
    var Cc = u((z8, Nc) => {
        var Lv = jt();

        function Nv(e) {
            return Lv(this, e).get(e)
        }
        Nc.exports = Nv
    });
    var Pc = u((Q8, wc) => {
        var Cv = jt();

        function wv(e) {
            return Cv(this, e).has(e)
        }
        wc.exports = wv
    });
    var xc = u((j8, Mc) => {
        var Pv = jt();

        function Mv(e, t) {
            var n = Pv(this, e),
                i = n.size;
            return n.set(e, t), this.size += n.size == i ? 0 : 1, this
        }
        Mc.exports = Mv
    });
    var Rn = u((K8, Fc) => {
        var xv = hc(),
            Fv = Lc(),
            Dv = Cc(),
            Vv = Pc(),
            Uv = xc();

        function Rt(e) {
            var t = -1,
                n = e == null ? 0 : e.length;
            for (this.clear(); ++t < n;) {
                var i = e[t];
                this.set(i[0], i[1])
            }
        }
        Rt.prototype.clear = xv;
        Rt.prototype.delete = Fv;
        Rt.prototype.get = Dv;
        Rt.prototype.has = Vv;
        Rt.prototype.set = Uv;
        Fc.exports = Rt
    });
    var Vc = u(($8, Dc) => {
        var Gv = zt(),
            qv = An(),
            kv = Rn(),
            Xv = 200;

        function Bv(e, t) {
            var n = this.__data__;
            if (n instanceof Gv) {
                var i = n.__data__;
                if (!qv || i.length < Xv - 1) return i.push([e, t]), this.size = ++n.size, this;
                n = this.__data__ = new kv(i)
            }
            return n.set(e, t), this.size = n.size, this
        }
        Dc.exports = Bv
    });
    var or = u((Z8, Uc) => {
        var Yv = zt(),
            Wv = qs(),
            Hv = Xs(),
            zv = Ys(),
            Qv = Hs(),
            jv = Vc();

        function Lt(e) {
            var t = this.__data__ = new Yv(e);
            this.size = t.size
        }
        Lt.prototype.clear = Wv;
        Lt.prototype.delete = Hv;
        Lt.prototype.get = zv;
        Lt.prototype.has = Qv;
        Lt.prototype.set = jv;
        Uc.exports = Lt
    });
    var qc = u((J8, Gc) => {
        var Kv = "__lodash_hash_undefined__";

        function $v(e) {
            return this.__data__.set(e, Kv), this
        }
        Gc.exports = $v
    });
    var Xc = u((e4, kc) => {
        function Zv(e) {
            return this.__data__.has(e)
        }
        kc.exports = Zv
    });
    var Yc = u((t4, Bc) => {
        var Jv = Rn(),
            e_ = qc(),
            t_ = Xc();

        function Ln(e) {
            var t = -1,
                n = e == null ? 0 : e.length;
            for (this.__data__ = new Jv; ++t < n;) this.add(e[t])
        }
        Ln.prototype.add = Ln.prototype.push = e_;
        Ln.prototype.has = t_;
        Bc.exports = Ln
    });
    var Hc = u((n4, Wc) => {
        function n_(e, t) {
            for (var n = -1, i = e == null ? 0 : e.length; ++n < i;)
                if (t(e[n], n, e)) return !0;
            return !1
        }
        Wc.exports = n_
    });
    var Qc = u((i4, zc) => {
        function i_(e, t) {
            return e.has(t)
        }
        zc.exports = i_
    });
    var sr = u((r4, jc) => {
        var r_ = Yc(),
            a_ = Hc(),
            o_ = Qc(),
            s_ = 1,
            c_ = 2;

        function u_(e, t, n, i, a, r) {
            var o = n & s_,
                s = e.length,
                c = t.length;
            if (s != c && !(o && c > s)) return !1;
            var d = r.get(e),
                I = r.get(t);
            if (d && I) return d == t && I == e;
            var E = -1,
                p = !0,
                g = n & c_ ? new r_ : void 0;
            for (r.set(e, t), r.set(t, e); ++E < s;) {
                var v = e[E],
                    m = t[E];
                if (i) var h = o ? i(m, v, E, t, e, r) : i(v, m, E, e, t, r);
                if (h !== void 0) {
                    if (h) continue;
                    p = !1;
                    break
                }
                if (g) {
                    if (!a_(t, function(T, A) {
                            if (!o_(g, A) && (v === T || a(v, T, n, i, r))) return g.push(A)
                        })) {
                        p = !1;
                        break
                    }
                } else if (!(v === m || a(v, m, n, i, r))) {
                    p = !1;
                    break
                }
            }
            return r.delete(e), r.delete(t), p
        }
        jc.exports = u_
    });
    var $c = u((a4, Kc) => {
        var l_ = Ge(),
            d_ = l_.Uint8Array;
        Kc.exports = d_
    });
    var Jc = u((o4, Zc) => {
        function f_(e) {
            var t = -1,
                n = Array(e.size);
            return e.forEach(function(i, a) {
                n[++t] = [a, i]
            }), n
        }
        Zc.exports = f_
    });
    var tu = u((s4, eu) => {
        function p_(e) {
            var t = -1,
                n = Array(e.size);
            return e.forEach(function(i) {
                n[++t] = i
            }), n
        }
        eu.exports = p_
    });
    var ou = u((c4, au) => {
        var nu = _t(),
            iu = $c(),
            g_ = Sn(),
            E_ = sr(),
            I_ = Jc(),
            y_ = tu(),
            T_ = 1,
            m_ = 2,
            v_ = "[object Boolean]",
            __ = "[object Date]",
            O_ = "[object Error]",
            h_ = "[object Map]",
            b_ = "[object Number]",
            S_ = "[object RegExp]",
            A_ = "[object Set]",
            R_ = "[object String]",
            L_ = "[object Symbol]",
            N_ = "[object ArrayBuffer]",
            C_ = "[object DataView]",
            ru = nu ? nu.prototype : void 0,
            cr = ru ? ru.valueOf : void 0;

        function w_(e, t, n, i, a, r, o) {
            switch (n) {
                case C_:
                    if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
                    e = e.buffer, t = t.buffer;
                case N_:
                    return !(e.byteLength != t.byteLength || !r(new iu(e), new iu(t)));
                case v_:
                case __:
                case b_:
                    return g_(+e, +t);
                case O_:
                    return e.name == t.name && e.message == t.message;
                case S_:
                case R_:
                    return e == t + "";
                case h_:
                    var s = I_;
                case A_:
                    var c = i & T_;
                    if (s || (s = y_), e.size != t.size && !c) return !1;
                    var d = o.get(e);
                    if (d) return d == t;
                    i |= m_, o.set(e, t);
                    var I = E_(s(e), s(t), i, a, r, o);
                    return o.delete(e), I;
                case L_:
                    if (cr) return cr.call(e) == cr.call(t)
            }
            return !1
        }
        au.exports = w_
    });
    var Nn = u((u4, su) => {
        function P_(e, t) {
            for (var n = -1, i = t.length, a = e.length; ++n < i;) e[a + n] = t[n];
            return e
        }
        su.exports = P_
    });
    var _e = u((l4, cu) => {
        var M_ = Array.isArray;
        cu.exports = M_
    });
    var ur = u((d4, uu) => {
        var x_ = Nn(),
            F_ = _e();

        function D_(e, t, n) {
            var i = t(e);
            return F_(e) ? i : x_(i, n(e))
        }
        uu.exports = D_
    });
    var du = u((f4, lu) => {
        function V_(e, t) {
            for (var n = -1, i = e == null ? 0 : e.length, a = 0, r = []; ++n < i;) {
                var o = e[n];
                t(o, n, e) && (r[a++] = o)
            }
            return r
        }
        lu.exports = V_
    });
    var lr = u((p4, fu) => {
        function U_() {
            return []
        }
        fu.exports = U_
    });
    var dr = u((g4, gu) => {
        var G_ = du(),
            q_ = lr(),
            k_ = Object.prototype,
            X_ = k_.propertyIsEnumerable,
            pu = Object.getOwnPropertySymbols,
            B_ = pu ? function(e) {
                return e == null ? [] : (e = Object(e), G_(pu(e), function(t) {
                    return X_.call(e, t)
                }))
            } : q_;
        gu.exports = B_
    });
    var Iu = u((E4, Eu) => {
        function Y_(e, t) {
            for (var n = -1, i = Array(e); ++n < e;) i[n] = t(n);
            return i
        }
        Eu.exports = Y_
    });
    var Tu = u((I4, yu) => {
        var W_ = tt(),
            H_ = Ke(),
            z_ = "[object Arguments]";

        function Q_(e) {
            return H_(e) && W_(e) == z_
        }
        yu.exports = Q_
    });
    var Kt = u((y4, _u) => {
        var mu = Tu(),
            j_ = Ke(),
            vu = Object.prototype,
            K_ = vu.hasOwnProperty,
            $_ = vu.propertyIsEnumerable,
            Z_ = mu(function() {
                return arguments
            }()) ? mu : function(e) {
                return j_(e) && K_.call(e, "callee") && !$_.call(e, "callee")
            };
        _u.exports = Z_
    });
    var hu = u((T4, Ou) => {
        function J_() {
            return !1
        }
        Ou.exports = J_
    });
    var Cn = u(($t, Nt) => {
        var eO = Ge(),
            tO = hu(),
            Au = typeof $t == "object" && $t && !$t.nodeType && $t,
            bu = Au && typeof Nt == "object" && Nt && !Nt.nodeType && Nt,
            nO = bu && bu.exports === Au,
            Su = nO ? eO.Buffer : void 0,
            iO = Su ? Su.isBuffer : void 0,
            rO = iO || tO;
        Nt.exports = rO
    });
    var wn = u((m4, Ru) => {
        var aO = 9007199254740991,
            oO = /^(?:0|[1-9]\d*)$/;

        function sO(e, t) {
            var n = typeof e;
            return t = t ? ? aO, !!t && (n == "number" || n != "symbol" && oO.test(e)) && e > -1 && e % 1 == 0 && e < t
        }
        Ru.exports = sO
    });
    var Pn = u((v4, Lu) => {
        var cO = 9007199254740991;

        function uO(e) {
            return typeof e == "number" && e > -1 && e % 1 == 0 && e <= cO
        }
        Lu.exports = uO
    });
    var Cu = u((_4, Nu) => {
        var lO = tt(),
            dO = Pn(),
            fO = Ke(),
            pO = "[object Arguments]",
            gO = "[object Array]",
            EO = "[object Boolean]",
            IO = "[object Date]",
            yO = "[object Error]",
            TO = "[object Function]",
            mO = "[object Map]",
            vO = "[object Number]",
            _O = "[object Object]",
            OO = "[object RegExp]",
            hO = "[object Set]",
            bO = "[object String]",
            SO = "[object WeakMap]",
            AO = "[object ArrayBuffer]",
            RO = "[object DataView]",
            LO = "[object Float32Array]",
            NO = "[object Float64Array]",
            CO = "[object Int8Array]",
            wO = "[object Int16Array]",
            PO = "[object Int32Array]",
            MO = "[object Uint8Array]",
            xO = "[object Uint8ClampedArray]",
            FO = "[object Uint16Array]",
            DO = "[object Uint32Array]",
            fe = {};
        fe[LO] = fe[NO] = fe[CO] = fe[wO] = fe[PO] = fe[MO] = fe[xO] = fe[FO] = fe[DO] = !0;
        fe[pO] = fe[gO] = fe[AO] = fe[EO] = fe[RO] = fe[IO] = fe[yO] = fe[TO] = fe[mO] = fe[vO] = fe[_O] = fe[OO] = fe[hO] = fe[bO] = fe[SO] = !1;

        function VO(e) {
            return fO(e) && dO(e.length) && !!fe[lO(e)]
        }
        Nu.exports = VO
    });
    var Pu = u((O4, wu) => {
        function UO(e) {
            return function(t) {
                return e(t)
            }
        }
        wu.exports = UO
    });
    var xu = u((Zt, Ct) => {
        var GO = Ci(),
            Mu = typeof Zt == "object" && Zt && !Zt.nodeType && Zt,
            Jt = Mu && typeof Ct == "object" && Ct && !Ct.nodeType && Ct,
            qO = Jt && Jt.exports === Mu,
            fr = qO && GO.process,
            kO = function() {
                try {
                    var e = Jt && Jt.require && Jt.require("util").types;
                    return e || fr && fr.binding && fr.binding("util")
                } catch {}
            }();
        Ct.exports = kO
    });
    var Mn = u((h4, Vu) => {
        var XO = Cu(),
            BO = Pu(),
            Fu = xu(),
            Du = Fu && Fu.isTypedArray,
            YO = Du ? BO(Du) : XO;
        Vu.exports = YO
    });
    var pr = u((b4, Uu) => {
        var WO = Iu(),
            HO = Kt(),
            zO = _e(),
            QO = Cn(),
            jO = wn(),
            KO = Mn(),
            $O = Object.prototype,
            ZO = $O.hasOwnProperty;

        function JO(e, t) {
            var n = zO(e),
                i = !n && HO(e),
                a = !n && !i && QO(e),
                r = !n && !i && !a && KO(e),
                o = n || i || a || r,
                s = o ? WO(e.length, String) : [],
                c = s.length;
            for (var d in e)(t || ZO.call(e, d)) && !(o && (d == "length" || a && (d == "offset" || d == "parent") || r && (d == "buffer" || d == "byteLength" || d == "byteOffset") || jO(d, c))) && s.push(d);
            return s
        }
        Uu.exports = JO
    });
    var xn = u((S4, Gu) => {
        var eh = Object.prototype;

        function th(e) {
            var t = e && e.constructor,
                n = typeof t == "function" && t.prototype || eh;
            return e === n
        }
        Gu.exports = th
    });
    var ku = u((A4, qu) => {
        var nh = wi(),
            ih = nh(Object.keys, Object);
        qu.exports = ih
    });
    var Fn = u((R4, Xu) => {
        var rh = xn(),
            ah = ku(),
            oh = Object.prototype,
            sh = oh.hasOwnProperty;

        function ch(e) {
            if (!rh(e)) return ah(e);
            var t = [];
            for (var n in Object(e)) sh.call(e, n) && n != "constructor" && t.push(n);
            return t
        }
        Xu.exports = ch
    });
    var lt = u((L4, Bu) => {
        var uh = ir(),
            lh = Pn();

        function dh(e) {
            return e != null && lh(e.length) && !uh(e)
        }
        Bu.exports = dh
    });
    var en = u((N4, Yu) => {
        var fh = pr(),
            ph = Fn(),
            gh = lt();

        function Eh(e) {
            return gh(e) ? fh(e) : ph(e)
        }
        Yu.exports = Eh
    });
    var Hu = u((C4, Wu) => {
        var Ih = ur(),
            yh = dr(),
            Th = en();

        function mh(e) {
            return Ih(e, Th, yh)
        }
        Wu.exports = mh
    });
    var ju = u((w4, Qu) => {
        var zu = Hu(),
            vh = 1,
            _h = Object.prototype,
            Oh = _h.hasOwnProperty;

        function hh(e, t, n, i, a, r) {
            var o = n & vh,
                s = zu(e),
                c = s.length,
                d = zu(t),
                I = d.length;
            if (c != I && !o) return !1;
            for (var E = c; E--;) {
                var p = s[E];
                if (!(o ? p in t : Oh.call(t, p))) return !1
            }
            var g = r.get(e),
                v = r.get(t);
            if (g && v) return g == t && v == e;
            var m = !0;
            r.set(e, t), r.set(t, e);
            for (var h = o; ++E < c;) {
                p = s[E];
                var T = e[p],
                    A = t[p];
                if (i) var b = o ? i(A, T, p, t, e, r) : i(T, A, p, e, t, r);
                if (!(b === void 0 ? T === A || a(T, A, n, i, r) : b)) {
                    m = !1;
                    break
                }
                h || (h = p == "constructor")
            }
            if (m && !h) {
                var N = e.constructor,
                    P = t.constructor;
                N != P && "constructor" in e && "constructor" in t && !(typeof N == "function" && N instanceof N && typeof P == "function" && P instanceof P) && (m = !1)
            }
            return r.delete(e), r.delete(t), m
        }
        Qu.exports = hh
    });
    var $u = u((P4, Ku) => {
        var bh = nt(),
            Sh = Ge(),
            Ah = bh(Sh, "DataView");
        Ku.exports = Ah
    });
    var Ju = u((M4, Zu) => {
        var Rh = nt(),
            Lh = Ge(),
            Nh = Rh(Lh, "Promise");
        Zu.exports = Nh
    });
    var tl = u((x4, el) => {
        var Ch = nt(),
            wh = Ge(),
            Ph = Ch(wh, "Set");
        el.exports = Ph
    });
    var gr = u((F4, nl) => {
        var Mh = nt(),
            xh = Ge(),
            Fh = Mh(xh, "WeakMap");
        nl.exports = Fh
    });
    var Dn = u((D4, ul) => {
        var Er = $u(),
            Ir = An(),
            yr = Ju(),
            Tr = tl(),
            mr = gr(),
            cl = tt(),
            wt = ar(),
            il = "[object Map]",
            Dh = "[object Object]",
            rl = "[object Promise]",
            al = "[object Set]",
            ol = "[object WeakMap]",
            sl = "[object DataView]",
            Vh = wt(Er),
            Uh = wt(Ir),
            Gh = wt(yr),
            qh = wt(Tr),
            kh = wt(mr),
            dt = cl;
        (Er && dt(new Er(new ArrayBuffer(1))) != sl || Ir && dt(new Ir) != il || yr && dt(yr.resolve()) != rl || Tr && dt(new Tr) != al || mr && dt(new mr) != ol) && (dt = function(e) {
            var t = cl(e),
                n = t == Dh ? e.constructor : void 0,
                i = n ? wt(n) : "";
            if (i) switch (i) {
                case Vh:
                    return sl;
                case Uh:
                    return il;
                case Gh:
                    return rl;
                case qh:
                    return al;
                case kh:
                    return ol
            }
            return t
        });
        ul.exports = dt
    });
    var yl = u((V4, Il) => {
        var vr = or(),
            Xh = sr(),
            Bh = ou(),
            Yh = ju(),
            ll = Dn(),
            dl = _e(),
            fl = Cn(),
            Wh = Mn(),
            Hh = 1,
            pl = "[object Arguments]",
            gl = "[object Array]",
            Vn = "[object Object]",
            zh = Object.prototype,
            El = zh.hasOwnProperty;

        function Qh(e, t, n, i, a, r) {
            var o = dl(e),
                s = dl(t),
                c = o ? gl : ll(e),
                d = s ? gl : ll(t);
            c = c == pl ? Vn : c, d = d == pl ? Vn : d;
            var I = c == Vn,
                E = d == Vn,
                p = c == d;
            if (p && fl(e)) {
                if (!fl(t)) return !1;
                o = !0, I = !1
            }
            if (p && !I) return r || (r = new vr), o || Wh(e) ? Xh(e, t, n, i, a, r) : Bh(e, t, c, n, i, a, r);
            if (!(n & Hh)) {
                var g = I && El.call(e, "__wrapped__"),
                    v = E && El.call(t, "__wrapped__");
                if (g || v) {
                    var m = g ? e.value() : e,
                        h = v ? t.value() : t;
                    return r || (r = new vr), a(m, h, n, i, r)
                }
            }
            return p ? (r || (r = new vr), Yh(e, t, n, i, a, r)) : !1
        }
        Il.exports = Qh
    });
    var _r = u((U4, vl) => {
        var jh = yl(),
            Tl = Ke();

        function ml(e, t, n, i, a) {
            return e === t ? !0 : e == null || t == null || !Tl(e) && !Tl(t) ? e !== e && t !== t : jh(e, t, n, i, ml, a)
        }
        vl.exports = ml
    });
    var Ol = u((G4, _l) => {
        var Kh = or(),
            $h = _r(),
            Zh = 1,
            Jh = 2;

        function eb(e, t, n, i) {
            var a = n.length,
                r = a,
                o = !i;
            if (e == null) return !r;
            for (e = Object(e); a--;) {
                var s = n[a];
                if (o && s[2] ? s[1] !== e[s[0]] : !(s[0] in e)) return !1
            }
            for (; ++a < r;) {
                s = n[a];
                var c = s[0],
                    d = e[c],
                    I = s[1];
                if (o && s[2]) {
                    if (d === void 0 && !(c in e)) return !1
                } else {
                    var E = new Kh;
                    if (i) var p = i(d, I, c, e, t, E);
                    if (!(p === void 0 ? $h(I, d, Zh | Jh, i, E) : p)) return !1
                }
            }
            return !0
        }
        _l.exports = eb
    });
    var Or = u((q4, hl) => {
        var tb = Ye();

        function nb(e) {
            return e === e && !tb(e)
        }
        hl.exports = nb
    });
    var Sl = u((k4, bl) => {
        var ib = Or(),
            rb = en();

        function ab(e) {
            for (var t = rb(e), n = t.length; n--;) {
                var i = t[n],
                    a = e[i];
                t[n] = [i, a, ib(a)]
            }
            return t
        }
        bl.exports = ab
    });
    var hr = u((X4, Al) => {
        function ob(e, t) {
            return function(n) {
                return n == null ? !1 : n[e] === t && (t !== void 0 || e in Object(n))
            }
        }
        Al.exports = ob
    });
    var Ll = u((B4, Rl) => {
        var sb = Ol(),
            cb = Sl(),
            ub = hr();

        function lb(e) {
            var t = cb(e);
            return t.length == 1 && t[0][2] ? ub(t[0][0], t[0][1]) : function(n) {
                return n === e || sb(n, e, t)
            }
        }
        Rl.exports = lb
    });
    var tn = u((Y4, Nl) => {
        var db = tt(),
            fb = Ke(),
            pb = "[object Symbol]";

        function gb(e) {
            return typeof e == "symbol" || fb(e) && db(e) == pb
        }
        Nl.exports = gb
    });
    var Un = u((W4, Cl) => {
        var Eb = _e(),
            Ib = tn(),
            yb = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
            Tb = /^\w*$/;

        function mb(e, t) {
            if (Eb(e)) return !1;
            var n = typeof e;
            return n == "number" || n == "symbol" || n == "boolean" || e == null || Ib(e) ? !0 : Tb.test(e) || !yb.test(e) || t != null && e in Object(t)
        }
        Cl.exports = mb
    });
    var Ml = u((H4, Pl) => {
        var wl = Rn(),
            vb = "Expected a function";

        function br(e, t) {
            if (typeof e != "function" || t != null && typeof t != "function") throw new TypeError(vb);
            var n = function() {
                var i = arguments,
                    a = t ? t.apply(this, i) : i[0],
                    r = n.cache;
                if (r.has(a)) return r.get(a);
                var o = e.apply(this, i);
                return n.cache = r.set(a, o) || r, o
            };
            return n.cache = new(br.Cache || wl), n
        }
        br.Cache = wl;
        Pl.exports = br
    });
    var Fl = u((z4, xl) => {
        var _b = Ml(),
            Ob = 500;

        function hb(e) {
            var t = _b(e, function(i) {
                    return n.size === Ob && n.clear(), i
                }),
                n = t.cache;
            return t
        }
        xl.exports = hb
    });
    var Vl = u((Q4, Dl) => {
        var bb = Fl(),
            Sb = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
            Ab = /\\(\\)?/g,
            Rb = bb(function(e) {
                var t = [];
                return e.charCodeAt(0) === 46 && t.push(""), e.replace(Sb, function(n, i, a, r) {
                    t.push(a ? r.replace(Ab, "$1") : i || n)
                }), t
            });
        Dl.exports = Rb
    });
    var Sr = u((j4, Ul) => {
        function Lb(e, t) {
            for (var n = -1, i = e == null ? 0 : e.length, a = Array(i); ++n < i;) a[n] = t(e[n], n, e);
            return a
        }
        Ul.exports = Lb
    });
    var Yl = u((K4, Bl) => {
        var Gl = _t(),
            Nb = Sr(),
            Cb = _e(),
            wb = tn(),
            Pb = 1 / 0,
            ql = Gl ? Gl.prototype : void 0,
            kl = ql ? ql.toString : void 0;

        function Xl(e) {
            if (typeof e == "string") return e;
            if (Cb(e)) return Nb(e, Xl) + "";
            if (wb(e)) return kl ? kl.call(e) : "";
            var t = e + "";
            return t == "0" && 1 / e == -Pb ? "-0" : t
        }
        Bl.exports = Xl
    });
    var Hl = u(($4, Wl) => {
        var Mb = Yl();

        function xb(e) {
            return e == null ? "" : Mb(e)
        }
        Wl.exports = xb
    });
    var nn = u((Z4, zl) => {
        var Fb = _e(),
            Db = Un(),
            Vb = Vl(),
            Ub = Hl();

        function Gb(e, t) {
            return Fb(e) ? e : Db(e, t) ? [e] : Vb(Ub(e))
        }
        zl.exports = Gb
    });
    var Pt = u((J4, Ql) => {
        var qb = tn(),
            kb = 1 / 0;

        function Xb(e) {
            if (typeof e == "string" || qb(e)) return e;
            var t = e + "";
            return t == "0" && 1 / e == -kb ? "-0" : t
        }
        Ql.exports = Xb
    });
    var Gn = u((ew, jl) => {
        var Bb = nn(),
            Yb = Pt();

        function Wb(e, t) {
            t = Bb(t, e);
            for (var n = 0, i = t.length; e != null && n < i;) e = e[Yb(t[n++])];
            return n && n == i ? e : void 0
        }
        jl.exports = Wb
    });
    var qn = u((tw, Kl) => {
        var Hb = Gn();

        function zb(e, t, n) {
            var i = e == null ? void 0 : Hb(e, t);
            return i === void 0 ? n : i
        }
        Kl.exports = zb
    });
    var Zl = u((nw, $l) => {
        function Qb(e, t) {
            return e != null && t in Object(e)
        }
        $l.exports = Qb
    });
    var ed = u((iw, Jl) => {
        var jb = nn(),
            Kb = Kt(),
            $b = _e(),
            Zb = wn(),
            Jb = Pn(),
            e1 = Pt();

        function t1(e, t, n) {
            t = jb(t, e);
            for (var i = -1, a = t.length, r = !1; ++i < a;) {
                var o = e1(t[i]);
                if (!(r = e != null && n(e, o))) break;
                e = e[o]
            }
            return r || ++i != a ? r : (a = e == null ? 0 : e.length, !!a && Jb(a) && Zb(o, a) && ($b(e) || Kb(e)))
        }
        Jl.exports = t1
    });
    var nd = u((rw, td) => {
        var n1 = Zl(),
            i1 = ed();

        function r1(e, t) {
            return e != null && i1(e, t, n1)
        }
        td.exports = r1
    });
    var rd = u((aw, id) => {
        var a1 = _r(),
            o1 = qn(),
            s1 = nd(),
            c1 = Un(),
            u1 = Or(),
            l1 = hr(),
            d1 = Pt(),
            f1 = 1,
            p1 = 2;

        function g1(e, t) {
            return c1(e) && u1(t) ? l1(d1(e), t) : function(n) {
                var i = o1(n, e);
                return i === void 0 && i === t ? s1(n, e) : a1(t, i, f1 | p1)
            }
        }
        id.exports = g1
    });
    var kn = u((ow, ad) => {
        function E1(e) {
            return e
        }
        ad.exports = E1
    });
    var Ar = u((sw, od) => {
        function I1(e) {
            return function(t) {
                return t ? .[e]
            }
        }
        od.exports = I1
    });
    var cd = u((cw, sd) => {
        var y1 = Gn();

        function T1(e) {
            return function(t) {
                return y1(t, e)
            }
        }
        sd.exports = T1
    });
    var ld = u((uw, ud) => {
        var m1 = Ar(),
            v1 = cd(),
            _1 = Un(),
            O1 = Pt();

        function h1(e) {
            return _1(e) ? m1(O1(e)) : v1(e)
        }
        ud.exports = h1
    });
    var it = u((lw, dd) => {
        var b1 = Ll(),
            S1 = rd(),
            A1 = kn(),
            R1 = _e(),
            L1 = ld();

        function N1(e) {
            return typeof e == "function" ? e : e == null ? A1 : typeof e == "object" ? R1(e) ? S1(e[0], e[1]) : b1(e) : L1(e)
        }
        dd.exports = N1
    });
    var Rr = u((dw, fd) => {
        var C1 = it(),
            w1 = lt(),
            P1 = en();

        function M1(e) {
            return function(t, n, i) {
                var a = Object(t);
                if (!w1(t)) {
                    var r = C1(n, 3);
                    t = P1(t), n = function(s) {
                        return r(a[s], s, a)
                    }
                }
                var o = e(t, n, i);
                return o > -1 ? a[r ? t[o] : o] : void 0
            }
        }
        fd.exports = M1
    });
    var Lr = u((fw, pd) => {
        function x1(e, t, n, i) {
            for (var a = e.length, r = n + (i ? 1 : -1); i ? r-- : ++r < a;)
                if (t(e[r], r, e)) return r;
            return -1
        }
        pd.exports = x1
    });
    var Ed = u((pw, gd) => {
        var F1 = /\s/;

        function D1(e) {
            for (var t = e.length; t-- && F1.test(e.charAt(t)););
            return t
        }
        gd.exports = D1
    });
    var yd = u((gw, Id) => {
        var V1 = Ed(),
            U1 = /^\s+/;

        function G1(e) {
            return e && e.slice(0, V1(e) + 1).replace(U1, "")
        }
        Id.exports = G1
    });
    var Xn = u((Ew, vd) => {
        var q1 = yd(),
            Td = Ye(),
            k1 = tn(),
            md = 0 / 0,
            X1 = /^[-+]0x[0-9a-f]+$/i,
            B1 = /^0b[01]+$/i,
            Y1 = /^0o[0-7]+$/i,
            W1 = parseInt;

        function H1(e) {
            if (typeof e == "number") return e;
            if (k1(e)) return md;
            if (Td(e)) {
                var t = typeof e.valueOf == "function" ? e.valueOf() : e;
                e = Td(t) ? t + "" : t
            }
            if (typeof e != "string") return e === 0 ? e : +e;
            e = q1(e);
            var n = B1.test(e);
            return n || Y1.test(e) ? W1(e.slice(2), n ? 2 : 8) : X1.test(e) ? md : +e
        }
        vd.exports = H1
    });
    var hd = u((Iw, Od) => {
        var z1 = Xn(),
            _d = 1 / 0,
            Q1 = 17976931348623157e292;

        function j1(e) {
            if (!e) return e === 0 ? e : 0;
            if (e = z1(e), e === _d || e === -_d) {
                var t = e < 0 ? -1 : 1;
                return t * Q1
            }
            return e === e ? e : 0
        }
        Od.exports = j1
    });
    var Nr = u((yw, bd) => {
        var K1 = hd();

        function $1(e) {
            var t = K1(e),
                n = t % 1;
            return t === t ? n ? t - n : t : 0
        }
        bd.exports = $1
    });
    var Ad = u((Tw, Sd) => {
        var Z1 = Lr(),
            J1 = it(),
            e2 = Nr(),
            t2 = Math.max;

        function n2(e, t, n) {
            var i = e == null ? 0 : e.length;
            if (!i) return -1;
            var a = n == null ? 0 : e2(n);
            return a < 0 && (a = t2(i + a, 0)), Z1(e, J1(t, 3), a)
        }
        Sd.exports = n2
    });
    var Cr = u((mw, Rd) => {
        var i2 = Rr(),
            r2 = Ad(),
            a2 = i2(r2);
        Rd.exports = a2
    });
    var Yn = u(wr => {
        "use strict";
        Object.defineProperty(wr, "__esModule", {
            value: !0
        });

        function o2(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        o2(wr, {
            ELEMENT_MATCHES: function() {
                return u2
            },
            FLEX_PREFIXED: function() {
                return l2
            },
            IS_BROWSER_ENV: function() {
                return Nd
            },
            TRANSFORM_PREFIXED: function() {
                return Cd
            },
            TRANSFORM_STYLE_PREFIXED: function() {
                return d2
            },
            withBrowser: function() {
                return Bn
            }
        });
        var s2 = c2(Cr());

        function c2(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var Nd = typeof window < "u",
            Bn = (e, t) => Nd ? e() : t,
            u2 = Bn(() => (0, s2.default)(["matches", "matchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector", "webkitMatchesSelector"], e => e in Element.prototype)),
            l2 = Bn(() => {
                let e = document.createElement("i"),
                    t = ["flex", "-webkit-flex", "-ms-flexbox", "-moz-box", "-webkit-box"],
                    n = "";
                try {
                    let {
                        length: i
                    } = t;
                    for (let a = 0; a < i; a++) {
                        let r = t[a];
                        if (e.style.display = r, e.style.display === r) return r
                    }
                    return n
                } catch {
                    return n
                }
            }, "flex"),
            Cd = Bn(() => {
                let e = document.createElement("i");
                if (e.style.transform == null) {
                    let t = ["Webkit", "Moz", "ms"],
                        n = "Transform",
                        {
                            length: i
                        } = t;
                    for (let a = 0; a < i; a++) {
                        let r = t[a] + n;
                        if (e.style[r] !== void 0) return r
                    }
                }
                return "transform"
            }, "transform"),
            Ld = Cd.split("transform")[0],
            d2 = Ld ? Ld + "TransformStyle" : "transformStyle"
    });
    var Pr = u((_w, Fd) => {
        var f2 = 4,
            p2 = .001,
            g2 = 1e-7,
            E2 = 10,
            rn = 11,
            Wn = 1 / (rn - 1),
            I2 = typeof Float32Array == "function";

        function wd(e, t) {
            return 1 - 3 * t + 3 * e
        }

        function Pd(e, t) {
            return 3 * t - 6 * e
        }

        function Md(e) {
            return 3 * e
        }

        function Hn(e, t, n) {
            return ((wd(t, n) * e + Pd(t, n)) * e + Md(t)) * e
        }

        function xd(e, t, n) {
            return 3 * wd(t, n) * e * e + 2 * Pd(t, n) * e + Md(t)
        }

        function y2(e, t, n, i, a) {
            var r, o, s = 0;
            do o = t + (n - t) / 2, r = Hn(o, i, a) - e, r > 0 ? n = o : t = o; while (Math.abs(r) > g2 && ++s < E2);
            return o
        }

        function T2(e, t, n, i) {
            for (var a = 0; a < f2; ++a) {
                var r = xd(t, n, i);
                if (r === 0) return t;
                var o = Hn(t, n, i) - e;
                t -= o / r
            }
            return t
        }
        Fd.exports = function(t, n, i, a) {
            if (!(0 <= t && t <= 1 && 0 <= i && i <= 1)) throw new Error("bezier x values must be in [0, 1] range");
            var r = I2 ? new Float32Array(rn) : new Array(rn);
            if (t !== n || i !== a)
                for (var o = 0; o < rn; ++o) r[o] = Hn(o * Wn, t, i);

            function s(c) {
                for (var d = 0, I = 1, E = rn - 1; I !== E && r[I] <= c; ++I) d += Wn;
                --I;
                var p = (c - r[I]) / (r[I + 1] - r[I]),
                    g = d + p * Wn,
                    v = xd(g, t, i);
                return v >= p2 ? T2(c, g, t, i) : v === 0 ? g : y2(c, d, d + Wn, t, i)
            }
            return function(d) {
                return t === n && i === a ? d : d === 0 ? 0 : d === 1 ? 1 : Hn(s(d), n, a)
            }
        }
    });
    var xr = u(Mr => {
        "use strict";
        Object.defineProperty(Mr, "__esModule", {
            value: !0
        });

        function m2(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        m2(Mr, {
            bounce: function() {
                return nS
            },
            bouncePast: function() {
                return iS
            },
            ease: function() {
                return _2
            },
            easeIn: function() {
                return O2
            },
            easeInOut: function() {
                return b2
            },
            easeOut: function() {
                return h2
            },
            inBack: function() {
                return z2
            },
            inCirc: function() {
                return B2
            },
            inCubic: function() {
                return L2
            },
            inElastic: function() {
                return K2
            },
            inExpo: function() {
                return q2
            },
            inOutBack: function() {
                return j2
            },
            inOutCirc: function() {
                return W2
            },
            inOutCubic: function() {
                return C2
            },
            inOutElastic: function() {
                return Z2
            },
            inOutExpo: function() {
                return X2
            },
            inOutQuad: function() {
                return R2
            },
            inOutQuart: function() {
                return M2
            },
            inOutQuint: function() {
                return D2
            },
            inOutSine: function() {
                return G2
            },
            inQuad: function() {
                return S2
            },
            inQuart: function() {
                return w2
            },
            inQuint: function() {
                return x2
            },
            inSine: function() {
                return V2
            },
            outBack: function() {
                return Q2
            },
            outBounce: function() {
                return H2
            },
            outCirc: function() {
                return Y2
            },
            outCubic: function() {
                return N2
            },
            outElastic: function() {
                return $2
            },
            outExpo: function() {
                return k2
            },
            outQuad: function() {
                return A2
            },
            outQuart: function() {
                return P2
            },
            outQuint: function() {
                return F2
            },
            outSine: function() {
                return U2
            },
            swingFrom: function() {
                return eS
            },
            swingFromTo: function() {
                return J2
            },
            swingTo: function() {
                return tS
            }
        });
        var zn = v2(Pr());

        function v2(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var $e = 1.70158,
            _2 = (0, zn.default)(.25, .1, .25, 1),
            O2 = (0, zn.default)(.42, 0, 1, 1),
            h2 = (0, zn.default)(0, 0, .58, 1),
            b2 = (0, zn.default)(.42, 0, .58, 1);

        function S2(e) {
            return Math.pow(e, 2)
        }

        function A2(e) {
            return -(Math.pow(e - 1, 2) - 1)
        }

        function R2(e) {
            return (e /= .5) < 1 ? .5 * Math.pow(e, 2) : -.5 * ((e -= 2) * e - 2)
        }

        function L2(e) {
            return Math.pow(e, 3)
        }

        function N2(e) {
            return Math.pow(e - 1, 3) + 1
        }

        function C2(e) {
            return (e /= .5) < 1 ? .5 * Math.pow(e, 3) : .5 * (Math.pow(e - 2, 3) + 2)
        }

        function w2(e) {
            return Math.pow(e, 4)
        }

        function P2(e) {
            return -(Math.pow(e - 1, 4) - 1)
        }

        function M2(e) {
            return (e /= .5) < 1 ? .5 * Math.pow(e, 4) : -.5 * ((e -= 2) * Math.pow(e, 3) - 2)
        }

        function x2(e) {
            return Math.pow(e, 5)
        }

        function F2(e) {
            return Math.pow(e - 1, 5) + 1
        }

        function D2(e) {
            return (e /= .5) < 1 ? .5 * Math.pow(e, 5) : .5 * (Math.pow(e - 2, 5) + 2)
        }

        function V2(e) {
            return -Math.cos(e * (Math.PI / 2)) + 1
        }

        function U2(e) {
            return Math.sin(e * (Math.PI / 2))
        }

        function G2(e) {
            return -.5 * (Math.cos(Math.PI * e) - 1)
        }

        function q2(e) {
            return e === 0 ? 0 : Math.pow(2, 10 * (e - 1))
        }

        function k2(e) {
            return e === 1 ? 1 : -Math.pow(2, -10 * e) + 1
        }

        function X2(e) {
            return e === 0 ? 0 : e === 1 ? 1 : (e /= .5) < 1 ? .5 * Math.pow(2, 10 * (e - 1)) : .5 * (-Math.pow(2, -10 * --e) + 2)
        }

        function B2(e) {
            return -(Math.sqrt(1 - e * e) - 1)
        }

        function Y2(e) {
            return Math.sqrt(1 - Math.pow(e - 1, 2))
        }

        function W2(e) {
            return (e /= .5) < 1 ? -.5 * (Math.sqrt(1 - e * e) - 1) : .5 * (Math.sqrt(1 - (e -= 2) * e) + 1)
        }

        function H2(e) {
            return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
        }

        function z2(e) {
            let t = $e;
            return e * e * ((t + 1) * e - t)
        }

        function Q2(e) {
            let t = $e;
            return (e -= 1) * e * ((t + 1) * e + t) + 1
        }

        function j2(e) {
            let t = $e;
            return (e /= .5) < 1 ? .5 * (e * e * (((t *= 1.525) + 1) * e - t)) : .5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2)
        }

        function K2(e) {
            let t = $e,
                n = 0,
                i = 1;
            return e === 0 ? 0 : e === 1 ? 1 : (n || (n = .3), i < 1 ? (i = 1, t = n / 4) : t = n / (2 * Math.PI) * Math.asin(1 / i), -(i * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n)))
        }

        function $2(e) {
            let t = $e,
                n = 0,
                i = 1;
            return e === 0 ? 0 : e === 1 ? 1 : (n || (n = .3), i < 1 ? (i = 1, t = n / 4) : t = n / (2 * Math.PI) * Math.asin(1 / i), i * Math.pow(2, -10 * e) * Math.sin((e - t) * (2 * Math.PI) / n) + 1)
        }

        function Z2(e) {
            let t = $e,
                n = 0,
                i = 1;
            return e === 0 ? 0 : (e /= 1 / 2) === 2 ? 1 : (n || (n = .3 * 1.5), i < 1 ? (i = 1, t = n / 4) : t = n / (2 * Math.PI) * Math.asin(1 / i), e < 1 ? -.5 * (i * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n)) : i * Math.pow(2, -10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / n) * .5 + 1)
        }

        function J2(e) {
            let t = $e;
            return (e /= .5) < 1 ? .5 * (e * e * (((t *= 1.525) + 1) * e - t)) : .5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2)
        }

        function eS(e) {
            let t = $e;
            return e * e * ((t + 1) * e - t)
        }

        function tS(e) {
            let t = $e;
            return (e -= 1) * e * ((t + 1) * e + t) + 1
        }

        function nS(e) {
            return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
        }

        function iS(e) {
            return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 2 - (7.5625 * (e -= 1.5 / 2.75) * e + .75) : e < 2.5 / 2.75 ? 2 - (7.5625 * (e -= 2.25 / 2.75) * e + .9375) : 2 - (7.5625 * (e -= 2.625 / 2.75) * e + .984375)
        }
    });
    var Vr = u(Dr => {
        "use strict";
        Object.defineProperty(Dr, "__esModule", {
            value: !0
        });

        function rS(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        rS(Dr, {
            applyEasing: function() {
                return uS
            },
            createBezierEasing: function() {
                return cS
            },
            optimizeFloat: function() {
                return Fr
            }
        });
        var Dd = sS(xr()),
            aS = oS(Pr());

        function oS(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function Vd(e) {
            if (typeof WeakMap != "function") return null;
            var t = new WeakMap,
                n = new WeakMap;
            return (Vd = function(i) {
                return i ? n : t
            })(e)
        }

        function sS(e, t) {
            if (!t && e && e.__esModule) return e;
            if (e === null || typeof e != "object" && typeof e != "function") return {
                default: e
            };
            var n = Vd(t);
            if (n && n.has(e)) return n.get(e);
            var i = {
                    __proto__: null
                },
                a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var r in e)
                if (r !== "default" && Object.prototype.hasOwnProperty.call(e, r)) {
                    var o = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    o && (o.get || o.set) ? Object.defineProperty(i, r, o) : i[r] = e[r]
                }
            return i.default = e, n && n.set(e, i), i
        }

        function Fr(e, t = 5, n = 10) {
            let i = Math.pow(n, t),
                a = Number(Math.round(e * i) / i);
            return Math.abs(a) > 1e-4 ? a : 0
        }

        function cS(e) {
            return (0, aS.default)(...e)
        }

        function uS(e, t, n) {
            return t === 0 ? 0 : t === 1 ? 1 : Fr(n ? t > 0 ? n(t) : t : t > 0 && e && Dd[e] ? Dd[e](t) : t)
        }
    });
    var kd = u(Gr => {
        "use strict";
        Object.defineProperty(Gr, "__esModule", {
            value: !0
        });

        function lS(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        lS(Gr, {
            createElementState: function() {
                return qd
            },
            ixElements: function() {
                return bS
            },
            mergeActionState: function() {
                return Ur
            }
        });
        var Qn = bt(),
            Gd = Re(),
            {
                HTML_ELEMENT: bw,
                PLAIN_OBJECT: dS,
                ABSTRACT_NODE: Sw,
                CONFIG_X_VALUE: fS,
                CONFIG_Y_VALUE: pS,
                CONFIG_Z_VALUE: gS,
                CONFIG_VALUE: ES,
                CONFIG_X_UNIT: IS,
                CONFIG_Y_UNIT: yS,
                CONFIG_Z_UNIT: TS,
                CONFIG_UNIT: mS
            } = Gd.IX2EngineConstants,
            {
                IX2_SESSION_STOPPED: vS,
                IX2_INSTANCE_ADDED: _S,
                IX2_ELEMENT_STATE_CHANGED: OS
            } = Gd.IX2EngineActionTypes,
            Ud = {},
            hS = "refState",
            bS = (e = Ud, t = {}) => {
                switch (t.type) {
                    case vS:
                        return Ud;
                    case _S:
                        {
                            let {
                                elementId: n,
                                element: i,
                                origin: a,
                                actionItem: r,
                                refType: o
                            } = t.payload,
                            {
                                actionTypeId: s
                            } = r,
                            c = e;
                            return (0, Qn.getIn)(c, [n, i]) !== i && (c = qd(c, i, o, n, r)),
                            Ur(c, n, s, a, r)
                        }
                    case OS:
                        {
                            let {
                                elementId: n,
                                actionTypeId: i,
                                current: a,
                                actionItem: r
                            } = t.payload;
                            return Ur(e, n, i, a, r)
                        }
                    default:
                        return e
                }
            };

        function qd(e, t, n, i, a) {
            let r = n === dS ? (0, Qn.getIn)(a, ["config", "target", "objectId"]) : null;
            return (0, Qn.mergeIn)(e, [i], {
                id: i,
                ref: t,
                refId: r,
                refType: n
            })
        }

        function Ur(e, t, n, i, a) {
            let r = AS(a),
                o = [t, hS, n];
            return (0, Qn.mergeIn)(e, o, i, r)
        }
        var SS = [
            [fS, IS],
            [pS, yS],
            [gS, TS],
            [ES, mS]
        ];

        function AS(e) {
            let {
                config: t
            } = e;
            return SS.reduce((n, i) => {
                let a = i[0],
                    r = i[1],
                    o = t[a],
                    s = t[r];
                return o != null && s != null && (n[r] = s), n
            }, {})
        }
    });
    var Xd = u(qr => {
        "use strict";
        Object.defineProperty(qr, "__esModule", {
            value: !0
        });

        function RS(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        RS(qr, {
            clearPlugin: function() {
                return xS
            },
            createPluginInstance: function() {
                return PS
            },
            getPluginConfig: function() {
                return LS
            },
            getPluginDestination: function() {
                return wS
            },
            getPluginDuration: function() {
                return NS
            },
            getPluginOrigin: function() {
                return CS
            },
            renderPlugin: function() {
                return MS
            }
        });
        var LS = e => e.value,
            NS = (e, t) => {
                if (t.config.duration !== "auto") return null;
                let n = parseFloat(e.getAttribute("data-duration"));
                return n > 0 ? n * 1e3 : parseFloat(e.getAttribute("data-default-duration")) * 1e3
            },
            CS = e => e || {
                value: 0
            },
            wS = e => ({
                value: e.value
            }),
            PS = e => {
                let t = window.Webflow.require("lottie").createInstance(e);
                return t.stop(), t.setSubframe(!0), t
            },
            MS = (e, t, n) => {
                if (!e) return;
                let i = t[n.actionTypeId].value / 100;
                e.goToFrame(e.frames * i)
            },
            xS = e => {
                window.Webflow.require("lottie").createInstance(e).stop()
            }
    });
    var Yd = u(kr => {
        "use strict";
        Object.defineProperty(kr, "__esModule", {
            value: !0
        });

        function FS(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        FS(kr, {
            clearPlugin: function() {
                return WS
            },
            createPluginInstance: function() {
                return BS
            },
            getPluginConfig: function() {
                return GS
            },
            getPluginDestination: function() {
                return XS
            },
            getPluginDuration: function() {
                return qS
            },
            getPluginOrigin: function() {
                return kS
            },
            renderPlugin: function() {
                return YS
            }
        });
        var DS = e => document.querySelector(`[data-w-id="${e}"]`),
            VS = () => window.Webflow.require("spline"),
            US = (e, t) => e.filter(n => !t.includes(n)),
            GS = (e, t) => e.value[t],
            qS = () => null,
            Bd = Object.freeze({
                positionX: 0,
                positionY: 0,
                positionZ: 0,
                rotationX: 0,
                rotationY: 0,
                rotationZ: 0,
                scaleX: 1,
                scaleY: 1,
                scaleZ: 1
            }),
            kS = (e, t) => {
                let n = t.config.value,
                    i = Object.keys(n);
                if (e) {
                    let r = Object.keys(e),
                        o = US(i, r);
                    return o.length ? o.reduce((c, d) => (c[d] = Bd[d], c), e) : e
                }
                return i.reduce((r, o) => (r[o] = Bd[o], r), {})
            },
            XS = e => e.value,
            BS = (e, t) => {
                let n = t ? .config ? .target ? .pluginElement;
                return n ? DS(n) : null
            },
            YS = (e, t, n) => {
                let i = VS(),
                    a = i.getInstance(e),
                    r = n.config.target.objectId,
                    o = s => {
                        if (!s) throw new Error("Invalid spline app passed to renderSpline");
                        let c = r && s.findObjectById(r);
                        if (!c) return;
                        let {
                            PLUGIN_SPLINE: d
                        } = t;
                        d.positionX != null && (c.position.x = d.positionX), d.positionY != null && (c.position.y = d.positionY), d.positionZ != null && (c.position.z = d.positionZ), d.rotationX != null && (c.rotation.x = d.rotationX), d.rotationY != null && (c.rotation.y = d.rotationY), d.rotationZ != null && (c.rotation.z = d.rotationZ), d.scaleX != null && (c.scale.x = d.scaleX), d.scaleY != null && (c.scale.y = d.scaleY), d.scaleZ != null && (c.scale.z = d.scaleZ)
                    };
                a ? o(a.spline) : i.setLoadHandler(e, o)
            },
            WS = () => null
    });
    var Wd = u(Yr => {
        "use strict";
        Object.defineProperty(Yr, "__esModule", {
            value: !0
        });

        function HS(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        HS(Yr, {
            clearPlugin: function() {
                return tA
            },
            createPluginInstance: function() {
                return JS
            },
            getPluginConfig: function() {
                return jS
            },
            getPluginDestination: function() {
                return ZS
            },
            getPluginDuration: function() {
                return KS
            },
            getPluginOrigin: function() {
                return $S
            },
            renderPlugin: function() {
                return eA
            }
        });
        var Xr = "--wf-rive-fit",
            Br = "--wf-rive-alignment",
            zS = e => document.querySelector(`[data-w-id="${e}"]`),
            QS = () => window.Webflow.require("rive"),
            jS = (e, t) => e.value.inputs[t],
            KS = () => null,
            $S = (e, t) => {
                if (e) return e;
                let n = {},
                    {
                        inputs: i = {}
                    } = t.config.value;
                for (let a in i) i[a] == null && (n[a] = 0);
                return n
            },
            ZS = e => e.value.inputs ? ? {},
            JS = (e, t) => {
                if ((t.config ? .target ? .selectorGuids || []).length > 0) return e;
                let i = t ? .config ? .target ? .pluginElement;
                return i ? zS(i) : null
            },
            eA = (e, {
                PLUGIN_RIVE: t
            }, n) => {
                let i = QS(),
                    a = i.getInstance(e),
                    r = i.rive.StateMachineInputType,
                    {
                        name: o,
                        inputs: s = {}
                    } = n.config.value || {};

                function c(d) {
                    if (d.loaded) I();
                    else {
                        let E = () => {
                            I(), d ? .off("load", E)
                        };
                        d ? .on("load", E)
                    }

                    function I() {
                        let E = d.stateMachineInputs(o);
                        if (E != null) {
                            if (d.isPlaying || d.play(o, !1), Xr in s || Br in s) {
                                let p = d.layout,
                                    g = s[Xr] ? ? p.fit,
                                    v = s[Br] ? ? p.alignment;
                                (g !== p.fit || v !== p.alignment) && (d.layout = p.copyWith({
                                    fit: g,
                                    alignment: v
                                }))
                            }
                            for (let p in s) {
                                if (p === Xr || p === Br) continue;
                                let g = E.find(v => v.name === p);
                                if (g != null) switch (g.type) {
                                    case r.Boolean:
                                        {
                                            if (s[p] != null) {
                                                let v = !!s[p];
                                                g.value = v
                                            }
                                            break
                                        }
                                    case r.Number:
                                        {
                                            let v = t[p];v != null && (g.value = v);
                                            break
                                        }
                                    case r.Trigger:
                                        {
                                            s[p] && g.fire();
                                            break
                                        }
                                }
                            }
                        }
                    }
                }
                a ? .rive ? c(a.rive) : i.setLoadHandler(e, c)
            },
            tA = (e, t) => null
    });
    var Hr = u(Wr => {
        "use strict";
        Object.defineProperty(Wr, "__esModule", {
            value: !0
        });
        Object.defineProperty(Wr, "normalizeColor", {
            enumerable: !0,
            get: function() {
                return nA
            }
        });
        var Hd = {
            aliceblue: "#F0F8FF",
            antiquewhite: "#FAEBD7",
            aqua: "#00FFFF",
            aquamarine: "#7FFFD4",
            azure: "#F0FFFF",
            beige: "#F5F5DC",
            bisque: "#FFE4C4",
            black: "#000000",
            blanchedalmond: "#FFEBCD",
            blue: "#0000FF",
            blueviolet: "#8A2BE2",
            brown: "#A52A2A",
            burlywood: "#DEB887",
            cadetblue: "#5F9EA0",
            chartreuse: "#7FFF00",
            chocolate: "#D2691E",
            coral: "#FF7F50",
            cornflowerblue: "#6495ED",
            cornsilk: "#FFF8DC",
            crimson: "#DC143C",
            cyan: "#00FFFF",
            darkblue: "#00008B",
            darkcyan: "#008B8B",
            darkgoldenrod: "#B8860B",
            darkgray: "#A9A9A9",
            darkgreen: "#006400",
            darkgrey: "#A9A9A9",
            darkkhaki: "#BDB76B",
            darkmagenta: "#8B008B",
            darkolivegreen: "#556B2F",
            darkorange: "#FF8C00",
            darkorchid: "#9932CC",
            darkred: "#8B0000",
            darksalmon: "#E9967A",
            darkseagreen: "#8FBC8F",
            darkslateblue: "#483D8B",
            darkslategray: "#2F4F4F",
            darkslategrey: "#2F4F4F",
            darkturquoise: "#00CED1",
            darkviolet: "#9400D3",
            deeppink: "#FF1493",
            deepskyblue: "#00BFFF",
            dimgray: "#696969",
            dimgrey: "#696969",
            dodgerblue: "#1E90FF",
            firebrick: "#B22222",
            floralwhite: "#FFFAF0",
            forestgreen: "#228B22",
            fuchsia: "#FF00FF",
            gainsboro: "#DCDCDC",
            ghostwhite: "#F8F8FF",
            gold: "#FFD700",
            goldenrod: "#DAA520",
            gray: "#808080",
            green: "#008000",
            greenyellow: "#ADFF2F",
            grey: "#808080",
            honeydew: "#F0FFF0",
            hotpink: "#FF69B4",
            indianred: "#CD5C5C",
            indigo: "#4B0082",
            ivory: "#FFFFF0",
            khaki: "#F0E68C",
            lavender: "#E6E6FA",
            lavenderblush: "#FFF0F5",
            lawngreen: "#7CFC00",
            lemonchiffon: "#FFFACD",
            lightblue: "#ADD8E6",
            lightcoral: "#F08080",
            lightcyan: "#E0FFFF",
            lightgoldenrodyellow: "#FAFAD2",
            lightgray: "#D3D3D3",
            lightgreen: "#90EE90",
            lightgrey: "#D3D3D3",
            lightpink: "#FFB6C1",
            lightsalmon: "#FFA07A",
            lightseagreen: "#20B2AA",
            lightskyblue: "#87CEFA",
            lightslategray: "#778899",
            lightslategrey: "#778899",
            lightsteelblue: "#B0C4DE",
            lightyellow: "#FFFFE0",
            lime: "#00FF00",
            limegreen: "#32CD32",
            linen: "#FAF0E6",
            magenta: "#FF00FF",
            maroon: "#800000",
            mediumaquamarine: "#66CDAA",
            mediumblue: "#0000CD",
            mediumorchid: "#BA55D3",
            mediumpurple: "#9370DB",
            mediumseagreen: "#3CB371",
            mediumslateblue: "#7B68EE",
            mediumspringgreen: "#00FA9A",
            mediumturquoise: "#48D1CC",
            mediumvioletred: "#C71585",
            midnightblue: "#191970",
            mintcream: "#F5FFFA",
            mistyrose: "#FFE4E1",
            moccasin: "#FFE4B5",
            navajowhite: "#FFDEAD",
            navy: "#000080",
            oldlace: "#FDF5E6",
            olive: "#808000",
            olivedrab: "#6B8E23",
            orange: "#FFA500",
            orangered: "#FF4500",
            orchid: "#DA70D6",
            palegoldenrod: "#EEE8AA",
            palegreen: "#98FB98",
            paleturquoise: "#AFEEEE",
            palevioletred: "#DB7093",
            papayawhip: "#FFEFD5",
            peachpuff: "#FFDAB9",
            peru: "#CD853F",
            pink: "#FFC0CB",
            plum: "#DDA0DD",
            powderblue: "#B0E0E6",
            purple: "#800080",
            rebeccapurple: "#663399",
            red: "#FF0000",
            rosybrown: "#BC8F8F",
            royalblue: "#4169E1",
            saddlebrown: "#8B4513",
            salmon: "#FA8072",
            sandybrown: "#F4A460",
            seagreen: "#2E8B57",
            seashell: "#FFF5EE",
            sienna: "#A0522D",
            silver: "#C0C0C0",
            skyblue: "#87CEEB",
            slateblue: "#6A5ACD",
            slategray: "#708090",
            slategrey: "#708090",
            snow: "#FFFAFA",
            springgreen: "#00FF7F",
            steelblue: "#4682B4",
            tan: "#D2B48C",
            teal: "#008080",
            thistle: "#D8BFD8",
            tomato: "#FF6347",
            turquoise: "#40E0D0",
            violet: "#EE82EE",
            wheat: "#F5DEB3",
            white: "#FFFFFF",
            whitesmoke: "#F5F5F5",
            yellow: "#FFFF00",
            yellowgreen: "#9ACD32"
        };

        function nA(e) {
            let t, n, i, a = 1,
                r = e.replace(/\s/g, "").toLowerCase(),
                s = (typeof Hd[r] == "string" ? Hd[r].toLowerCase() : null) || r;
            if (s.startsWith("#")) {
                let c = s.substring(1);
                c.length === 3 || c.length === 4 ? (t = parseInt(c[0] + c[0], 16), n = parseInt(c[1] + c[1], 16), i = parseInt(c[2] + c[2], 16), c.length === 4 && (a = parseInt(c[3] + c[3], 16) / 255)) : (c.length === 6 || c.length === 8) && (t = parseInt(c.substring(0, 2), 16), n = parseInt(c.substring(2, 4), 16), i = parseInt(c.substring(4, 6), 16), c.length === 8 && (a = parseInt(c.substring(6, 8), 16) / 255))
            } else if (s.startsWith("rgba")) {
                let c = s.match(/rgba\(([^)]+)\)/)[1].split(",");
                t = parseInt(c[0], 10), n = parseInt(c[1], 10), i = parseInt(c[2], 10), a = parseFloat(c[3])
            } else if (s.startsWith("rgb")) {
                let c = s.match(/rgb\(([^)]+)\)/)[1].split(",");
                t = parseInt(c[0], 10), n = parseInt(c[1], 10), i = parseInt(c[2], 10)
            } else if (s.startsWith("hsla")) {
                let c = s.match(/hsla\(([^)]+)\)/)[1].split(","),
                    d = parseFloat(c[0]),
                    I = parseFloat(c[1].replace("%", "")) / 100,
                    E = parseFloat(c[2].replace("%", "")) / 100;
                a = parseFloat(c[3]);
                let p = (1 - Math.abs(2 * E - 1)) * I,
                    g = p * (1 - Math.abs(d / 60 % 2 - 1)),
                    v = E - p / 2,
                    m, h, T;
                d >= 0 && d < 60 ? (m = p, h = g, T = 0) : d >= 60 && d < 120 ? (m = g, h = p, T = 0) : d >= 120 && d < 180 ? (m = 0, h = p, T = g) : d >= 180 && d < 240 ? (m = 0, h = g, T = p) : d >= 240 && d < 300 ? (m = g, h = 0, T = p) : (m = p, h = 0, T = g), t = Math.round((m + v) * 255), n = Math.round((h + v) * 255), i = Math.round((T + v) * 255)
            } else if (s.startsWith("hsl")) {
                let c = s.match(/hsl\(([^)]+)\)/)[1].split(","),
                    d = parseFloat(c[0]),
                    I = parseFloat(c[1].replace("%", "")) / 100,
                    E = parseFloat(c[2].replace("%", "")) / 100,
                    p = (1 - Math.abs(2 * E - 1)) * I,
                    g = p * (1 - Math.abs(d / 60 % 2 - 1)),
                    v = E - p / 2,
                    m, h, T;
                d >= 0 && d < 60 ? (m = p, h = g, T = 0) : d >= 60 && d < 120 ? (m = g, h = p, T = 0) : d >= 120 && d < 180 ? (m = 0, h = p, T = g) : d >= 180 && d < 240 ? (m = 0, h = g, T = p) : d >= 240 && d < 300 ? (m = g, h = 0, T = p) : (m = p, h = 0, T = g), t = Math.round((m + v) * 255), n = Math.round((h + v) * 255), i = Math.round((T + v) * 255)
            }
            if (Number.isNaN(t) || Number.isNaN(n) || Number.isNaN(i)) throw new Error(`Invalid color in [ix2/shared/utils/normalizeColor.js] '${e}'`);
            return {
                red: t,
                green: n,
                blue: i,
                alpha: a
            }
        }
    });
    var zd = u(zr => {
        "use strict";
        Object.defineProperty(zr, "__esModule", {
            value: !0
        });

        function iA(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        iA(zr, {
            clearPlugin: function() {
                return fA
            },
            createPluginInstance: function() {
                return uA
            },
            getPluginConfig: function() {
                return aA
            },
            getPluginDestination: function() {
                return cA
            },
            getPluginDuration: function() {
                return oA
            },
            getPluginOrigin: function() {
                return sA
            },
            renderPlugin: function() {
                return dA
            }
        });
        var rA = Hr(),
            aA = (e, t) => e.value[t],
            oA = () => null,
            sA = (e, t) => {
                if (e) return e;
                let n = t.config.value,
                    i = t.config.target.objectId,
                    a = getComputedStyle(document.documentElement).getPropertyValue(i);
                if (n.size != null) return {
                    size: parseInt(a, 10)
                };
                if (n.unit === "%" || n.unit === "-") return {
                    size: parseFloat(a)
                };
                if (n.red != null && n.green != null && n.blue != null) return (0, rA.normalizeColor)(a)
            },
            cA = e => e.value,
            uA = () => null,
            lA = {
                color: {
                    match: ({
                        red: e,
                        green: t,
                        blue: n,
                        alpha: i
                    }) => [e, t, n, i].every(a => a != null),
                    getValue: ({
                        red: e,
                        green: t,
                        blue: n,
                        alpha: i
                    }) => `rgba(${e}, ${t}, ${n}, ${i})`
                },
                size: {
                    match: ({
                        size: e
                    }) => e != null,
                    getValue: ({
                        size: e
                    }, t) => {
                        switch (t) {
                            case "-":
                                return e;
                            default:
                                return `${e}${t}`
                        }
                    }
                }
            },
            dA = (e, t, n) => {
                let {
                    target: {
                        objectId: i
                    },
                    value: {
                        unit: a
                    }
                } = n.config, r = t.PLUGIN_VARIABLE, o = Object.values(lA).find(s => s.match(r, a));
                o && document.documentElement.style.setProperty(i, o.getValue(r, a))
            },
            fA = (e, t) => {
                let n = t.config.target.objectId;
                document.documentElement.style.removeProperty(n)
            }
    });
    var jd = u(Qr => {
        "use strict";
        Object.defineProperty(Qr, "__esModule", {
            value: !0
        });
        Object.defineProperty(Qr, "pluginMethodMap", {
            enumerable: !0,
            get: function() {
                return yA
            }
        });
        var jn = Re(),
            pA = Kn(Xd()),
            gA = Kn(Yd()),
            EA = Kn(Wd()),
            IA = Kn(zd());

        function Qd(e) {
            if (typeof WeakMap != "function") return null;
            var t = new WeakMap,
                n = new WeakMap;
            return (Qd = function(i) {
                return i ? n : t
            })(e)
        }

        function Kn(e, t) {
            if (!t && e && e.__esModule) return e;
            if (e === null || typeof e != "object" && typeof e != "function") return {
                default: e
            };
            var n = Qd(t);
            if (n && n.has(e)) return n.get(e);
            var i = {
                    __proto__: null
                },
                a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var r in e)
                if (r !== "default" && Object.prototype.hasOwnProperty.call(e, r)) {
                    var o = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    o && (o.get || o.set) ? Object.defineProperty(i, r, o) : i[r] = e[r]
                }
            return i.default = e, n && n.set(e, i), i
        }
        var yA = new Map([
            [jn.ActionTypeConsts.PLUGIN_LOTTIE, { ...pA
            }],
            [jn.ActionTypeConsts.PLUGIN_SPLINE, { ...gA
            }],
            [jn.ActionTypeConsts.PLUGIN_RIVE, { ...EA
            }],
            [jn.ActionTypeConsts.PLUGIN_VARIABLE, { ...IA
            }]
        ])
    });
    var Kr = u(jr => {
        "use strict";
        Object.defineProperty(jr, "__esModule", {
            value: !0
        });

        function TA(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        TA(jr, {
            clearPlugin: function() {
                return RA
            },
            createPluginInstance: function() {
                return SA
            },
            getPluginConfig: function() {
                return _A
            },
            getPluginDestination: function() {
                return bA
            },
            getPluginDuration: function() {
                return hA
            },
            getPluginOrigin: function() {
                return OA
            },
            isPluginType: function() {
                return vA
            },
            renderPlugin: function() {
                return AA
            }
        });
        var mA = Yn(),
            Kd = jd();

        function vA(e) {
            return Kd.pluginMethodMap.has(e)
        }
        var ft = e => t => {
                if (!mA.IS_BROWSER_ENV) return () => null;
                let n = Kd.pluginMethodMap.get(t);
                if (!n) throw new Error(`IX2 no plugin configured for: ${t}`);
                let i = n[e];
                if (!i) throw new Error(`IX2 invalid plugin method: ${e}`);
                return i
            },
            _A = ft("getPluginConfig"),
            OA = ft("getPluginOrigin"),
            hA = ft("getPluginDuration"),
            bA = ft("getPluginDestination"),
            SA = ft("createPluginInstance"),
            AA = ft("renderPlugin"),
            RA = ft("clearPlugin")
    });
    var Zd = u((xw, $d) => {
        function LA(e, t) {
            return e == null || e !== e ? t : e
        }
        $d.exports = LA
    });
    var ef = u((Fw, Jd) => {
        function NA(e, t, n, i) {
            var a = -1,
                r = e == null ? 0 : e.length;
            for (i && r && (n = e[++a]); ++a < r;) n = t(n, e[a], a, e);
            return n
        }
        Jd.exports = NA
    });
    var nf = u((Dw, tf) => {
        function CA(e) {
            return function(t, n, i) {
                for (var a = -1, r = Object(t), o = i(t), s = o.length; s--;) {
                    var c = o[e ? s : ++a];
                    if (n(r[c], c, r) === !1) break
                }
                return t
            }
        }
        tf.exports = CA
    });
    var af = u((Vw, rf) => {
        var wA = nf(),
            PA = wA();
        rf.exports = PA
    });
    var $r = u((Uw, of ) => {
        var MA = af(),
            xA = en();

        function FA(e, t) {
            return e && MA(e, t, xA)
        } of .exports = FA
    });
    var cf = u((Gw, sf) => {
        var DA = lt();

        function VA(e, t) {
            return function(n, i) {
                if (n == null) return n;
                if (!DA(n)) return e(n, i);
                for (var a = n.length, r = t ? a : -1, o = Object(n);
                    (t ? r-- : ++r < a) && i(o[r], r, o) !== !1;);
                return n
            }
        }
        sf.exports = VA
    });
    var Zr = u((qw, uf) => {
        var UA = $r(),
            GA = cf(),
            qA = GA(UA);
        uf.exports = qA
    });
    var df = u((kw, lf) => {
        function kA(e, t, n, i, a) {
            return a(e, function(r, o, s) {
                n = i ? (i = !1, r) : t(n, r, o, s)
            }), n
        }
        lf.exports = kA
    });
    var pf = u((Xw, ff) => {
        var XA = ef(),
            BA = Zr(),
            YA = it(),
            WA = df(),
            HA = _e();

        function zA(e, t, n) {
            var i = HA(e) ? XA : WA,
                a = arguments.length < 3;
            return i(e, YA(t, 4), n, a, BA)
        }
        ff.exports = zA
    });
    var Ef = u((Bw, gf) => {
        var QA = Lr(),
            jA = it(),
            KA = Nr(),
            $A = Math.max,
            ZA = Math.min;

        function JA(e, t, n) {
            var i = e == null ? 0 : e.length;
            if (!i) return -1;
            var a = i - 1;
            return n !== void 0 && (a = KA(n), a = n < 0 ? $A(i + a, 0) : ZA(a, i - 1)), QA(e, jA(t, 3), a, !0)
        }
        gf.exports = JA
    });
    var yf = u((Yw, If) => {
        var e5 = Rr(),
            t5 = Ef(),
            n5 = e5(t5);
        If.exports = n5
    });
    var mf = u(Jr => {
        "use strict";
        Object.defineProperty(Jr, "__esModule", {
            value: !0
        });
        Object.defineProperty(Jr, "default", {
            enumerable: !0,
            get: function() {
                return r5
            }
        });

        function Tf(e, t) {
            return e === t ? e !== 0 || t !== 0 || 1 / e === 1 / t : e !== e && t !== t
        }

        function i5(e, t) {
            if (Tf(e, t)) return !0;
            if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
            let n = Object.keys(e),
                i = Object.keys(t);
            if (n.length !== i.length) return !1;
            for (let a = 0; a < n.length; a++)
                if (!Object.hasOwn(t, n[a]) || !Tf(e[n[a]], t[n[a]])) return !1;
            return !0
        }
        var r5 = i5
    });
    var Uf = u(ca => {
        "use strict";
        Object.defineProperty(ca, "__esModule", {
            value: !0
        });

        function a5(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        a5(ca, {
            cleanupHTMLElement: function() {
                return rR
            },
            clearAllStyles: function() {
                return iR
            },
            clearObjectCache: function() {
                return b5
            },
            getActionListProgress: function() {
                return oR
            },
            getAffectedElements: function() {
                return oa
            },
            getComputedStyle: function() {
                return P5
            },
            getDestinationValues: function() {
                return G5
            },
            getElementId: function() {
                return L5
            },
            getInstanceId: function() {
                return A5
            },
            getInstanceOrigin: function() {
                return F5
            },
            getItemConfigByKey: function() {
                return U5
            },
            getMaxDurationItemIndex: function() {
                return Vf
            },
            getNamespacedParameterId: function() {
                return uR
            },
            getRenderType: function() {
                return xf
            },
            getStyleProp: function() {
                return q5
            },
            mediaQueriesEqual: function() {
                return dR
            },
            observeStore: function() {
                return w5
            },
            reduceListToGroup: function() {
                return sR
            },
            reifyState: function() {
                return N5
            },
            renderHTMLElement: function() {
                return k5
            },
            shallowEqual: function() {
                return Rf.default
            },
            shouldAllowMediaQuery: function() {
                return lR
            },
            shouldNamespaceEventParameter: function() {
                return cR
            },
            stringifyTarget: function() {
                return fR
            }
        });
        var rt = ei(Zd()),
            na = ei(pf()),
            ta = ei(yf()),
            vf = bt(),
            pt = Re(),
            Rf = ei(mf()),
            o5 = Vr(),
            s5 = Hr(),
            ze = Kr(),
            Se = Yn();

        function ei(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var {
            BACKGROUND: c5,
            TRANSFORM: u5,
            TRANSLATE_3D: l5,
            SCALE_3D: d5,
            ROTATE_X: f5,
            ROTATE_Y: p5,
            ROTATE_Z: g5,
            SKEW: E5,
            PRESERVE_3D: I5,
            FLEX: y5,
            OPACITY: Zn,
            FILTER: an,
            FONT_VARIATION_SETTINGS: on,
            WIDTH: We,
            HEIGHT: He,
            BACKGROUND_COLOR: Lf,
            BORDER_COLOR: T5,
            COLOR: m5,
            CHILDREN: _f,
            IMMEDIATE_CHILDREN: v5,
            SIBLINGS: Of,
            PARENT: _5,
            DISPLAY: Jn,
            WILL_CHANGE: Mt,
            AUTO: at,
            COMMA_DELIMITER: sn,
            COLON_DELIMITER: O5,
            BAR_DELIMITER: ea,
            RENDER_TRANSFORM: Nf,
            RENDER_GENERAL: ia,
            RENDER_STYLE: ra,
            RENDER_PLUGIN: Cf
        } = pt.IX2EngineConstants, {
            TRANSFORM_MOVE: xt,
            TRANSFORM_SCALE: Ft,
            TRANSFORM_ROTATE: Dt,
            TRANSFORM_SKEW: cn,
            STYLE_OPACITY: wf,
            STYLE_FILTER: un,
            STYLE_FONT_VARIATION: ln,
            STYLE_SIZE: Vt,
            STYLE_BACKGROUND_COLOR: Ut,
            STYLE_BORDER: Gt,
            STYLE_TEXT_COLOR: qt,
            GENERAL_DISPLAY: ti,
            OBJECT_VALUE: h5
        } = pt.ActionTypeConsts, Pf = e => e.trim(), aa = Object.freeze({
            [Ut]: Lf,
            [Gt]: T5,
            [qt]: m5
        }), Mf = Object.freeze({
            [Se.TRANSFORM_PREFIXED]: u5,
            [Lf]: c5,
            [Zn]: Zn,
            [an]: an,
            [We]: We,
            [He]: He,
            [on]: on
        }), $n = new Map;

        function b5() {
            $n.clear()
        }
        var S5 = 1;

        function A5() {
            return "i" + S5++
        }
        var R5 = 1;

        function L5(e, t) {
            for (let n in e) {
                let i = e[n];
                if (i && i.ref === t) return i.id
            }
            return "e" + R5++
        }

        function N5({
            events: e,
            actionLists: t,
            site: n
        } = {}) {
            let i = (0, na.default)(e, (o, s) => {
                    let {
                        eventTypeId: c
                    } = s;
                    return o[c] || (o[c] = {}), o[c][s.id] = s, o
                }, {}),
                a = n && n.mediaQueries,
                r = [];
            return a ? r = a.map(o => o.key) : (a = [], console.warn("IX2 missing mediaQueries in site data")), {
                ixData: {
                    events: e,
                    actionLists: t,
                    eventTypeMap: i,
                    mediaQueries: a,
                    mediaQueryKeys: r
                }
            }
        }
        var C5 = (e, t) => e === t;

        function w5({
            store: e,
            select: t,
            onChange: n,
            comparator: i = C5
        }) {
            let {
                getState: a,
                subscribe: r
            } = e, o = r(c), s = t(a());

            function c() {
                let d = t(a());
                if (d == null) {
                    o();
                    return
                }
                i(d, s) || (s = d, n(s, e))
            }
            return o
        }

        function hf(e) {
            let t = typeof e;
            if (t === "string") return {
                id: e
            };
            if (e != null && t === "object") {
                let {
                    id: n,
                    objectId: i,
                    selector: a,
                    selectorGuids: r,
                    appliesTo: o,
                    useEventTarget: s
                } = e;
                return {
                    id: n,
                    objectId: i,
                    selector: a,
                    selectorGuids: r,
                    appliesTo: o,
                    useEventTarget: s
                }
            }
            return {}
        }

        function oa({
            config: e,
            event: t,
            eventTarget: n,
            elementRoot: i,
            elementApi: a
        }) {
            if (!a) throw new Error("IX2 missing elementApi");
            let {
                targets: r
            } = e;
            if (Array.isArray(r) && r.length > 0) return r.reduce((x, O) => x.concat(oa({
                config: {
                    target: O
                },
                event: t,
                eventTarget: n,
                elementRoot: i,
                elementApi: a
            })), []);
            let {
                getValidDocument: o,
                getQuerySelector: s,
                queryDocument: c,
                getChildElements: d,
                getSiblingElements: I,
                matchSelector: E,
                elementContains: p,
                isSiblingNode: g
            } = a, {
                target: v
            } = e;
            if (!v) return [];
            let {
                id: m,
                objectId: h,
                selector: T,
                selectorGuids: A,
                appliesTo: b,
                useEventTarget: N
            } = hf(v);
            if (h) return [$n.has(h) ? $n.get(h) : $n.set(h, {}).get(h)];
            if (b === pt.EventAppliesTo.PAGE) {
                let x = o(m);
                return x ? [x] : []
            }
            let C = (t ? .action ? .config ? .affectedElements ? ? {})[m || T] || {},
                G = !!(C.id || C.selector),
                X, B, z, J = t && s(hf(t.target));
            if (G ? (X = C.limitAffectedElements, B = J, z = s(C)) : B = z = s({
                    id: m,
                    selector: T,
                    selectorGuids: A
                }), t && N) {
                let x = n && (z || N === !0) ? [n] : c(J);
                if (z) {
                    if (N === _5) return c(z).filter(O => x.some(M => p(O, M)));
                    if (N === _f) return c(z).filter(O => x.some(M => p(M, O)));
                    if (N === Of) return c(z).filter(O => x.some(M => g(M, O)))
                }
                return x
            }
            return B == null || z == null ? [] : Se.IS_BROWSER_ENV && i ? c(z).filter(x => i.contains(x)) : X === _f ? c(B, z) : X === v5 ? d(c(B)).filter(E(z)) : X === Of ? I(c(B)).filter(E(z)) : c(z)
        }

        function P5({
            element: e,
            actionItem: t
        }) {
            if (!Se.IS_BROWSER_ENV) return {};
            let {
                actionTypeId: n
            } = t;
            switch (n) {
                case Vt:
                case Ut:
                case Gt:
                case qt:
                case ti:
                    return window.getComputedStyle(e);
                default:
                    return {}
            }
        }
        var bf = /px/,
            M5 = (e, t) => t.reduce((n, i) => (n[i.type] == null && (n[i.type] = X5[i.type]), n), e || {}),
            x5 = (e, t) => t.reduce((n, i) => (n[i.type] == null && (n[i.type] = B5[i.type] || i.defaultValue || 0), n), e || {});

        function F5(e, t = {}, n = {}, i, a) {
            let {
                getStyle: r
            } = a, {
                actionTypeId: o
            } = i;
            if ((0, ze.isPluginType)(o)) return (0, ze.getPluginOrigin)(o)(t[o], i);
            switch (i.actionTypeId) {
                case xt:
                case Ft:
                case Dt:
                case cn:
                    return t[i.actionTypeId] || sa[i.actionTypeId];
                case un:
                    return M5(t[i.actionTypeId], i.config.filters);
                case ln:
                    return x5(t[i.actionTypeId], i.config.fontVariations);
                case wf:
                    return {
                        value: (0, rt.default)(parseFloat(r(e, Zn)), 1)
                    };
                case Vt:
                    {
                        let s = r(e, We),
                            c = r(e, He),
                            d, I;
                        return i.config.widthUnit === at ? d = bf.test(s) ? parseFloat(s) : parseFloat(n.width) : d = (0, rt.default)(parseFloat(s), parseFloat(n.width)),
                        i.config.heightUnit === at ? I = bf.test(c) ? parseFloat(c) : parseFloat(n.height) : I = (0, rt.default)(parseFloat(c), parseFloat(n.height)),
                        {
                            widthValue: d,
                            heightValue: I
                        }
                    }
                case Ut:
                case Gt:
                case qt:
                    return eR({
                        element: e,
                        actionTypeId: i.actionTypeId,
                        computedStyle: n,
                        getStyle: r
                    });
                case ti:
                    return {
                        value: (0, rt.default)(r(e, Jn), n.display)
                    };
                case h5:
                    return t[i.actionTypeId] || {
                        value: 0
                    };
                default:
                    return
            }
        }
        var D5 = (e, t) => (t && (e[t.type] = t.value || 0), e),
            V5 = (e, t) => (t && (e[t.type] = t.value || 0), e),
            U5 = (e, t, n) => {
                if ((0, ze.isPluginType)(e)) return (0, ze.getPluginConfig)(e)(n, t);
                switch (e) {
                    case un:
                        {
                            let i = (0, ta.default)(n.filters, ({
                                type: a
                            }) => a === t);
                            return i ? i.value : 0
                        }
                    case ln:
                        {
                            let i = (0, ta.default)(n.fontVariations, ({
                                type: a
                            }) => a === t);
                            return i ? i.value : 0
                        }
                    default:
                        return n[t]
                }
            };

        function G5({
            element: e,
            actionItem: t,
            elementApi: n
        }) {
            if ((0, ze.isPluginType)(t.actionTypeId)) return (0, ze.getPluginDestination)(t.actionTypeId)(t.config);
            switch (t.actionTypeId) {
                case xt:
                case Ft:
                case Dt:
                case cn:
                    {
                        let {
                            xValue: i,
                            yValue: a,
                            zValue: r
                        } = t.config;
                        return {
                            xValue: i,
                            yValue: a,
                            zValue: r
                        }
                    }
                case Vt:
                    {
                        let {
                            getStyle: i,
                            setStyle: a,
                            getProperty: r
                        } = n,
                        {
                            widthUnit: o,
                            heightUnit: s
                        } = t.config,
                        {
                            widthValue: c,
                            heightValue: d
                        } = t.config;
                        if (!Se.IS_BROWSER_ENV) return {
                            widthValue: c,
                            heightValue: d
                        };
                        if (o === at) {
                            let I = i(e, We);
                            a(e, We, ""), c = r(e, "offsetWidth"), a(e, We, I)
                        }
                        if (s === at) {
                            let I = i(e, He);
                            a(e, He, ""), d = r(e, "offsetHeight"), a(e, He, I)
                        }
                        return {
                            widthValue: c,
                            heightValue: d
                        }
                    }
                case Ut:
                case Gt:
                case qt:
                    {
                        let {
                            rValue: i,
                            gValue: a,
                            bValue: r,
                            aValue: o,
                            globalSwatchId: s
                        } = t.config;
                        if (s && s.startsWith("--")) {
                            let {
                                getStyle: c
                            } = n, d = c(e, s), I = (0, s5.normalizeColor)(d);
                            return {
                                rValue: I.red,
                                gValue: I.green,
                                bValue: I.blue,
                                aValue: I.alpha
                            }
                        }
                        return {
                            rValue: i,
                            gValue: a,
                            bValue: r,
                            aValue: o
                        }
                    }
                case un:
                    return t.config.filters.reduce(D5, {});
                case ln:
                    return t.config.fontVariations.reduce(V5, {});
                default:
                    {
                        let {
                            value: i
                        } = t.config;
                        return {
                            value: i
                        }
                    }
            }
        }

        function xf(e) {
            if (/^TRANSFORM_/.test(e)) return Nf;
            if (/^STYLE_/.test(e)) return ra;
            if (/^GENERAL_/.test(e)) return ia;
            if (/^PLUGIN_/.test(e)) return Cf
        }

        function q5(e, t) {
            return e === ra ? t.replace("STYLE_", "").toLowerCase() : null
        }

        function k5(e, t, n, i, a, r, o, s, c) {
            switch (s) {
                case Nf:
                    return H5(e, t, n, a, o);
                case ra:
                    return tR(e, t, n, a, r, o);
                case ia:
                    return nR(e, a, o);
                case Cf:
                    {
                        let {
                            actionTypeId: d
                        } = a;
                        if ((0, ze.isPluginType)(d)) return (0, ze.renderPlugin)(d)(c, t, a)
                    }
            }
        }
        var sa = {
                [xt]: Object.freeze({
                    xValue: 0,
                    yValue: 0,
                    zValue: 0
                }),
                [Ft]: Object.freeze({
                    xValue: 1,
                    yValue: 1,
                    zValue: 1
                }),
                [Dt]: Object.freeze({
                    xValue: 0,
                    yValue: 0,
                    zValue: 0
                }),
                [cn]: Object.freeze({
                    xValue: 0,
                    yValue: 0
                })
            },
            X5 = Object.freeze({
                blur: 0,
                "hue-rotate": 0,
                invert: 0,
                grayscale: 0,
                saturate: 100,
                sepia: 0,
                contrast: 100,
                brightness: 100
            }),
            B5 = Object.freeze({
                wght: 0,
                opsz: 0,
                wdth: 0,
                slnt: 0
            }),
            Y5 = (e, t) => {
                let n = (0, ta.default)(t.filters, ({
                    type: i
                }) => i === e);
                if (n && n.unit) return n.unit;
                switch (e) {
                    case "blur":
                        return "px";
                    case "hue-rotate":
                        return "deg";
                    default:
                        return "%"
                }
            },
            W5 = Object.keys(sa);

        function H5(e, t, n, i, a) {
            let r = W5.map(s => {
                    let c = sa[s],
                        {
                            xValue: d = c.xValue,
                            yValue: I = c.yValue,
                            zValue: E = c.zValue,
                            xUnit: p = "",
                            yUnit: g = "",
                            zUnit: v = ""
                        } = t[s] || {};
                    switch (s) {
                        case xt:
                            return `${l5}(${d}${p}, ${I}${g}, ${E}${v})`;
                        case Ft:
                            return `${d5}(${d}${p}, ${I}${g}, ${E}${v})`;
                        case Dt:
                            return `${f5}(${d}${p}) ${p5}(${I}${g}) ${g5}(${E}${v})`;
                        case cn:
                            return `${E5}(${d}${p}, ${I}${g})`;
                        default:
                            return ""
                    }
                }).join(" "),
                {
                    setStyle: o
                } = a;
            gt(e, Se.TRANSFORM_PREFIXED, a), o(e, Se.TRANSFORM_PREFIXED, r), j5(i, n) && o(e, Se.TRANSFORM_STYLE_PREFIXED, I5)
        }

        function z5(e, t, n, i) {
            let a = (0, na.default)(t, (o, s, c) => `${o} ${c}(${s}${Y5(c,n)})`, ""),
                {
                    setStyle: r
                } = i;
            gt(e, an, i), r(e, an, a)
        }

        function Q5(e, t, n, i) {
            let a = (0, na.default)(t, (o, s, c) => (o.push(`"${c}" ${s}`), o), []).join(", "),
                {
                    setStyle: r
                } = i;
            gt(e, on, i), r(e, on, a)
        }

        function j5({
            actionTypeId: e
        }, {
            xValue: t,
            yValue: n,
            zValue: i
        }) {
            return e === xt && i !== void 0 || e === Ft && i !== void 0 || e === Dt && (t !== void 0 || n !== void 0)
        }
        var K5 = "\\(([^)]+)\\)",
            $5 = /^rgb/,
            Z5 = RegExp(`rgba?${K5}`);

        function J5(e, t) {
            let n = e.exec(t);
            return n ? n[1] : ""
        }

        function eR({
            element: e,
            actionTypeId: t,
            computedStyle: n,
            getStyle: i
        }) {
            let a = aa[t],
                r = i(e, a),
                o = $5.test(r) ? r : n[a],
                s = J5(Z5, o).split(sn);
            return {
                rValue: (0, rt.default)(parseInt(s[0], 10), 255),
                gValue: (0, rt.default)(parseInt(s[1], 10), 255),
                bValue: (0, rt.default)(parseInt(s[2], 10), 255),
                aValue: (0, rt.default)(parseFloat(s[3]), 1)
            }
        }

        function tR(e, t, n, i, a, r) {
            let {
                setStyle: o
            } = r;
            switch (i.actionTypeId) {
                case Vt:
                    {
                        let {
                            widthUnit: s = "",
                            heightUnit: c = ""
                        } = i.config,
                        {
                            widthValue: d,
                            heightValue: I
                        } = n;d !== void 0 && (s === at && (s = "px"), gt(e, We, r), o(e, We, d + s)),
                        I !== void 0 && (c === at && (c = "px"), gt(e, He, r), o(e, He, I + c));
                        break
                    }
                case un:
                    {
                        z5(e, n, i.config, r);
                        break
                    }
                case ln:
                    {
                        Q5(e, n, i.config, r);
                        break
                    }
                case Ut:
                case Gt:
                case qt:
                    {
                        let s = aa[i.actionTypeId],
                            c = Math.round(n.rValue),
                            d = Math.round(n.gValue),
                            I = Math.round(n.bValue),
                            E = n.aValue;gt(e, s, r),
                        o(e, s, E >= 1 ? `rgb(${c},${d},${I})` : `rgba(${c},${d},${I},${E})`);
                        break
                    }
                default:
                    {
                        let {
                            unit: s = ""
                        } = i.config;gt(e, a, r),
                        o(e, a, n.value + s);
                        break
                    }
            }
        }

        function nR(e, t, n) {
            let {
                setStyle: i
            } = n;
            switch (t.actionTypeId) {
                case ti:
                    {
                        let {
                            value: a
                        } = t.config;a === y5 && Se.IS_BROWSER_ENV ? i(e, Jn, Se.FLEX_PREFIXED) : i(e, Jn, a);
                        return
                    }
            }
        }

        function gt(e, t, n) {
            if (!Se.IS_BROWSER_ENV) return;
            let i = Mf[t];
            if (!i) return;
            let {
                getStyle: a,
                setStyle: r
            } = n, o = a(e, Mt);
            if (!o) {
                r(e, Mt, i);
                return
            }
            let s = o.split(sn).map(Pf);
            s.indexOf(i) === -1 && r(e, Mt, s.concat(i).join(sn))
        }

        function Ff(e, t, n) {
            if (!Se.IS_BROWSER_ENV) return;
            let i = Mf[t];
            if (!i) return;
            let {
                getStyle: a,
                setStyle: r
            } = n, o = a(e, Mt);
            !o || o.indexOf(i) === -1 || r(e, Mt, o.split(sn).map(Pf).filter(s => s !== i).join(sn))
        }

        function iR({
            store: e,
            elementApi: t
        }) {
            let {
                ixData: n
            } = e.getState(), {
                events: i = {},
                actionLists: a = {}
            } = n;
            Object.keys(i).forEach(r => {
                let o = i[r],
                    {
                        config: s
                    } = o.action,
                    {
                        actionListId: c
                    } = s,
                    d = a[c];
                d && Sf({
                    actionList: d,
                    event: o,
                    elementApi: t
                })
            }), Object.keys(a).forEach(r => {
                Sf({
                    actionList: a[r],
                    elementApi: t
                })
            })
        }

        function Sf({
            actionList: e = {},
            event: t,
            elementApi: n
        }) {
            let {
                actionItemGroups: i,
                continuousParameterGroups: a
            } = e;
            i && i.forEach(r => {
                Af({
                    actionGroup: r,
                    event: t,
                    elementApi: n
                })
            }), a && a.forEach(r => {
                let {
                    continuousActionGroups: o
                } = r;
                o.forEach(s => {
                    Af({
                        actionGroup: s,
                        event: t,
                        elementApi: n
                    })
                })
            })
        }

        function Af({
            actionGroup: e,
            event: t,
            elementApi: n
        }) {
            let {
                actionItems: i
            } = e;
            i.forEach(a => {
                let {
                    actionTypeId: r,
                    config: o
                } = a, s;
                (0, ze.isPluginType)(r) ? s = c => (0, ze.clearPlugin)(r)(c, a): s = Df({
                    effect: aR,
                    actionTypeId: r,
                    elementApi: n
                }), oa({
                    config: o,
                    event: t,
                    elementApi: n
                }).forEach(s)
            })
        }

        function rR(e, t, n) {
            let {
                setStyle: i,
                getStyle: a
            } = n, {
                actionTypeId: r
            } = t;
            if (r === Vt) {
                let {
                    config: o
                } = t;
                o.widthUnit === at && i(e, We, ""), o.heightUnit === at && i(e, He, "")
            }
            a(e, Mt) && Df({
                effect: Ff,
                actionTypeId: r,
                elementApi: n
            })(e)
        }
        var Df = ({
            effect: e,
            actionTypeId: t,
            elementApi: n
        }) => i => {
            switch (t) {
                case xt:
                case Ft:
                case Dt:
                case cn:
                    e(i, Se.TRANSFORM_PREFIXED, n);
                    break;
                case un:
                    e(i, an, n);
                    break;
                case ln:
                    e(i, on, n);
                    break;
                case wf:
                    e(i, Zn, n);
                    break;
                case Vt:
                    e(i, We, n), e(i, He, n);
                    break;
                case Ut:
                case Gt:
                case qt:
                    e(i, aa[t], n);
                    break;
                case ti:
                    e(i, Jn, n);
                    break
            }
        };

        function aR(e, t, n) {
            let {
                setStyle: i
            } = n;
            Ff(e, t, n), i(e, t, ""), t === Se.TRANSFORM_PREFIXED && i(e, Se.TRANSFORM_STYLE_PREFIXED, "")
        }

        function Vf(e) {
            let t = 0,
                n = 0;
            return e.forEach((i, a) => {
                let {
                    config: r
                } = i, o = r.delay + r.duration;
                o >= t && (t = o, n = a)
            }), n
        }

        function oR(e, t) {
            let {
                actionItemGroups: n,
                useFirstGroupAsInitialState: i
            } = e, {
                actionItem: a,
                verboseTimeElapsed: r = 0
            } = t, o = 0, s = 0;
            return n.forEach((c, d) => {
                if (i && d === 0) return;
                let {
                    actionItems: I
                } = c, E = I[Vf(I)], {
                    config: p,
                    actionTypeId: g
                } = E;
                a.id === E.id && (s = o + r);
                let v = xf(g) === ia ? 0 : p.duration;
                o += p.delay + v
            }), o > 0 ? (0, o5.optimizeFloat)(s / o) : 0
        }

        function sR({
            actionList: e,
            actionItemId: t,
            rawData: n
        }) {
            let {
                actionItemGroups: i,
                continuousParameterGroups: a
            } = e, r = [], o = s => (r.push((0, vf.mergeIn)(s, ["config"], {
                delay: 0,
                duration: 0
            })), s.id === t);
            return i && i.some(({
                actionItems: s
            }) => s.some(o)), a && a.some(s => {
                let {
                    continuousActionGroups: c
                } = s;
                return c.some(({
                    actionItems: d
                }) => d.some(o))
            }), (0, vf.setIn)(n, ["actionLists"], {
                [e.id]: {
                    id: e.id,
                    actionItemGroups: [{
                        actionItems: r
                    }]
                }
            })
        }

        function cR(e, {
            basedOn: t
        }) {
            return e === pt.EventTypeConsts.SCROLLING_IN_VIEW && (t === pt.EventBasedOn.ELEMENT || t == null) || e === pt.EventTypeConsts.MOUSE_MOVE && t === pt.EventBasedOn.ELEMENT
        }

        function uR(e, t) {
            return e + O5 + t
        }

        function lR(e, t) {
            return t == null ? !0 : e.indexOf(t) !== -1
        }

        function dR(e, t) {
            return (0, Rf.default)(e && e.sort(), t && t.sort())
        }

        function fR(e) {
            if (typeof e == "string") return e;
            if (e.pluginElement && e.objectId) return e.pluginElement + ea + e.objectId;
            if (e.objectId) return e.objectId;
            let {
                id: t = "",
                selector: n = "",
                useEventTarget: i = ""
            } = e;
            return t + ea + n + ea + i
        }
    });
    var Et = u(ua => {
        "use strict";
        Object.defineProperty(ua, "__esModule", {
            value: !0
        });

        function pR(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        pR(ua, {
            IX2BrowserSupport: function() {
                return gR
            },
            IX2EasingUtils: function() {
                return IR
            },
            IX2Easings: function() {
                return ER
            },
            IX2ElementsReducer: function() {
                return yR
            },
            IX2VanillaPlugins: function() {
                return TR
            },
            IX2VanillaUtils: function() {
                return mR
            }
        });
        var gR = kt(Yn()),
            ER = kt(xr()),
            IR = kt(Vr()),
            yR = kt(kd()),
            TR = kt(Kr()),
            mR = kt(Uf());

        function Gf(e) {
            if (typeof WeakMap != "function") return null;
            var t = new WeakMap,
                n = new WeakMap;
            return (Gf = function(i) {
                return i ? n : t
            })(e)
        }

        function kt(e, t) {
            if (!t && e && e.__esModule) return e;
            if (e === null || typeof e != "object" && typeof e != "function") return {
                default: e
            };
            var n = Gf(t);
            if (n && n.has(e)) return n.get(e);
            var i = {
                    __proto__: null
                },
                a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var r in e)
                if (r !== "default" && Object.prototype.hasOwnProperty.call(e, r)) {
                    var o = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    o && (o.get || o.set) ? Object.defineProperty(i, r, o) : i[r] = e[r]
                }
            return i.default = e, n && n.set(e, i), i
        }
    });
    var Bf = u(da => {
        "use strict";
        Object.defineProperty(da, "__esModule", {
            value: !0
        });
        Object.defineProperty(da, "ixInstances", {
            enumerable: !0,
            get: function() {
                return PR
            }
        });
        var qf = Re(),
            kf = Et(),
            Xt = bt(),
            {
                IX2_RAW_DATA_IMPORTED: vR,
                IX2_SESSION_STOPPED: _R,
                IX2_INSTANCE_ADDED: OR,
                IX2_INSTANCE_STARTED: hR,
                IX2_INSTANCE_REMOVED: bR,
                IX2_ANIMATION_FRAME_CHANGED: SR
            } = qf.IX2EngineActionTypes,
            {
                optimizeFloat: ni,
                applyEasing: Xf,
                createBezierEasing: AR
            } = kf.IX2EasingUtils,
            {
                RENDER_GENERAL: RR
            } = qf.IX2EngineConstants,
            {
                getItemConfigByKey: la,
                getRenderType: LR,
                getStyleProp: NR
            } = kf.IX2VanillaUtils,
            CR = (e, t) => {
                let {
                    position: n,
                    parameterId: i,
                    actionGroups: a,
                    destinationKeys: r,
                    smoothing: o,
                    restingValue: s,
                    actionTypeId: c,
                    customEasingFn: d,
                    skipMotion: I,
                    skipToValue: E
                } = e, {
                    parameters: p
                } = t.payload, g = Math.max(1 - o, .01), v = p[i];
                v == null && (g = 1, v = s);
                let m = Math.max(v, 0) || 0,
                    h = ni(m - n),
                    T = I ? E : ni(n + h * g),
                    A = T * 100;
                if (T === n && e.current) return e;
                let b, N, P, C;
                for (let X = 0, {
                        length: B
                    } = a; X < B; X++) {
                    let {
                        keyframe: z,
                        actionItems: J
                    } = a[X];
                    if (X === 0 && (b = J[0]), A >= z) {
                        b = J[0];
                        let x = a[X + 1],
                            O = x && A !== z;
                        N = O ? x.actionItems[0] : null, O && (P = z / 100, C = (x.keyframe - z) / 100)
                    }
                }
                let G = {};
                if (b && !N)
                    for (let X = 0, {
                            length: B
                        } = r; X < B; X++) {
                        let z = r[X];
                        G[z] = la(c, z, b.config)
                    } else if (b && N && P !== void 0 && C !== void 0) {
                        let X = (T - P) / C,
                            B = b.config.easing,
                            z = Xf(B, X, d);
                        for (let J = 0, {
                                length: x
                            } = r; J < x; J++) {
                            let O = r[J],
                                M = la(c, O, b.config),
                                ee = (la(c, O, N.config) - M) * z + M;
                            G[O] = ee
                        }
                    }
                return (0, Xt.merge)(e, {
                    position: T,
                    current: G
                })
            },
            wR = (e, t) => {
                let {
                    active: n,
                    origin: i,
                    start: a,
                    immediate: r,
                    renderType: o,
                    verbose: s,
                    actionItem: c,
                    destination: d,
                    destinationKeys: I,
                    pluginDuration: E,
                    instanceDelay: p,
                    customEasingFn: g,
                    skipMotion: v
                } = e, m = c.config.easing, {
                    duration: h,
                    delay: T
                } = c.config;
                E != null && (h = E), T = p ? ? T, o === RR ? h = 0 : (r || v) && (h = T = 0);
                let {
                    now: A
                } = t.payload;
                if (n && i) {
                    let b = A - (a + T);
                    if (s) {
                        let X = A - a,
                            B = h + T,
                            z = ni(Math.min(Math.max(0, X / B), 1));
                        e = (0, Xt.set)(e, "verboseTimeElapsed", B * z)
                    }
                    if (b < 0) return e;
                    let N = ni(Math.min(Math.max(0, b / h), 1)),
                        P = Xf(m, N, g),
                        C = {},
                        G = null;
                    return I.length && (G = I.reduce((X, B) => {
                        let z = d[B],
                            J = parseFloat(i[B]) || 0,
                            O = (parseFloat(z) - J) * P + J;
                        return X[B] = O, X
                    }, {})), C.current = G, C.position = N, N === 1 && (C.active = !1, C.complete = !0), (0, Xt.merge)(e, C)
                }
                return e
            },
            PR = (e = Object.freeze({}), t) => {
                switch (t.type) {
                    case vR:
                        return t.payload.ixInstances || Object.freeze({});
                    case _R:
                        return Object.freeze({});
                    case OR:
                        {
                            let {
                                instanceId: n,
                                elementId: i,
                                actionItem: a,
                                eventId: r,
                                eventTarget: o,
                                eventStateKey: s,
                                actionListId: c,
                                groupIndex: d,
                                isCarrier: I,
                                origin: E,
                                destination: p,
                                immediate: g,
                                verbose: v,
                                continuous: m,
                                parameterId: h,
                                actionGroups: T,
                                smoothing: A,
                                restingValue: b,
                                pluginInstance: N,
                                pluginDuration: P,
                                instanceDelay: C,
                                skipMotion: G,
                                skipToValue: X
                            } = t.payload,
                            {
                                actionTypeId: B
                            } = a,
                            z = LR(B),
                            J = NR(z, B),
                            x = Object.keys(p).filter(M => p[M] != null && typeof p[M] != "string"),
                            {
                                easing: O
                            } = a.config;
                            return (0, Xt.set)(e, n, {
                                id: n,
                                elementId: i,
                                active: !1,
                                position: 0,
                                start: 0,
                                origin: E,
                                destination: p,
                                destinationKeys: x,
                                immediate: g,
                                verbose: v,
                                current: null,
                                actionItem: a,
                                actionTypeId: B,
                                eventId: r,
                                eventTarget: o,
                                eventStateKey: s,
                                actionListId: c,
                                groupIndex: d,
                                renderType: z,
                                isCarrier: I,
                                styleProp: J,
                                continuous: m,
                                parameterId: h,
                                actionGroups: T,
                                smoothing: A,
                                restingValue: b,
                                pluginInstance: N,
                                pluginDuration: P,
                                instanceDelay: C,
                                skipMotion: G,
                                skipToValue: X,
                                customEasingFn: Array.isArray(O) && O.length === 4 ? AR(O) : void 0
                            })
                        }
                    case hR:
                        {
                            let {
                                instanceId: n,
                                time: i
                            } = t.payload;
                            return (0, Xt.mergeIn)(e, [n], {
                                active: !0,
                                complete: !1,
                                start: i
                            })
                        }
                    case bR:
                        {
                            let {
                                instanceId: n
                            } = t.payload;
                            if (!e[n]) return e;
                            let i = {},
                                a = Object.keys(e),
                                {
                                    length: r
                                } = a;
                            for (let o = 0; o < r; o++) {
                                let s = a[o];
                                s !== n && (i[s] = e[s])
                            }
                            return i
                        }
                    case SR:
                        {
                            let n = e,
                                i = Object.keys(e),
                                {
                                    length: a
                                } = i;
                            for (let r = 0; r < a; r++) {
                                let o = i[r],
                                    s = e[o],
                                    c = s.continuous ? CR : wR;
                                n = (0, Xt.set)(n, o, c(s, t))
                            }
                            return n
                        }
                    default:
                        return e
                }
            }
    });
    var Yf = u(fa => {
        "use strict";
        Object.defineProperty(fa, "__esModule", {
            value: !0
        });
        Object.defineProperty(fa, "ixParameters", {
            enumerable: !0,
            get: function() {
                return VR
            }
        });
        var MR = Re(),
            {
                IX2_RAW_DATA_IMPORTED: xR,
                IX2_SESSION_STOPPED: FR,
                IX2_PARAMETER_CHANGED: DR
            } = MR.IX2EngineActionTypes,
            VR = (e = {}, t) => {
                switch (t.type) {
                    case xR:
                        return t.payload.ixParameters || {};
                    case FR:
                        return {};
                    case DR:
                        {
                            let {
                                key: n,
                                value: i
                            } = t.payload;
                            return e[n] = i,
                            e
                        }
                    default:
                        return e
                }
            }
    });
    var Wf = u(pa => {
        "use strict";
        Object.defineProperty(pa, "__esModule", {
            value: !0
        });
        Object.defineProperty(pa, "default", {
            enumerable: !0,
            get: function() {
                return HR
            }
        });
        var UR = Wi(),
            GR = rs(),
            qR = hs(),
            kR = Ss(),
            XR = Et(),
            BR = Bf(),
            YR = Yf(),
            {
                ixElements: WR
            } = XR.IX2ElementsReducer,
            HR = (0, UR.combineReducers)({
                ixData: GR.ixData,
                ixRequest: qR.ixRequest,
                ixSession: kR.ixSession,
                ixElements: WR,
                ixInstances: BR.ixInstances,
                ixParameters: YR.ixParameters
            })
    });
    var zf = u(($w, Hf) => {
        var zR = tt(),
            QR = _e(),
            jR = Ke(),
            KR = "[object String]";

        function $R(e) {
            return typeof e == "string" || !QR(e) && jR(e) && zR(e) == KR
        }
        Hf.exports = $R
    });
    var jf = u((Zw, Qf) => {
        var ZR = Ar(),
            JR = ZR("length");
        Qf.exports = JR
    });
    var $f = u((Jw, Kf) => {
        var eL = "\\ud800-\\udfff",
            tL = "\\u0300-\\u036f",
            nL = "\\ufe20-\\ufe2f",
            iL = "\\u20d0-\\u20ff",
            rL = tL + nL + iL,
            aL = "\\ufe0e\\ufe0f",
            oL = "\\u200d",
            sL = RegExp("[" + oL + eL + rL + aL + "]");

        function cL(e) {
            return sL.test(e)
        }
        Kf.exports = cL
    });
    var op = u((eP, ap) => {
        var Jf = "\\ud800-\\udfff",
            uL = "\\u0300-\\u036f",
            lL = "\\ufe20-\\ufe2f",
            dL = "\\u20d0-\\u20ff",
            fL = uL + lL + dL,
            pL = "\\ufe0e\\ufe0f",
            gL = "[" + Jf + "]",
            ga = "[" + fL + "]",
            Ea = "\\ud83c[\\udffb-\\udfff]",
            EL = "(?:" + ga + "|" + Ea + ")",
            ep = "[^" + Jf + "]",
            tp = "(?:\\ud83c[\\udde6-\\uddff]){2}",
            np = "[\\ud800-\\udbff][\\udc00-\\udfff]",
            IL = "\\u200d",
            ip = EL + "?",
            rp = "[" + pL + "]?",
            yL = "(?:" + IL + "(?:" + [ep, tp, np].join("|") + ")" + rp + ip + ")*",
            TL = rp + ip + yL,
            mL = "(?:" + [ep + ga + "?", ga, tp, np, gL].join("|") + ")",
            Zf = RegExp(Ea + "(?=" + Ea + ")|" + mL + TL, "g");

        function vL(e) {
            for (var t = Zf.lastIndex = 0; Zf.test(e);) ++t;
            return t
        }
        ap.exports = vL
    });
    var cp = u((tP, sp) => {
        var _L = jf(),
            OL = $f(),
            hL = op();

        function bL(e) {
            return OL(e) ? hL(e) : _L(e)
        }
        sp.exports = bL
    });
    var lp = u((nP, up) => {
        var SL = Fn(),
            AL = Dn(),
            RL = lt(),
            LL = zf(),
            NL = cp(),
            CL = "[object Map]",
            wL = "[object Set]";

        function PL(e) {
            if (e == null) return 0;
            if (RL(e)) return LL(e) ? NL(e) : e.length;
            var t = AL(e);
            return t == CL || t == wL ? e.size : SL(e).length
        }
        up.exports = PL
    });
    var fp = u((iP, dp) => {
        var ML = "Expected a function";

        function xL(e) {
            if (typeof e != "function") throw new TypeError(ML);
            return function() {
                var t = arguments;
                switch (t.length) {
                    case 0:
                        return !e.call(this);
                    case 1:
                        return !e.call(this, t[0]);
                    case 2:
                        return !e.call(this, t[0], t[1]);
                    case 3:
                        return !e.call(this, t[0], t[1], t[2])
                }
                return !e.apply(this, t)
            }
        }
        dp.exports = xL
    });
    var Ia = u((rP, pp) => {
        var FL = nt(),
            DL = function() {
                try {
                    var e = FL(Object, "defineProperty");
                    return e({}, "", {}), e
                } catch {}
            }();
        pp.exports = DL
    });
    var ya = u((aP, Ep) => {
        var gp = Ia();

        function VL(e, t, n) {
            t == "__proto__" && gp ? gp(e, t, {
                configurable: !0,
                enumerable: !0,
                value: n,
                writable: !0
            }) : e[t] = n
        }
        Ep.exports = VL
    });
    var yp = u((oP, Ip) => {
        var UL = ya(),
            GL = Sn(),
            qL = Object.prototype,
            kL = qL.hasOwnProperty;

        function XL(e, t, n) {
            var i = e[t];
            (!(kL.call(e, t) && GL(i, n)) || n === void 0 && !(t in e)) && UL(e, t, n)
        }
        Ip.exports = XL
    });
    var vp = u((sP, mp) => {
        var BL = yp(),
            YL = nn(),
            WL = wn(),
            Tp = Ye(),
            HL = Pt();

        function zL(e, t, n, i) {
            if (!Tp(e)) return e;
            t = YL(t, e);
            for (var a = -1, r = t.length, o = r - 1, s = e; s != null && ++a < r;) {
                var c = HL(t[a]),
                    d = n;
                if (c === "__proto__" || c === "constructor" || c === "prototype") return e;
                if (a != o) {
                    var I = s[c];
                    d = i ? i(I, c, s) : void 0, d === void 0 && (d = Tp(I) ? I : WL(t[a + 1]) ? [] : {})
                }
                BL(s, c, d), s = s[c]
            }
            return e
        }
        mp.exports = zL
    });
    var Op = u((cP, _p) => {
        var QL = Gn(),
            jL = vp(),
            KL = nn();

        function $L(e, t, n) {
            for (var i = -1, a = t.length, r = {}; ++i < a;) {
                var o = t[i],
                    s = QL(e, o);
                n(s, o) && jL(r, KL(o, e), s)
            }
            return r
        }
        _p.exports = $L
    });
    var bp = u((uP, hp) => {
        var ZL = Nn(),
            JL = Pi(),
            e6 = dr(),
            t6 = lr(),
            n6 = Object.getOwnPropertySymbols,
            i6 = n6 ? function(e) {
                for (var t = []; e;) ZL(t, e6(e)), e = JL(e);
                return t
            } : t6;
        hp.exports = i6
    });
    var Ap = u((lP, Sp) => {
        function r6(e) {
            var t = [];
            if (e != null)
                for (var n in Object(e)) t.push(n);
            return t
        }
        Sp.exports = r6
    });
    var Lp = u((dP, Rp) => {
        var a6 = Ye(),
            o6 = xn(),
            s6 = Ap(),
            c6 = Object.prototype,
            u6 = c6.hasOwnProperty;

        function l6(e) {
            if (!a6(e)) return s6(e);
            var t = o6(e),
                n = [];
            for (var i in e) i == "constructor" && (t || !u6.call(e, i)) || n.push(i);
            return n
        }
        Rp.exports = l6
    });
    var Cp = u((fP, Np) => {
        var d6 = pr(),
            f6 = Lp(),
            p6 = lt();

        function g6(e) {
            return p6(e) ? d6(e, !0) : f6(e)
        }
        Np.exports = g6
    });
    var Pp = u((pP, wp) => {
        var E6 = ur(),
            I6 = bp(),
            y6 = Cp();

        function T6(e) {
            return E6(e, y6, I6)
        }
        wp.exports = T6
    });
    var xp = u((gP, Mp) => {
        var m6 = Sr(),
            v6 = it(),
            _6 = Op(),
            O6 = Pp();

        function h6(e, t) {
            if (e == null) return {};
            var n = m6(O6(e), function(i) {
                return [i]
            });
            return t = v6(t), _6(e, n, function(i, a) {
                return t(i, a[0])
            })
        }
        Mp.exports = h6
    });
    var Dp = u((EP, Fp) => {
        var b6 = it(),
            S6 = fp(),
            A6 = xp();

        function R6(e, t) {
            return A6(e, S6(b6(t)))
        }
        Fp.exports = R6
    });
    var Up = u((IP, Vp) => {
        var L6 = Fn(),
            N6 = Dn(),
            C6 = Kt(),
            w6 = _e(),
            P6 = lt(),
            M6 = Cn(),
            x6 = xn(),
            F6 = Mn(),
            D6 = "[object Map]",
            V6 = "[object Set]",
            U6 = Object.prototype,
            G6 = U6.hasOwnProperty;

        function q6(e) {
            if (e == null) return !0;
            if (P6(e) && (w6(e) || typeof e == "string" || typeof e.splice == "function" || M6(e) || F6(e) || C6(e))) return !e.length;
            var t = N6(e);
            if (t == D6 || t == V6) return !e.size;
            if (x6(e)) return !L6(e).length;
            for (var n in e)
                if (G6.call(e, n)) return !1;
            return !0
        }
        Vp.exports = q6
    });
    var qp = u((yP, Gp) => {
        var k6 = ya(),
            X6 = $r(),
            B6 = it();

        function Y6(e, t) {
            var n = {};
            return t = B6(t, 3), X6(e, function(i, a, r) {
                k6(n, a, t(i, a, r))
            }), n
        }
        Gp.exports = Y6
    });
    var Xp = u((TP, kp) => {
        function W6(e, t) {
            for (var n = -1, i = e == null ? 0 : e.length; ++n < i && t(e[n], n, e) !== !1;);
            return e
        }
        kp.exports = W6
    });
    var Yp = u((mP, Bp) => {
        var H6 = kn();

        function z6(e) {
            return typeof e == "function" ? e : H6
        }
        Bp.exports = z6
    });
    var Hp = u((vP, Wp) => {
        var Q6 = Xp(),
            j6 = Zr(),
            K6 = Yp(),
            $6 = _e();

        function Z6(e, t) {
            var n = $6(e) ? Q6 : j6;
            return n(e, K6(t))
        }
        Wp.exports = Z6
    });
    var Qp = u((_P, zp) => {
        var J6 = Ge(),
            e7 = function() {
                return J6.Date.now()
            };
        zp.exports = e7
    });
    var $p = u((OP, Kp) => {
        var t7 = Ye(),
            Ta = Qp(),
            jp = Xn(),
            n7 = "Expected a function",
            i7 = Math.max,
            r7 = Math.min;

        function a7(e, t, n) {
            var i, a, r, o, s, c, d = 0,
                I = !1,
                E = !1,
                p = !0;
            if (typeof e != "function") throw new TypeError(n7);
            t = jp(t) || 0, t7(n) && (I = !!n.leading, E = "maxWait" in n, r = E ? i7(jp(n.maxWait) || 0, t) : r, p = "trailing" in n ? !!n.trailing : p);

            function g(C) {
                var G = i,
                    X = a;
                return i = a = void 0, d = C, o = e.apply(X, G), o
            }

            function v(C) {
                return d = C, s = setTimeout(T, t), I ? g(C) : o
            }

            function m(C) {
                var G = C - c,
                    X = C - d,
                    B = t - G;
                return E ? r7(B, r - X) : B
            }

            function h(C) {
                var G = C - c,
                    X = C - d;
                return c === void 0 || G >= t || G < 0 || E && X >= r
            }

            function T() {
                var C = Ta();
                if (h(C)) return A(C);
                s = setTimeout(T, m(C))
            }

            function A(C) {
                return s = void 0, p && i ? g(C) : (i = a = void 0, o)
            }

            function b() {
                s !== void 0 && clearTimeout(s), d = 0, i = c = a = s = void 0
            }

            function N() {
                return s === void 0 ? o : A(Ta())
            }

            function P() {
                var C = Ta(),
                    G = h(C);
                if (i = arguments, a = this, c = C, G) {
                    if (s === void 0) return v(c);
                    if (E) return clearTimeout(s), s = setTimeout(T, t), g(c)
                }
                return s === void 0 && (s = setTimeout(T, t)), o
            }
            return P.cancel = b, P.flush = N, P
        }
        Kp.exports = a7
    });
    var Jp = u((hP, Zp) => {
        var o7 = $p(),
            s7 = Ye(),
            c7 = "Expected a function";

        function u7(e, t, n) {
            var i = !0,
                a = !0;
            if (typeof e != "function") throw new TypeError(c7);
            return s7(n) && (i = "leading" in n ? !!n.leading : i, a = "trailing" in n ? !!n.trailing : a), o7(e, t, {
                leading: i,
                maxWait: t,
                trailing: a
            })
        }
        Zp.exports = u7
    });
    var ii = u(ma => {
        "use strict";
        Object.defineProperty(ma, "__esModule", {
            value: !0
        });

        function l7(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        l7(ma, {
            actionListPlaybackChanged: function() {
                return K7
            },
            animationFrameChanged: function() {
                return Y7
            },
            clearRequested: function() {
                return q7
            },
            elementStateChanged: function() {
                return j7
            },
            eventListenerAdded: function() {
                return k7
            },
            eventStateChanged: function() {
                return B7
            },
            instanceAdded: function() {
                return H7
            },
            instanceRemoved: function() {
                return Q7
            },
            instanceStarted: function() {
                return z7
            },
            mediaQueriesDefined: function() {
                return Z7
            },
            parameterChanged: function() {
                return W7
            },
            playbackRequested: function() {
                return U7
            },
            previewRequested: function() {
                return V7
            },
            rawDataImported: function() {
                return M7
            },
            sessionInitialized: function() {
                return x7
            },
            sessionStarted: function() {
                return F7
            },
            sessionStopped: function() {
                return D7
            },
            stopRequested: function() {
                return G7
            },
            testFrameRendered: function() {
                return X7
            },
            viewportWidthChanged: function() {
                return $7
            }
        });
        var e0 = Re(),
            d7 = Et(),
            {
                IX2_RAW_DATA_IMPORTED: f7,
                IX2_SESSION_INITIALIZED: p7,
                IX2_SESSION_STARTED: g7,
                IX2_SESSION_STOPPED: E7,
                IX2_PREVIEW_REQUESTED: I7,
                IX2_PLAYBACK_REQUESTED: y7,
                IX2_STOP_REQUESTED: T7,
                IX2_CLEAR_REQUESTED: m7,
                IX2_EVENT_LISTENER_ADDED: v7,
                IX2_TEST_FRAME_RENDERED: _7,
                IX2_EVENT_STATE_CHANGED: O7,
                IX2_ANIMATION_FRAME_CHANGED: h7,
                IX2_PARAMETER_CHANGED: b7,
                IX2_INSTANCE_ADDED: S7,
                IX2_INSTANCE_STARTED: A7,
                IX2_INSTANCE_REMOVED: R7,
                IX2_ELEMENT_STATE_CHANGED: L7,
                IX2_ACTION_LIST_PLAYBACK_CHANGED: N7,
                IX2_VIEWPORT_WIDTH_CHANGED: C7,
                IX2_MEDIA_QUERIES_DEFINED: w7
            } = e0.IX2EngineActionTypes,
            {
                reifyState: P7
            } = d7.IX2VanillaUtils,
            M7 = e => ({
                type: f7,
                payload: { ...P7(e)
                }
            }),
            x7 = ({
                hasBoundaryNodes: e,
                reducedMotion: t
            }) => ({
                type: p7,
                payload: {
                    hasBoundaryNodes: e,
                    reducedMotion: t
                }
            }),
            F7 = () => ({
                type: g7
            }),
            D7 = () => ({
                type: E7
            }),
            V7 = ({
                rawData: e,
                defer: t
            }) => ({
                type: I7,
                payload: {
                    defer: t,
                    rawData: e
                }
            }),
            U7 = ({
                actionTypeId: e = e0.ActionTypeConsts.GENERAL_START_ACTION,
                actionListId: t,
                actionItemId: n,
                eventId: i,
                allowEvents: a,
                immediate: r,
                testManual: o,
                verbose: s,
                rawData: c
            }) => ({
                type: y7,
                payload: {
                    actionTypeId: e,
                    actionListId: t,
                    actionItemId: n,
                    testManual: o,
                    eventId: i,
                    allowEvents: a,
                    immediate: r,
                    verbose: s,
                    rawData: c
                }
            }),
            G7 = e => ({
                type: T7,
                payload: {
                    actionListId: e
                }
            }),
            q7 = () => ({
                type: m7
            }),
            k7 = (e, t) => ({
                type: v7,
                payload: {
                    target: e,
                    listenerParams: t
                }
            }),
            X7 = (e = 1) => ({
                type: _7,
                payload: {
                    step: e
                }
            }),
            B7 = (e, t) => ({
                type: O7,
                payload: {
                    stateKey: e,
                    newState: t
                }
            }),
            Y7 = (e, t) => ({
                type: h7,
                payload: {
                    now: e,
                    parameters: t
                }
            }),
            W7 = (e, t) => ({
                type: b7,
                payload: {
                    key: e,
                    value: t
                }
            }),
            H7 = e => ({
                type: S7,
                payload: { ...e
                }
            }),
            z7 = (e, t) => ({
                type: A7,
                payload: {
                    instanceId: e,
                    time: t
                }
            }),
            Q7 = e => ({
                type: R7,
                payload: {
                    instanceId: e
                }
            }),
            j7 = (e, t, n, i) => ({
                type: L7,
                payload: {
                    elementId: e,
                    actionTypeId: t,
                    current: n,
                    actionItem: i
                }
            }),
            K7 = ({
                actionListId: e,
                isPlaying: t
            }) => ({
                type: N7,
                payload: {
                    actionListId: e,
                    isPlaying: t
                }
            }),
            $7 = ({
                width: e,
                mediaQueries: t
            }) => ({
                type: C7,
                payload: {
                    width: e,
                    mediaQueries: t
                }
            }),
            Z7 = () => ({
                type: w7
            })
    });
    var i0 = u(_a => {
        "use strict";
        Object.defineProperty(_a, "__esModule", {
            value: !0
        });

        function J7(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        J7(_a, {
            elementContains: function() {
                return dN
            },
            getChildElements: function() {
                return pN
            },
            getClosestElement: function() {
                return EN
            },
            getProperty: function() {
                return oN
            },
            getQuerySelector: function() {
                return cN
            },
            getRefType: function() {
                return IN
            },
            getSiblingElements: function() {
                return gN
            },
            getStyle: function() {
                return aN
            },
            getValidDocument: function() {
                return uN
            },
            isSiblingNode: function() {
                return fN
            },
            matchSelector: function() {
                return sN
            },
            queryDocument: function() {
                return lN
            },
            setStyle: function() {
                return rN
            }
        });
        var eN = Et(),
            tN = Re(),
            {
                ELEMENT_MATCHES: va
            } = eN.IX2BrowserSupport,
            {
                IX2_ID_DELIMITER: t0,
                HTML_ELEMENT: nN,
                PLAIN_OBJECT: iN,
                WF_PAGE: n0
            } = tN.IX2EngineConstants;

        function rN(e, t, n) {
            e.style[t] = n
        }

        function aN(e, t) {
            if (t.startsWith("--")) return window.getComputedStyle(document.documentElement).getPropertyValue(t);
            if (e.style instanceof CSSStyleDeclaration) return e.style[t]
        }

        function oN(e, t) {
            return e[t]
        }

        function sN(e) {
            return t => t[va](e)
        }

        function cN({
            id: e,
            selector: t
        }) {
            if (e) {
                let n = e;
                if (e.indexOf(t0) !== -1) {
                    let i = e.split(t0),
                        a = i[0];
                    if (n = i[1], a !== document.documentElement.getAttribute(n0)) return null
                }
                return `[data-w-id="${n}"], [data-w-id^="${n}_instance"]`
            }
            return t
        }

        function uN(e) {
            return e == null || e === document.documentElement.getAttribute(n0) ? document : null
        }

        function lN(e, t) {
            return Array.prototype.slice.call(document.querySelectorAll(t ? e + " " + t : e))
        }

        function dN(e, t) {
            return e.contains(t)
        }

        function fN(e, t) {
            return e !== t && e.parentNode === t.parentNode
        }

        function pN(e) {
            let t = [];
            for (let n = 0, {
                    length: i
                } = e || []; n < i; n++) {
                let {
                    children: a
                } = e[n], {
                    length: r
                } = a;
                if (r)
                    for (let o = 0; o < r; o++) t.push(a[o])
            }
            return t
        }

        function gN(e = []) {
            let t = [],
                n = [];
            for (let i = 0, {
                    length: a
                } = e; i < a; i++) {
                let {
                    parentNode: r
                } = e[i];
                if (!r || !r.children || !r.children.length || n.indexOf(r) !== -1) continue;
                n.push(r);
                let o = r.firstElementChild;
                for (; o != null;) e.indexOf(o) === -1 && t.push(o), o = o.nextElementSibling
            }
            return t
        }
        var EN = Element.prototype.closest ? (e, t) => document.documentElement.contains(e) ? e.closest(t) : null : (e, t) => {
            if (!document.documentElement.contains(e)) return null;
            let n = e;
            do {
                if (n[va] && n[va](t)) return n;
                n = n.parentNode
            } while (n != null);
            return null
        };

        function IN(e) {
            return e != null && typeof e == "object" ? e instanceof Element ? nN : iN : null
        }
    });
    var Oa = u((AP, a0) => {
        var yN = Ye(),
            r0 = Object.create,
            TN = function() {
                function e() {}
                return function(t) {
                    if (!yN(t)) return {};
                    if (r0) return r0(t);
                    e.prototype = t;
                    var n = new e;
                    return e.prototype = void 0, n
                }
            }();
        a0.exports = TN
    });
    var ri = u((RP, o0) => {
        function mN() {}
        o0.exports = mN
    });
    var oi = u((LP, s0) => {
        var vN = Oa(),
            _N = ri();

        function ai(e, t) {
            this.__wrapped__ = e, this.__actions__ = [], this.__chain__ = !!t, this.__index__ = 0, this.__values__ = void 0
        }
        ai.prototype = vN(_N.prototype);
        ai.prototype.constructor = ai;
        s0.exports = ai
    });
    var d0 = u((NP, l0) => {
        var c0 = _t(),
            ON = Kt(),
            hN = _e(),
            u0 = c0 ? c0.isConcatSpreadable : void 0;

        function bN(e) {
            return hN(e) || ON(e) || !!(u0 && e && e[u0])
        }
        l0.exports = bN
    });
    var g0 = u((CP, p0) => {
        var SN = Nn(),
            AN = d0();

        function f0(e, t, n, i, a) {
            var r = -1,
                o = e.length;
            for (n || (n = AN), a || (a = []); ++r < o;) {
                var s = e[r];
                t > 0 && n(s) ? t > 1 ? f0(s, t - 1, n, i, a) : SN(a, s) : i || (a[a.length] = s)
            }
            return a
        }
        p0.exports = f0
    });
    var I0 = u((wP, E0) => {
        var RN = g0();

        function LN(e) {
            var t = e == null ? 0 : e.length;
            return t ? RN(e, 1) : []
        }
        E0.exports = LN
    });
    var T0 = u((PP, y0) => {
        function NN(e, t, n) {
            switch (n.length) {
                case 0:
                    return e.call(t);
                case 1:
                    return e.call(t, n[0]);
                case 2:
                    return e.call(t, n[0], n[1]);
                case 3:
                    return e.call(t, n[0], n[1], n[2])
            }
            return e.apply(t, n)
        }
        y0.exports = NN
    });
    var _0 = u((MP, v0) => {
        var CN = T0(),
            m0 = Math.max;

        function wN(e, t, n) {
            return t = m0(t === void 0 ? e.length - 1 : t, 0),
                function() {
                    for (var i = arguments, a = -1, r = m0(i.length - t, 0), o = Array(r); ++a < r;) o[a] = i[t + a];
                    a = -1;
                    for (var s = Array(t + 1); ++a < t;) s[a] = i[a];
                    return s[t] = n(o), CN(e, this, s)
                }
        }
        v0.exports = wN
    });
    var h0 = u((xP, O0) => {
        function PN(e) {
            return function() {
                return e
            }
        }
        O0.exports = PN
    });
    var A0 = u((FP, S0) => {
        var MN = h0(),
            b0 = Ia(),
            xN = kn(),
            FN = b0 ? function(e, t) {
                return b0(e, "toString", {
                    configurable: !0,
                    enumerable: !1,
                    value: MN(t),
                    writable: !0
                })
            } : xN;
        S0.exports = FN
    });
    var L0 = u((DP, R0) => {
        var DN = 800,
            VN = 16,
            UN = Date.now;

        function GN(e) {
            var t = 0,
                n = 0;
            return function() {
                var i = UN(),
                    a = VN - (i - n);
                if (n = i, a > 0) {
                    if (++t >= DN) return arguments[0]
                } else t = 0;
                return e.apply(void 0, arguments)
            }
        }
        R0.exports = GN
    });
    var C0 = u((VP, N0) => {
        var qN = A0(),
            kN = L0(),
            XN = kN(qN);
        N0.exports = XN
    });
    var P0 = u((UP, w0) => {
        var BN = I0(),
            YN = _0(),
            WN = C0();

        function HN(e) {
            return WN(YN(e, void 0, BN), e + "")
        }
        w0.exports = HN
    });
    var F0 = u((GP, x0) => {
        var M0 = gr(),
            zN = M0 && new M0;
        x0.exports = zN
    });
    var V0 = u((qP, D0) => {
        function QN() {}
        D0.exports = QN
    });
    var ha = u((kP, G0) => {
        var U0 = F0(),
            jN = V0(),
            KN = U0 ? function(e) {
                return U0.get(e)
            } : jN;
        G0.exports = KN
    });
    var k0 = u((XP, q0) => {
        var $N = {};
        q0.exports = $N
    });
    var ba = u((BP, B0) => {
        var X0 = k0(),
            ZN = Object.prototype,
            JN = ZN.hasOwnProperty;

        function e3(e) {
            for (var t = e.name + "", n = X0[t], i = JN.call(X0, t) ? n.length : 0; i--;) {
                var a = n[i],
                    r = a.func;
                if (r == null || r == e) return a.name
            }
            return t
        }
        B0.exports = e3
    });
    var ci = u((YP, Y0) => {
        var t3 = Oa(),
            n3 = ri(),
            i3 = 4294967295;

        function si(e) {
            this.__wrapped__ = e, this.__actions__ = [], this.__dir__ = 1, this.__filtered__ = !1, this.__iteratees__ = [], this.__takeCount__ = i3, this.__views__ = []
        }
        si.prototype = t3(n3.prototype);
        si.prototype.constructor = si;
        Y0.exports = si
    });
    var H0 = u((WP, W0) => {
        function r3(e, t) {
            var n = -1,
                i = e.length;
            for (t || (t = Array(i)); ++n < i;) t[n] = e[n];
            return t
        }
        W0.exports = r3
    });
    var Q0 = u((HP, z0) => {
        var a3 = ci(),
            o3 = oi(),
            s3 = H0();

        function c3(e) {
            if (e instanceof a3) return e.clone();
            var t = new o3(e.__wrapped__, e.__chain__);
            return t.__actions__ = s3(e.__actions__), t.__index__ = e.__index__, t.__values__ = e.__values__, t
        }
        z0.exports = c3
    });
    var $0 = u((zP, K0) => {
        var u3 = ci(),
            j0 = oi(),
            l3 = ri(),
            d3 = _e(),
            f3 = Ke(),
            p3 = Q0(),
            g3 = Object.prototype,
            E3 = g3.hasOwnProperty;

        function ui(e) {
            if (f3(e) && !d3(e) && !(e instanceof u3)) {
                if (e instanceof j0) return e;
                if (E3.call(e, "__wrapped__")) return p3(e)
            }
            return new j0(e)
        }
        ui.prototype = l3.prototype;
        ui.prototype.constructor = ui;
        K0.exports = ui
    });
    var J0 = u((QP, Z0) => {
        var I3 = ci(),
            y3 = ha(),
            T3 = ba(),
            m3 = $0();

        function v3(e) {
            var t = T3(e),
                n = m3[t];
            if (typeof n != "function" || !(t in I3.prototype)) return !1;
            if (e === n) return !0;
            var i = y3(n);
            return !!i && e === i[0]
        }
        Z0.exports = v3
    });
    var ig = u((jP, ng) => {
        var eg = oi(),
            _3 = P0(),
            O3 = ha(),
            Sa = ba(),
            h3 = _e(),
            tg = J0(),
            b3 = "Expected a function",
            S3 = 8,
            A3 = 32,
            R3 = 128,
            L3 = 256;

        function N3(e) {
            return _3(function(t) {
                var n = t.length,
                    i = n,
                    a = eg.prototype.thru;
                for (e && t.reverse(); i--;) {
                    var r = t[i];
                    if (typeof r != "function") throw new TypeError(b3);
                    if (a && !o && Sa(r) == "wrapper") var o = new eg([], !0)
                }
                for (i = o ? i : n; ++i < n;) {
                    r = t[i];
                    var s = Sa(r),
                        c = s == "wrapper" ? O3(r) : void 0;
                    c && tg(c[0]) && c[1] == (R3 | S3 | A3 | L3) && !c[4].length && c[9] == 1 ? o = o[Sa(c[0])].apply(o, c[3]) : o = r.length == 1 && tg(r) ? o[s]() : o.thru(r)
                }
                return function() {
                    var d = arguments,
                        I = d[0];
                    if (o && d.length == 1 && h3(I)) return o.plant(I).value();
                    for (var E = 0, p = n ? t[E].apply(this, d) : I; ++E < n;) p = t[E].call(this, p);
                    return p
                }
            })
        }
        ng.exports = N3
    });
    var ag = u((KP, rg) => {
        var C3 = ig(),
            w3 = C3();
        rg.exports = w3
    });
    var sg = u(($P, og) => {
        function P3(e, t, n) {
            return e === e && (n !== void 0 && (e = e <= n ? e : n), t !== void 0 && (e = e >= t ? e : t)), e
        }
        og.exports = P3
    });
    var ug = u((ZP, cg) => {
        var M3 = sg(),
            Aa = Xn();

        function x3(e, t, n) {
            return n === void 0 && (n = t, t = void 0), n !== void 0 && (n = Aa(n), n = n === n ? n : 0), t !== void 0 && (t = Aa(t), t = t === t ? t : 0), M3(Aa(e), t, n)
        }
        cg.exports = x3
    });
    var Rg = u(Pa => {
        "use strict";
        Object.defineProperty(Pa, "__esModule", {
            value: !0
        });
        Object.defineProperty(Pa, "default", {
            enumerable: !0,
            get: function() {
                return I9
            }
        });
        var F3 = wa(ag()),
            D3 = wa(qn()),
            V3 = wa(ug()),
            It = Re(),
            Ra = Ma(),
            li = ii(),
            U3 = Et();

        function wa(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
        var {
            MOUSE_CLICK: G3,
            MOUSE_SECOND_CLICK: q3,
            MOUSE_DOWN: k3,
            MOUSE_UP: X3,
            MOUSE_OVER: B3,
            MOUSE_OUT: Y3,
            DROPDOWN_CLOSE: W3,
            DROPDOWN_OPEN: H3,
            SLIDER_ACTIVE: z3,
            SLIDER_INACTIVE: Q3,
            TAB_ACTIVE: j3,
            TAB_INACTIVE: K3,
            NAVBAR_CLOSE: $3,
            NAVBAR_OPEN: Z3,
            MOUSE_MOVE: J3,
            PAGE_SCROLL_DOWN: Tg,
            SCROLL_INTO_VIEW: mg,
            SCROLL_OUT_OF_VIEW: e9,
            PAGE_SCROLL_UP: t9,
            SCROLLING_IN_VIEW: n9,
            PAGE_FINISH: vg,
            ECOMMERCE_CART_CLOSE: i9,
            ECOMMERCE_CART_OPEN: r9,
            PAGE_START: _g,
            PAGE_SCROLL: a9
        } = It.EventTypeConsts, La = "COMPONENT_ACTIVE", Og = "COMPONENT_INACTIVE", {
            COLON_DELIMITER: lg
        } = It.IX2EngineConstants, {
            getNamespacedParameterId: dg
        } = U3.IX2VanillaUtils, hg = e => t => typeof t == "object" && e(t) ? !0 : t, fn = hg(({
            element: e,
            nativeEvent: t
        }) => e === t.target), o9 = hg(({
            element: e,
            nativeEvent: t
        }) => e.contains(t.target)), Qe = (0, F3.default)([fn, o9]), bg = (e, t) => {
            if (t) {
                let {
                    ixData: n
                } = e.getState(), {
                    events: i
                } = n, a = i[t];
                if (a && !c9[a.eventTypeId]) return a
            }
            return null
        }, s9 = ({
            store: e,
            event: t
        }) => {
            let {
                action: n
            } = t, {
                autoStopEventId: i
            } = n.config;
            return !!bg(e, i)
        }, Ne = ({
            store: e,
            event: t,
            element: n,
            eventStateKey: i
        }, a) => {
            let {
                action: r,
                id: o
            } = t, {
                actionListId: s,
                autoStopEventId: c
            } = r.config, d = bg(e, c);
            return d && (0, Ra.stopActionGroup)({
                store: e,
                eventId: c,
                eventTarget: n,
                eventStateKey: c + lg + i.split(lg)[1],
                actionListId: (0, D3.default)(d, "action.config.actionListId")
            }), (0, Ra.stopActionGroup)({
                store: e,
                eventId: o,
                eventTarget: n,
                eventStateKey: i,
                actionListId: s
            }), (0, Ra.startActionGroup)({
                store: e,
                eventId: o,
                eventTarget: n,
                eventStateKey: i,
                actionListId: s
            }), a
        }, qe = (e, t) => (n, i) => e(n, i) === !0 ? t(n, i) : i, pn = {
            handler: qe(Qe, Ne)
        }, Sg = { ...pn,
            types: [La, Og].join(" ")
        }, Na = [{
            target: window,
            types: "resize orientationchange",
            throttle: !0
        }, {
            target: document,
            types: "scroll wheel readystatechange IX2_PAGE_UPDATE",
            throttle: !0
        }], fg = "mouseover mouseout", Ca = {
            types: Na
        }, c9 = {
            PAGE_START: _g,
            PAGE_FINISH: vg
        }, dn = (() => {
            let e = window.pageXOffset !== void 0,
                n = document.compatMode === "CSS1Compat" ? document.documentElement : document.body;
            return () => ({
                scrollLeft: e ? window.pageXOffset : n.scrollLeft,
                scrollTop: e ? window.pageYOffset : n.scrollTop,
                stiffScrollTop: (0, V3.default)(e ? window.pageYOffset : n.scrollTop, 0, n.scrollHeight - window.innerHeight),
                scrollWidth: n.scrollWidth,
                scrollHeight: n.scrollHeight,
                clientWidth: n.clientWidth,
                clientHeight: n.clientHeight,
                innerWidth: window.innerWidth,
                innerHeight: window.innerHeight
            })
        })(), u9 = (e, t) => !(e.left > t.right || e.right < t.left || e.top > t.bottom || e.bottom < t.top), l9 = ({
            element: e,
            nativeEvent: t
        }) => {
            let {
                type: n,
                target: i,
                relatedTarget: a
            } = t, r = e.contains(i);
            if (n === "mouseover" && r) return !0;
            let o = e.contains(a);
            return !!(n === "mouseout" && r && o)
        }, d9 = e => {
            let {
                element: t,
                event: {
                    config: n
                }
            } = e, {
                clientWidth: i,
                clientHeight: a
            } = dn(), r = n.scrollOffsetValue, c = n.scrollOffsetUnit === "PX" ? r : a * (r || 0) / 100;
            return u9(t.getBoundingClientRect(), {
                left: 0,
                top: c,
                right: i,
                bottom: a - c
            })
        }, Ag = e => (t, n) => {
            let {
                type: i
            } = t.nativeEvent, a = [La, Og].indexOf(i) !== -1 ? i === La : n.isActive, r = { ...n,
                isActive: a
            };
            return (!n || r.isActive !== n.isActive) && e(t, r) || r
        }, pg = e => (t, n) => {
            let i = {
                elementHovered: l9(t)
            };
            return (n ? i.elementHovered !== n.elementHovered : i.elementHovered) && e(t, i) || i
        }, f9 = e => (t, n) => {
            let i = { ...n,
                elementVisible: d9(t)
            };
            return (n ? i.elementVisible !== n.elementVisible : i.elementVisible) && e(t, i) || i
        }, gg = e => (t, n = {}) => {
            let {
                stiffScrollTop: i,
                scrollHeight: a,
                innerHeight: r
            } = dn(), {
                event: {
                    config: o,
                    eventTypeId: s
                }
            } = t, {
                scrollOffsetValue: c,
                scrollOffsetUnit: d
            } = o, I = d === "PX", E = a - r, p = Number((i / E).toFixed(2));
            if (n && n.percentTop === p) return n;
            let g = (I ? c : r * (c || 0) / 100) / E,
                v, m, h = 0;
            n && (v = p > n.percentTop, m = n.scrollingDown !== v, h = m ? p : n.anchorTop);
            let T = s === Tg ? p >= h + g : p <= h - g,
                A = { ...n,
                    percentTop: p,
                    inBounds: T,
                    anchorTop: h,
                    scrollingDown: v
                };
            return n && T && (m || A.inBounds !== n.inBounds) && e(t, A) || A
        }, p9 = (e, t) => e.left > t.left && e.left < t.right && e.top > t.top && e.top < t.bottom, g9 = e => (t, n) => {
            let i = {
                finished: document.readyState === "complete"
            };
            return i.finished && !(n && n.finshed) && e(t), i
        }, E9 = e => (t, n) => {
            let i = {
                started: !0
            };
            return n || e(t), i
        }, Eg = e => (t, n = {
            clickCount: 0
        }) => {
            let i = {
                clickCount: n.clickCount % 2 + 1
            };
            return i.clickCount !== n.clickCount && e(t, i) || i
        }, di = (e = !0) => ({ ...Sg,
            handler: qe(e ? Qe : fn, Ag((t, n) => n.isActive ? pn.handler(t, n) : n))
        }), fi = (e = !0) => ({ ...Sg,
            handler: qe(e ? Qe : fn, Ag((t, n) => n.isActive ? n : pn.handler(t, n)))
        }), Ig = { ...Ca,
            handler: f9((e, t) => {
                let {
                    elementVisible: n
                } = t, {
                    event: i,
                    store: a
                } = e, {
                    ixData: r
                } = a.getState(), {
                    events: o
                } = r;
                return !o[i.action.config.autoStopEventId] && t.triggered ? t : i.eventTypeId === mg === n ? (Ne(e), { ...t,
                    triggered: !0
                }) : t
            })
        }, yg = .05, I9 = {
            [z3]: di(),
            [Q3]: fi(),
            [H3]: di(),
            [W3]: fi(),
            [Z3]: di(!1),
            [$3]: fi(!1),
            [j3]: di(),
            [K3]: fi(),
            [r9]: {
                types: "ecommerce-cart-open",
                handler: qe(Qe, Ne)
            },
            [i9]: {
                types: "ecommerce-cart-close",
                handler: qe(Qe, Ne)
            },
            [G3]: {
                types: "click",
                handler: qe(Qe, Eg((e, {
                    clickCount: t
                }) => {
                    s9(e) ? t === 1 && Ne(e) : Ne(e)
                }))
            },
            [q3]: {
                types: "click",
                handler: qe(Qe, Eg((e, {
                    clickCount: t
                }) => {
                    t === 2 && Ne(e)
                }))
            },
            [k3]: { ...pn,
                types: "mousedown"
            },
            [X3]: { ...pn,
                types: "mouseup"
            },
            [B3]: {
                types: fg,
                handler: qe(Qe, pg((e, t) => {
                    t.elementHovered && Ne(e)
                }))
            },
            [Y3]: {
                types: fg,
                handler: qe(Qe, pg((e, t) => {
                    t.elementHovered || Ne(e)
                }))
            },
            [J3]: {
                types: "mousemove mouseout scroll",
                handler: ({
                    store: e,
                    element: t,
                    eventConfig: n,
                    nativeEvent: i,
                    eventStateKey: a
                }, r = {
                    clientX: 0,
                    clientY: 0,
                    pageX: 0,
                    pageY: 0
                }) => {
                    let {
                        basedOn: o,
                        selectedAxis: s,
                        continuousParameterGroupId: c,
                        reverse: d,
                        restingState: I = 0
                    } = n, {
                        clientX: E = r.clientX,
                        clientY: p = r.clientY,
                        pageX: g = r.pageX,
                        pageY: v = r.pageY
                    } = i, m = s === "X_AXIS", h = i.type === "mouseout", T = I / 100, A = c, b = !1;
                    switch (o) {
                        case It.EventBasedOn.VIEWPORT:
                            {
                                T = m ? Math.min(E, window.innerWidth) / window.innerWidth : Math.min(p, window.innerHeight) / window.innerHeight;
                                break
                            }
                        case It.EventBasedOn.PAGE:
                            {
                                let {
                                    scrollLeft: N,
                                    scrollTop: P,
                                    scrollWidth: C,
                                    scrollHeight: G
                                } = dn();T = m ? Math.min(N + g, C) / C : Math.min(P + v, G) / G;
                                break
                            }
                        case It.EventBasedOn.ELEMENT:
                        default:
                            {
                                A = dg(a, c);
                                let N = i.type.indexOf("mouse") === 0;
                                if (N && Qe({
                                        element: t,
                                        nativeEvent: i
                                    }) !== !0) break;
                                let P = t.getBoundingClientRect(),
                                    {
                                        left: C,
                                        top: G,
                                        width: X,
                                        height: B
                                    } = P;
                                if (!N && !p9({
                                        left: E,
                                        top: p
                                    }, P)) break;b = !0,
                                T = m ? (E - C) / X : (p - G) / B;
                                break
                            }
                    }
                    return h && (T > 1 - yg || T < yg) && (T = Math.round(T)), (o !== It.EventBasedOn.ELEMENT || b || b !== r.elementHovered) && (T = d ? 1 - T : T, e.dispatch((0, li.parameterChanged)(A, T))), {
                        elementHovered: b,
                        clientX: E,
                        clientY: p,
                        pageX: g,
                        pageY: v
                    }
                }
            },
            [a9]: {
                types: Na,
                handler: ({
                    store: e,
                    eventConfig: t
                }) => {
                    let {
                        continuousParameterGroupId: n,
                        reverse: i
                    } = t, {
                        scrollTop: a,
                        scrollHeight: r,
                        clientHeight: o
                    } = dn(), s = a / (r - o);
                    s = i ? 1 - s : s, e.dispatch((0, li.parameterChanged)(n, s))
                }
            },
            [n9]: {
                types: Na,
                handler: ({
                    element: e,
                    store: t,
                    eventConfig: n,
                    eventStateKey: i
                }, a = {
                    scrollPercent: 0
                }) => {
                    let {
                        scrollLeft: r,
                        scrollTop: o,
                        scrollWidth: s,
                        scrollHeight: c,
                        clientHeight: d
                    } = dn(), {
                        basedOn: I,
                        selectedAxis: E,
                        continuousParameterGroupId: p,
                        startsEntering: g,
                        startsExiting: v,
                        addEndOffset: m,
                        addStartOffset: h,
                        addOffsetValue: T = 0,
                        endOffsetValue: A = 0
                    } = n, b = E === "X_AXIS";
                    if (I === It.EventBasedOn.VIEWPORT) {
                        let N = b ? r / s : o / c;
                        return N !== a.scrollPercent && t.dispatch((0, li.parameterChanged)(p, N)), {
                            scrollPercent: N
                        }
                    } else {
                        let N = dg(i, p),
                            P = e.getBoundingClientRect(),
                            C = (h ? T : 0) / 100,
                            G = (m ? A : 0) / 100;
                        C = g ? C : 1 - C, G = v ? G : 1 - G;
                        let X = P.top + Math.min(P.height * C, d),
                            z = P.top + P.height * G - X,
                            J = Math.min(d + z, c),
                            O = Math.min(Math.max(0, d - X), J) / J;
                        return O !== a.scrollPercent && t.dispatch((0, li.parameterChanged)(N, O)), {
                            scrollPercent: O
                        }
                    }
                }
            },
            [mg]: Ig,
            [e9]: Ig,
            [Tg]: { ...Ca,
                handler: gg((e, t) => {
                    t.scrollingDown && Ne(e)
                })
            },
            [t9]: { ...Ca,
                handler: gg((e, t) => {
                    t.scrollingDown || Ne(e)
                })
            },
            [vg]: {
                types: "readystatechange IX2_PAGE_UPDATE",
                handler: qe(fn, g9(Ne))
            },
            [_g]: {
                types: "readystatechange IX2_PAGE_UPDATE",
                handler: qe(fn, E9(Ne))
            }
        }
    });
    var Ma = u(Xa => {
        "use strict";
        Object.defineProperty(Xa, "__esModule", {
            value: !0
        });

        function y9(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        y9(Xa, {
            observeRequests: function() {
                return W9
            },
            startActionGroup: function() {
                return Ga
            },
            startEngine: function() {
                return yi
            },
            stopActionGroup: function() {
                return Ua
            },
            stopAllActionGroups: function() {
                return Vg
            },
            stopEngine: function() {
                return Ti
            }
        });
        var T9 = Ze(Cr()),
            ot = Ze(qn()),
            m9 = Ze(lp()),
            v9 = Ze(Dp()),
            _9 = Ze(Up()),
            O9 = Ze(qp()),
            gn = Ze(Hp()),
            h9 = Ze(Jp()),
            Me = Re(),
            Cg = Et(),
            Ie = ii(),
            me = S9(i0()),
            b9 = Ze(Rg());

        function Ze(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function wg(e) {
            if (typeof WeakMap != "function") return null;
            var t = new WeakMap,
                n = new WeakMap;
            return (wg = function(i) {
                return i ? n : t
            })(e)
        }

        function S9(e, t) {
            if (!t && e && e.__esModule) return e;
            if (e === null || typeof e != "object" && typeof e != "function") return {
                default: e
            };
            var n = wg(t);
            if (n && n.has(e)) return n.get(e);
            var i = {
                    __proto__: null
                },
                a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var r in e)
                if (r !== "default" && Object.prototype.hasOwnProperty.call(e, r)) {
                    var o = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    o && (o.get || o.set) ? Object.defineProperty(i, r, o) : i[r] = e[r]
                }
            return i.default = e, n && n.set(e, i), i
        }
        var A9 = Object.keys(Me.QuickEffectIds),
            xa = e => A9.includes(e),
            {
                COLON_DELIMITER: Fa,
                BOUNDARY_SELECTOR: pi,
                HTML_ELEMENT: Pg,
                RENDER_GENERAL: R9,
                W_MOD_IX: Lg
            } = Me.IX2EngineConstants,
            {
                getAffectedElements: gi,
                getElementId: L9,
                getDestinationValues: Da,
                observeStore: yt,
                getInstanceId: N9,
                renderHTMLElement: C9,
                clearAllStyles: Mg,
                getMaxDurationItemIndex: w9,
                getComputedStyle: P9,
                getInstanceOrigin: M9,
                reduceListToGroup: x9,
                shouldNamespaceEventParameter: F9,
                getNamespacedParameterId: D9,
                shouldAllowMediaQuery: Ei,
                cleanupHTMLElement: V9,
                clearObjectCache: U9,
                stringifyTarget: G9,
                mediaQueriesEqual: q9,
                shallowEqual: k9
            } = Cg.IX2VanillaUtils,
            {
                isPluginType: Ii,
                createPluginInstance: Va,
                getPluginDuration: X9
            } = Cg.IX2VanillaPlugins,
            Ng = navigator.userAgent,
            B9 = Ng.match(/iPad/i) || Ng.match(/iPhone/),
            Y9 = 12;

        function W9(e) {
            yt({
                store: e,
                select: ({
                    ixRequest: t
                }) => t.preview,
                onChange: Q9
            }), yt({
                store: e,
                select: ({
                    ixRequest: t
                }) => t.playback,
                onChange: j9
            }), yt({
                store: e,
                select: ({
                    ixRequest: t
                }) => t.stop,
                onChange: K9
            }), yt({
                store: e,
                select: ({
                    ixRequest: t
                }) => t.clear,
                onChange: $9
            })
        }

        function H9(e) {
            yt({
                store: e,
                select: ({
                    ixSession: t
                }) => t.mediaQueryKey,
                onChange: () => {
                    Ti(e), Mg({
                        store: e,
                        elementApi: me
                    }), yi({
                        store: e,
                        allowEvents: !0
                    }), xg()
                }
            })
        }

        function z9(e, t) {
            let n = yt({
                store: e,
                select: ({
                    ixSession: i
                }) => i.tick,
                onChange: i => {
                    t(i), n()
                }
            })
        }

        function Q9({
            rawData: e,
            defer: t
        }, n) {
            let i = () => {
                yi({
                    store: n,
                    rawData: e,
                    allowEvents: !0
                }), xg()
            };
            t ? setTimeout(i, 0) : i()
        }

        function xg() {
            document.dispatchEvent(new CustomEvent("IX2_PAGE_UPDATE"))
        }

        function j9(e, t) {
            let {
                actionTypeId: n,
                actionListId: i,
                actionItemId: a,
                eventId: r,
                allowEvents: o,
                immediate: s,
                testManual: c,
                verbose: d = !0
            } = e, {
                rawData: I
            } = e;
            if (i && a && I && s) {
                let E = I.actionLists[i];
                E && (I = x9({
                    actionList: E,
                    actionItemId: a,
                    rawData: I
                }))
            }
            if (yi({
                    store: t,
                    rawData: I,
                    allowEvents: o,
                    testManual: c
                }), i && n === Me.ActionTypeConsts.GENERAL_START_ACTION || xa(n)) {
                Ua({
                    store: t,
                    actionListId: i
                }), Dg({
                    store: t,
                    actionListId: i,
                    eventId: r
                });
                let E = Ga({
                    store: t,
                    eventId: r,
                    actionListId: i,
                    immediate: s,
                    verbose: d
                });
                d && E && t.dispatch((0, Ie.actionListPlaybackChanged)({
                    actionListId: i,
                    isPlaying: !s
                }))
            }
        }

        function K9({
            actionListId: e
        }, t) {
            e ? Ua({
                store: t,
                actionListId: e
            }) : Vg({
                store: t
            }), Ti(t)
        }

        function $9(e, t) {
            Ti(t), Mg({
                store: t,
                elementApi: me
            })
        }

        function yi({
            store: e,
            rawData: t,
            allowEvents: n,
            testManual: i
        }) {
            let {
                ixSession: a
            } = e.getState();
            t && e.dispatch((0, Ie.rawDataImported)(t)), a.active || (e.dispatch((0, Ie.sessionInitialized)({
                hasBoundaryNodes: !!document.querySelector(pi),
                reducedMotion: document.body.hasAttribute("data-wf-ix-vacation") && window.matchMedia("(prefers-reduced-motion)").matches
            })), n && (iC(e), Z9(), e.getState().ixSession.hasDefinedMediaQueries && H9(e)), e.dispatch((0, Ie.sessionStarted)()), J9(e, i))
        }

        function Z9() {
            let {
                documentElement: e
            } = document;
            e.className.indexOf(Lg) === -1 && (e.className += ` ${Lg}`)
        }

        function J9(e, t) {
            let n = i => {
                let {
                    ixSession: a,
                    ixParameters: r
                } = e.getState();
                a.active && (e.dispatch((0, Ie.animationFrameChanged)(i, r)), t ? z9(e, n) : requestAnimationFrame(n))
            };
            n(window.performance.now())
        }

        function Ti(e) {
            let {
                ixSession: t
            } = e.getState();
            if (t.active) {
                let {
                    eventListeners: n
                } = t;
                n.forEach(eC), U9(), e.dispatch((0, Ie.sessionStopped)())
            }
        }

        function eC({
            target: e,
            listenerParams: t
        }) {
            e.removeEventListener.apply(e, t)
        }

        function tC({
            store: e,
            eventStateKey: t,
            eventTarget: n,
            eventId: i,
            eventConfig: a,
            actionListId: r,
            parameterGroup: o,
            smoothing: s,
            restingValue: c
        }) {
            let {
                ixData: d,
                ixSession: I
            } = e.getState(), {
                events: E
            } = d, p = E[i], {
                eventTypeId: g
            } = p, v = {}, m = {}, h = [], {
                continuousActionGroups: T
            } = o, {
                id: A
            } = o;
            F9(g, a) && (A = D9(t, A));
            let b = I.hasBoundaryNodes && n ? me.getClosestElement(n, pi) : null;
            T.forEach(N => {
                let {
                    keyframe: P,
                    actionItems: C
                } = N;
                C.forEach(G => {
                    let {
                        actionTypeId: X
                    } = G, {
                        target: B
                    } = G.config;
                    if (!B) return;
                    let z = B.boundaryMode ? b : null,
                        J = G9(B) + Fa + X;
                    if (m[J] = nC(m[J], P, G), !v[J]) {
                        v[J] = !0;
                        let {
                            config: x
                        } = G;
                        gi({
                            config: x,
                            event: p,
                            eventTarget: n,
                            elementRoot: z,
                            elementApi: me
                        }).forEach(O => {
                            h.push({
                                element: O,
                                key: J
                            })
                        })
                    }
                })
            }), h.forEach(({
                element: N,
                key: P
            }) => {
                let C = m[P],
                    G = (0, ot.default)(C, "[0].actionItems[0]", {}),
                    {
                        actionTypeId: X
                    } = G,
                    z = (X === Me.ActionTypeConsts.PLUGIN_RIVE ? (G.config ? .target ? .selectorGuids || []).length === 0 : Ii(X)) ? Va(X)(N, G) : null,
                    J = Da({
                        element: N,
                        actionItem: G,
                        elementApi: me
                    }, z);
                qa({
                    store: e,
                    element: N,
                    eventId: i,
                    actionListId: r,
                    actionItem: G,
                    destination: J,
                    continuous: !0,
                    parameterId: A,
                    actionGroups: C,
                    smoothing: s,
                    restingValue: c,
                    pluginInstance: z
                })
            })
        }

        function nC(e = [], t, n) {
            let i = [...e],
                a;
            return i.some((r, o) => r.keyframe === t ? (a = o, !0) : !1), a == null && (a = i.length, i.push({
                keyframe: t,
                actionItems: []
            })), i[a].actionItems.push(n), i
        }

        function iC(e) {
            let {
                ixData: t
            } = e.getState(), {
                eventTypeMap: n
            } = t;
            Fg(e), (0, gn.default)(n, (a, r) => {
                let o = b9.default[r];
                if (!o) {
                    console.warn(`IX2 event type not configured: ${r}`);
                    return
                }
                uC({
                    logic: o,
                    store: e,
                    events: a
                })
            });
            let {
                ixSession: i
            } = e.getState();
            i.eventListeners.length && aC(e)
        }
        var rC = ["resize", "orientationchange"];

        function aC(e) {
            let t = () => {
                Fg(e)
            };
            rC.forEach(n => {
                window.addEventListener(n, t), e.dispatch((0, Ie.eventListenerAdded)(window, [n, t]))
            }), t()
        }

        function Fg(e) {
            let {
                ixSession: t,
                ixData: n
            } = e.getState(), i = window.innerWidth;
            if (i !== t.viewportWidth) {
                let {
                    mediaQueries: a
                } = n;
                e.dispatch((0, Ie.viewportWidthChanged)({
                    width: i,
                    mediaQueries: a
                }))
            }
        }
        var oC = (e, t) => (0, v9.default)((0, O9.default)(e, t), _9.default),
            sC = (e, t) => {
                (0, gn.default)(e, (n, i) => {
                    n.forEach((a, r) => {
                        let o = i + Fa + r;
                        t(a, i, o)
                    })
                })
            },
            cC = e => {
                let t = {
                    target: e.target,
                    targets: e.targets
                };
                return gi({
                    config: t,
                    elementApi: me
                })
            };

        function uC({
            logic: e,
            store: t,
            events: n
        }) {
            lC(n);
            let {
                types: i,
                handler: a
            } = e, {
                ixData: r
            } = t.getState(), {
                actionLists: o
            } = r, s = oC(n, cC);
            if (!(0, m9.default)(s)) return;
            (0, gn.default)(s, (E, p) => {
                let g = n[p],
                    {
                        action: v,
                        id: m,
                        mediaQueries: h = r.mediaQueryKeys
                    } = g,
                    {
                        actionListId: T
                    } = v.config;
                q9(h, r.mediaQueryKeys) || t.dispatch((0, Ie.mediaQueriesDefined)()), v.actionTypeId === Me.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION && (Array.isArray(g.config) ? g.config : [g.config]).forEach(b => {
                    let {
                        continuousParameterGroupId: N
                    } = b, P = (0, ot.default)(o, `${T}.continuousParameterGroups`, []), C = (0, T9.default)(P, ({
                        id: B
                    }) => B === N), G = (b.smoothing || 0) / 100, X = (b.restingState || 0) / 100;
                    C && E.forEach((B, z) => {
                        let J = m + Fa + z;
                        tC({
                            store: t,
                            eventStateKey: J,
                            eventTarget: B,
                            eventId: m,
                            eventConfig: b,
                            actionListId: T,
                            parameterGroup: C,
                            smoothing: G,
                            restingValue: X
                        })
                    })
                }), (v.actionTypeId === Me.ActionTypeConsts.GENERAL_START_ACTION || xa(v.actionTypeId)) && Dg({
                    store: t,
                    actionListId: T,
                    eventId: m
                })
            });
            let c = E => {
                    let {
                        ixSession: p
                    } = t.getState();
                    sC(s, (g, v, m) => {
                        let h = n[v],
                            T = p.eventState[m],
                            {
                                action: A,
                                mediaQueries: b = r.mediaQueryKeys
                            } = h;
                        if (!Ei(b, p.mediaQueryKey)) return;
                        let N = (P = {}) => {
                            let C = a({
                                store: t,
                                element: g,
                                event: h,
                                eventConfig: P,
                                nativeEvent: E,
                                eventStateKey: m
                            }, T);
                            k9(C, T) || t.dispatch((0, Ie.eventStateChanged)(m, C))
                        };
                        A.actionTypeId === Me.ActionTypeConsts.GENERAL_CONTINUOUS_ACTION ? (Array.isArray(h.config) ? h.config : [h.config]).forEach(N) : N()
                    })
                },
                d = (0, h9.default)(c, Y9),
                I = ({
                    target: E = document,
                    types: p,
                    throttle: g
                }) => {
                    p.split(" ").filter(Boolean).forEach(v => {
                        let m = g ? d : c;
                        E.addEventListener(v, m), t.dispatch((0, Ie.eventListenerAdded)(E, [v, m]))
                    })
                };
            Array.isArray(i) ? i.forEach(I) : typeof i == "string" && I(e)
        }

        function lC(e) {
            if (!B9) return;
            let t = {},
                n = "";
            for (let i in e) {
                let {
                    eventTypeId: a,
                    target: r
                } = e[i], o = me.getQuerySelector(r);
                t[o] || (a === Me.EventTypeConsts.MOUSE_CLICK || a === Me.EventTypeConsts.MOUSE_SECOND_CLICK) && (t[o] = !0, n += o + "{cursor: pointer;touch-action: manipulation;}")
            }
            if (n) {
                let i = document.createElement("style");
                i.textContent = n, document.body.appendChild(i)
            }
        }

        function Dg({
            store: e,
            actionListId: t,
            eventId: n
        }) {
            let {
                ixData: i,
                ixSession: a
            } = e.getState(), {
                actionLists: r,
                events: o
            } = i, s = o[n], c = r[t];
            if (c && c.useFirstGroupAsInitialState) {
                let d = (0, ot.default)(c, "actionItemGroups[0].actionItems", []),
                    I = (0, ot.default)(s, "mediaQueries", i.mediaQueryKeys);
                if (!Ei(I, a.mediaQueryKey)) return;
                d.forEach(E => {
                    let {
                        config: p,
                        actionTypeId: g
                    } = E, v = p ? .target ? .useEventTarget === !0 && p ? .target ? .objectId == null ? {
                        target: s.target,
                        targets: s.targets
                    } : p, m = gi({
                        config: v,
                        event: s,
                        elementApi: me
                    }), h = Ii(g);
                    m.forEach(T => {
                        let A = h ? Va(g)(T, E) : null;
                        qa({
                            destination: Da({
                                element: T,
                                actionItem: E,
                                elementApi: me
                            }, A),
                            immediate: !0,
                            store: e,
                            element: T,
                            eventId: n,
                            actionItem: E,
                            actionListId: t,
                            pluginInstance: A
                        })
                    })
                })
            }
        }

        function Vg({
            store: e
        }) {
            let {
                ixInstances: t
            } = e.getState();
            (0, gn.default)(t, n => {
                if (!n.continuous) {
                    let {
                        actionListId: i,
                        verbose: a
                    } = n;
                    ka(n, e), a && e.dispatch((0, Ie.actionListPlaybackChanged)({
                        actionListId: i,
                        isPlaying: !1
                    }))
                }
            })
        }

        function Ua({
            store: e,
            eventId: t,
            eventTarget: n,
            eventStateKey: i,
            actionListId: a
        }) {
            let {
                ixInstances: r,
                ixSession: o
            } = e.getState(), s = o.hasBoundaryNodes && n ? me.getClosestElement(n, pi) : null;
            (0, gn.default)(r, c => {
                let d = (0, ot.default)(c, "actionItem.config.target.boundaryMode"),
                    I = i ? c.eventStateKey === i : !0;
                if (c.actionListId === a && c.eventId === t && I) {
                    if (s && d && !me.elementContains(s, c.element)) return;
                    ka(c, e), c.verbose && e.dispatch((0, Ie.actionListPlaybackChanged)({
                        actionListId: a,
                        isPlaying: !1
                    }))
                }
            })
        }

        function Ga({
            store: e,
            eventId: t,
            eventTarget: n,
            eventStateKey: i,
            actionListId: a,
            groupIndex: r = 0,
            immediate: o,
            verbose: s
        }) {
            let {
                ixData: c,
                ixSession: d
            } = e.getState(), {
                events: I
            } = c, E = I[t] || {}, {
                mediaQueries: p = c.mediaQueryKeys
            } = E, g = (0, ot.default)(c, `actionLists.${a}`, {}), {
                actionItemGroups: v,
                useFirstGroupAsInitialState: m
            } = g;
            if (!v || !v.length) return !1;
            r >= v.length && (0, ot.default)(E, "config.loop") && (r = 0), r === 0 && m && r++;
            let T = (r === 0 || r === 1 && m) && xa(E.action ? .actionTypeId) ? E.config.delay : void 0,
                A = (0, ot.default)(v, [r, "actionItems"], []);
            if (!A.length || !Ei(p, d.mediaQueryKey)) return !1;
            let b = d.hasBoundaryNodes && n ? me.getClosestElement(n, pi) : null,
                N = w9(A),
                P = !1;
            return A.forEach((C, G) => {
                let {
                    config: X,
                    actionTypeId: B
                } = C, z = Ii(B), {
                    target: J
                } = X;
                if (!J) return;
                let x = J.boundaryMode ? b : null;
                gi({
                    config: X,
                    event: E,
                    eventTarget: n,
                    elementRoot: x,
                    elementApi: me
                }).forEach((M, Y) => {
                    let q = z ? Va(B)(M, C) : null,
                        ee = z ? X9(B)(M, C) : null;
                    P = !0;
                    let Z = N === G && Y === 0,
                        se = P9({
                            element: M,
                            actionItem: C
                        }),
                        ve = Da({
                            element: M,
                            actionItem: C,
                            elementApi: me
                        }, q);
                    qa({
                        store: e,
                        element: M,
                        actionItem: C,
                        eventId: t,
                        eventTarget: n,
                        eventStateKey: i,
                        actionListId: a,
                        groupIndex: r,
                        isCarrier: Z,
                        computedStyle: se,
                        destination: ve,
                        immediate: o,
                        verbose: s,
                        pluginInstance: q,
                        pluginDuration: ee,
                        instanceDelay: T
                    })
                })
            }), P
        }

        function qa(e) {
            let {
                store: t,
                computedStyle: n,
                ...i
            } = e, {
                element: a,
                actionItem: r,
                immediate: o,
                pluginInstance: s,
                continuous: c,
                restingValue: d,
                eventId: I
            } = i, E = !c, p = N9(), {
                ixElements: g,
                ixSession: v,
                ixData: m
            } = t.getState(), h = L9(g, a), {
                refState: T
            } = g[h] || {}, A = me.getRefType(a), b = v.reducedMotion && Me.ReducedMotionTypes[r.actionTypeId], N;
            if (b && c) switch (m.events[I] ? .eventTypeId) {
                case Me.EventTypeConsts.MOUSE_MOVE:
                case Me.EventTypeConsts.MOUSE_MOVE_IN_VIEWPORT:
                    N = d;
                    break;
                default:
                    N = .5;
                    break
            }
            let P = M9(a, T, n, r, me, s);
            if (t.dispatch((0, Ie.instanceAdded)({
                    instanceId: p,
                    elementId: h,
                    origin: P,
                    refType: A,
                    skipMotion: b,
                    skipToValue: N,
                    ...i
                })), Ug(document.body, "ix2-animation-started", p), o) {
                dC(t, p);
                return
            }
            yt({
                store: t,
                select: ({
                    ixInstances: C
                }) => C[p],
                onChange: Gg
            }), E && t.dispatch((0, Ie.instanceStarted)(p, v.tick))
        }

        function ka(e, t) {
            Ug(document.body, "ix2-animation-stopping", {
                instanceId: e.id,
                state: t.getState()
            });
            let {
                elementId: n,
                actionItem: i
            } = e, {
                ixElements: a
            } = t.getState(), {
                ref: r,
                refType: o
            } = a[n] || {};
            o === Pg && V9(r, i, me), t.dispatch((0, Ie.instanceRemoved)(e.id))
        }

        function Ug(e, t, n) {
            let i = document.createEvent("CustomEvent");
            i.initCustomEvent(t, !0, !0, n), e.dispatchEvent(i)
        }

        function dC(e, t) {
            let {
                ixParameters: n
            } = e.getState();
            e.dispatch((0, Ie.instanceStarted)(t, 0)), e.dispatch((0, Ie.animationFrameChanged)(performance.now(), n));
            let {
                ixInstances: i
            } = e.getState();
            Gg(i[t], e)
        }

        function Gg(e, t) {
            let {
                active: n,
                continuous: i,
                complete: a,
                elementId: r,
                actionItem: o,
                actionTypeId: s,
                renderType: c,
                current: d,
                groupIndex: I,
                eventId: E,
                eventTarget: p,
                eventStateKey: g,
                actionListId: v,
                isCarrier: m,
                styleProp: h,
                verbose: T,
                pluginInstance: A
            } = e, {
                ixData: b,
                ixSession: N
            } = t.getState(), {
                events: P
            } = b, C = P && P[E] ? P[E] : {}, {
                mediaQueries: G = b.mediaQueryKeys
            } = C;
            if (Ei(G, N.mediaQueryKey) && (i || n || a)) {
                if (d || c === R9 && a) {
                    t.dispatch((0, Ie.elementStateChanged)(r, s, d, o));
                    let {
                        ixElements: X
                    } = t.getState(), {
                        ref: B,
                        refType: z,
                        refState: J
                    } = X[r] || {}, x = J && J[s];
                    (z === Pg || Ii(s)) && C9(B, J, x, E, o, h, me, c, A)
                }
                if (a) {
                    if (m) {
                        let X = Ga({
                            store: t,
                            eventId: E,
                            eventTarget: p,
                            eventStateKey: g,
                            actionListId: v,
                            groupIndex: I + 1,
                            verbose: T
                        });
                        T && !X && t.dispatch((0, Ie.actionListPlaybackChanged)({
                            actionListId: v,
                            isPlaying: !1
                        }))
                    }
                    ka(e, t)
                }
            }
        }
    });
    var Xg = u(Ya => {
        "use strict";
        Object.defineProperty(Ya, "__esModule", {
            value: !0
        });

        function fC(e, t) {
            for (var n in t) Object.defineProperty(e, n, {
                enumerable: !0,
                get: t[n]
            })
        }
        fC(Ya, {
            actions: function() {
                return EC
            },
            destroy: function() {
                return kg
            },
            init: function() {
                return mC
            },
            setEnv: function() {
                return TC
            },
            store: function() {
                return mi
            }
        });
        var pC = Wi(),
            gC = IC(Wf()),
            Ba = Ma(),
            EC = yC(ii());

        function IC(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }

        function qg(e) {
            if (typeof WeakMap != "function") return null;
            var t = new WeakMap,
                n = new WeakMap;
            return (qg = function(i) {
                return i ? n : t
            })(e)
        }

        function yC(e, t) {
            if (!t && e && e.__esModule) return e;
            if (e === null || typeof e != "object" && typeof e != "function") return {
                default: e
            };
            var n = qg(t);
            if (n && n.has(e)) return n.get(e);
            var i = {
                    __proto__: null
                },
                a = Object.defineProperty && Object.getOwnPropertyDescriptor;
            for (var r in e)
                if (r !== "default" && Object.prototype.hasOwnProperty.call(e, r)) {
                    var o = a ? Object.getOwnPropertyDescriptor(e, r) : null;
                    o && (o.get || o.set) ? Object.defineProperty(i, r, o) : i[r] = e[r]
                }
            return i.default = e, n && n.set(e, i), i
        }
        var mi = (0, pC.createStore)(gC.default);

        function TC(e) {
            e() && (0, Ba.observeRequests)(mi)
        }

        function mC(e) {
            kg(), (0, Ba.startEngine)({
                store: mi,
                rawData: e,
                allowEvents: !0
            })
        }

        function kg() {
            (0, Ba.stopEngine)(mi)
        }
    });
    var Hg = u((nM, Wg) => {
        "use strict";
        var Bg = Ue(),
            Yg = Xg();
        Yg.setEnv(Bg.env);
        Bg.define("ix2", Wg.exports = function() {
            return Yg
        })
    });
    var jg = u((iM, Qg) => {
        "use strict";
        var Wa = window.jQuery,
            je = {},
            vi = [],
            zg = ".w-ix",
            _i = {
                reset: function(e, t) {
                    t.__wf_intro = null
                },
                intro: function(e, t) {
                    t.__wf_intro || (t.__wf_intro = !0, Wa(t).triggerHandler(je.types.INTRO))
                },
                outro: function(e, t) {
                    t.__wf_intro && (t.__wf_intro = null, Wa(t).triggerHandler(je.types.OUTRO))
                }
            };
        je.triggers = {};
        je.types = {
            INTRO: "w-ix-intro" + zg,
            OUTRO: "w-ix-outro" + zg
        };
        je.init = function() {
            for (var e = vi.length, t = 0; t < e; t++) {
                var n = vi[t];
                n[0](0, n[1])
            }
            vi = [], Wa.extend(je.triggers, _i)
        };
        je.async = function() {
            for (var e in _i) {
                var t = _i[e];
                _i.hasOwnProperty(e) && (je.triggers[e] = function(n, i) {
                    vi.push([t, i])
                })
            }
        };
        je.async();
        Qg.exports = je
    });
    var za = u((rM, Zg) => {
        "use strict";
        var Ha = jg();

        function Kg(e, t) {
            var n = document.createEvent("CustomEvent");
            n.initCustomEvent(t, !0, !0, null), e.dispatchEvent(n)
        }
        var vC = window.jQuery,
            Oi = {},
            $g = ".w-ix",
            _C = {
                reset: function(e, t) {
                    Ha.triggers.reset(e, t)
                },
                intro: function(e, t) {
                    Ha.triggers.intro(e, t), Kg(t, "COMPONENT_ACTIVE")
                },
                outro: function(e, t) {
                    Ha.triggers.outro(e, t), Kg(t, "COMPONENT_INACTIVE")
                }
            };
        Oi.triggers = {};
        Oi.types = {
            INTRO: "w-ix-intro" + $g,
            OUTRO: "w-ix-outro" + $g
        };
        vC.extend(Oi.triggers, _C);
        Zg.exports = Oi
    });
    var eE = u((aM, Jg) => {
        "use strict";
        var st = Ue(),
            OC = za(),
            Oe = {
                ARROW_LEFT: 37,
                ARROW_UP: 38,
                ARROW_RIGHT: 39,
                ARROW_DOWN: 40,
                ESCAPE: 27,
                SPACE: 32,
                ENTER: 13,
                HOME: 36,
                END: 35
            };
        st.define("navbar", Jg.exports = function(e, t) {
            var n = {},
                i = e.tram,
                a = e(window),
                r = e(document),
                o = t.debounce,
                s, c, d, I, E = st.env(),
                p = '<div class="w-nav-overlay" data-wf-ignore />',
                g = ".w-nav",
                v = "w--open",
                m = "w--nav-dropdown-open",
                h = "w--nav-dropdown-toggle-open",
                T = "w--nav-dropdown-list-open",
                A = "w--nav-link-open",
                b = OC.triggers,
                N = e();
            n.ready = n.design = n.preview = P, n.destroy = function() {
                N = e(), C(), c && c.length && c.each(z)
            };

            function P() {
                d = E && st.env("design"), I = st.env("editor"), s = e(document.body), c = r.find(g), c.length && (c.each(B), C(), G())
            }

            function C() {
                st.resize.off(X)
            }

            function G() {
                st.resize.on(X)
            }

            function X() {
                c.each(L)
            }

            function B(f, F) {
                var W = e(F),
                    V = e.data(F, g);
                V || (V = e.data(F, g, {
                    open: !1,
                    el: W,
                    config: {},
                    selectedIdx: -1
                })), V.menu = W.find(".w-nav-menu"), V.links = V.menu.find(".w-nav-link"), V.dropdowns = V.menu.find(".w-dropdown"), V.dropdownToggle = V.menu.find(".w-dropdown-toggle"), V.dropdownList = V.menu.find(".w-dropdown-list"), V.button = W.find(".w-nav-button"), V.container = W.find(".w-container"), V.overlayContainerId = "w-nav-overlay-" + f, V.outside = Ce(V);
                var de = W.find(".w-nav-brand");
                de && de.attr("href") === "/" && de.attr("aria-label") == null && de.attr("aria-label", "home"), V.button.attr("style", "-webkit-user-select: text;"), V.button.attr("aria-label") == null && V.button.attr("aria-label", "menu"), V.button.attr("role", "button"), V.button.attr("tabindex", "0"), V.button.attr("aria-controls", V.overlayContainerId), V.button.attr("aria-haspopup", "menu"), V.button.attr("aria-expanded", "false"), V.el.off(g), V.button.off(g), V.menu.off(g), O(V), d ? (J(V), V.el.on("setting" + g, M(V))) : (x(V), V.button.on("click" + g, se(V)), V.menu.on("click" + g, "a", ve(V)), V.button.on("keydown" + g, Y(V)), V.el.on("keydown" + g, q(V))), L(f, F)
            }

            function z(f, F) {
                var W = e.data(F, g);
                W && (J(W), e.removeData(F, g))
            }

            function J(f) {
                f.overlay && (H(f, !0), f.overlay.remove(), f.overlay = null)
            }

            function x(f) {
                f.overlay || (f.overlay = e(p).appendTo(f.el), f.overlay.attr("id", f.overlayContainerId), f.parent = f.menu.parent(), H(f, !0))
            }

            function O(f) {
                var F = {},
                    W = f.config || {},
                    V = F.animation = f.el.attr("data-animation") || "default";
                F.animOver = /^over/.test(V), F.animDirect = /left$/.test(V) ? -1 : 1, W.animation !== V && f.open && t.defer(Z, f), F.easing = f.el.attr("data-easing") || "ease", F.easing2 = f.el.attr("data-easing2") || "ease";
                var de = f.el.attr("data-duration");
                F.duration = de != null ? Number(de) : 400, F.docHeight = f.el.attr("data-doc-height"), f.config = F
            }

            function M(f) {
                return function(F, W) {
                    W = W || {};
                    var V = a.width();
                    O(f), W.open === !0 && re(f, !0), W.open === !1 && H(f, !0), f.open && t.defer(function() {
                        V !== a.width() && Z(f)
                    })
                }
            }

            function Y(f) {
                return function(F) {
                    switch (F.keyCode) {
                        case Oe.SPACE:
                        case Oe.ENTER:
                            return se(f)(), F.preventDefault(), F.stopPropagation();
                        case Oe.ESCAPE:
                            return H(f), F.preventDefault(), F.stopPropagation();
                        case Oe.ARROW_RIGHT:
                        case Oe.ARROW_DOWN:
                        case Oe.HOME:
                        case Oe.END:
                            return f.open ? (F.keyCode === Oe.END ? f.selectedIdx = f.links.length - 1 : f.selectedIdx = 0, ee(f), F.preventDefault(), F.stopPropagation()) : (F.preventDefault(), F.stopPropagation())
                    }
                }
            }

            function q(f) {
                return function(F) {
                    if (f.open) switch (f.selectedIdx = f.links.index(document.activeElement), F.keyCode) {
                        case Oe.HOME:
                        case Oe.END:
                            return F.keyCode === Oe.END ? f.selectedIdx = f.links.length - 1 : f.selectedIdx = 0, ee(f), F.preventDefault(), F.stopPropagation();
                        case Oe.ESCAPE:
                            return H(f), f.button.focus(), F.preventDefault(), F.stopPropagation();
                        case Oe.ARROW_LEFT:
                        case Oe.ARROW_UP:
                            return f.selectedIdx = Math.max(-1, f.selectedIdx - 1), ee(f), F.preventDefault(), F.stopPropagation();
                        case Oe.ARROW_RIGHT:
                        case Oe.ARROW_DOWN:
                            return f.selectedIdx = Math.min(f.links.length - 1, f.selectedIdx + 1), ee(f), F.preventDefault(), F.stopPropagation()
                    }
                }
            }

            function ee(f) {
                if (f.links[f.selectedIdx]) {
                    var F = f.links[f.selectedIdx];
                    F.focus(), ve(F)
                }
            }

            function Z(f) {
                f.open && (H(f, !0), re(f, !0))
            }

            function se(f) {
                return o(function() {
                    f.open ? H(f) : re(f)
                })
            }

            function ve(f) {
                return function(F) {
                    var W = e(this),
                        V = W.attr("href");
                    if (!st.validClick(F.currentTarget)) {
                        F.preventDefault();
                        return
                    }
                    V && V.indexOf("#") === 0 && f.open && H(f)
                }
            }

            function Ce(f) {
                return f.outside && r.off("click" + g, f.outside),
                    function(F) {
                        var W = e(F.target);
                        I && W.closest(".w-editor-bem-EditorOverlay").length || ye(f, W)
                    }
            }
            var ye = o(function(f, F) {
                if (f.open) {
                    var W = F.closest(".w-nav-menu");
                    f.menu.is(W) || H(f)
                }
            });

            function L(f, F) {
                var W = e.data(F, g),
                    V = W.collapsed = W.button.css("display") !== "none";
                if (W.open && !V && !d && H(W, !0), W.container.length) {
                    var de = Q(W);
                    W.links.each(de), W.dropdowns.each(de)
                }
                W.open && oe(W)
            }
            var k = "max-width";

            function Q(f) {
                var F = f.container.css(k);
                return F === "none" && (F = ""),
                    function(W, V) {
                        V = e(V), V.css(k, ""), V.css(k) === "none" && V.css(k, F)
                    }
            }

            function U(f, F) {
                F.setAttribute("data-nav-menu-open", "")
            }

            function ne(f, F) {
                F.removeAttribute("data-nav-menu-open")
            }

            function re(f, F) {
                if (f.open) return;
                f.open = !0, f.menu.each(U), f.links.addClass(A), f.dropdowns.addClass(m), f.dropdownToggle.addClass(h), f.dropdownList.addClass(T), f.button.addClass(v);
                var W = f.config,
                    V = W.animation;
                (V === "none" || !i.support.transform || W.duration <= 0) && (F = !0);
                var de = oe(f),
                    Je = f.menu.outerHeight(!0),
                    ke = f.menu.outerWidth(!0),
                    l = f.el.height(),
                    y = f.el[0];
                if (L(0, y), b.intro(0, y), st.redraw.up(), d || r.on("click" + g, f.outside), F) {
                    w();
                    return
                }
                var _ = "transform " + W.duration + "ms " + W.easing;
                if (f.overlay && (N = f.menu.prev(), f.overlay.show().append(f.menu)), W.animOver) {
                    i(f.menu).add(_).set({
                        x: W.animDirect * ke,
                        height: de
                    }).start({
                        x: 0
                    }).then(w), f.overlay && f.overlay.width(ke);
                    return
                }
                var S = l + Je;
                i(f.menu).add(_).set({
                    y: -S
                }).start({
                    y: 0
                }).then(w);

                function w() {
                    f.button.attr("aria-expanded", "true")
                }
            }

            function oe(f) {
                var F = f.config,
                    W = F.docHeight ? r.height() : s.height();
                return F.animOver ? f.menu.height(W) : f.el.css("position") !== "fixed" && (W -= f.el.outerHeight(!0)), f.overlay && f.overlay.height(W), W
            }

            function H(f, F) {
                if (!f.open) return;
                f.open = !1, f.button.removeClass(v);
                var W = f.config;
                if ((W.animation === "none" || !i.support.transform || W.duration <= 0) && (F = !0), b.outro(0, f.el[0]), r.off("click" + g, f.outside), F) {
                    i(f.menu).stop(), y();
                    return
                }
                var V = "transform " + W.duration + "ms " + W.easing2,
                    de = f.menu.outerHeight(!0),
                    Je = f.menu.outerWidth(!0),
                    ke = f.el.height();
                if (W.animOver) {
                    i(f.menu).add(V).start({
                        x: Je * W.animDirect
                    }).then(y);
                    return
                }
                var l = ke + de;
                i(f.menu).add(V).start({
                    y: -l
                }).then(y);

                function y() {
                    f.menu.height(""), i(f.menu).set({
                        x: 0,
                        y: 0
                    }), f.menu.each(ne), f.links.removeClass(A), f.dropdowns.removeClass(m), f.dropdownToggle.removeClass(h), f.dropdownList.removeClass(T), f.overlay && f.overlay.children().length && (N.length ? f.menu.insertAfter(N) : f.menu.prependTo(f.parent), f.overlay.attr("style", "").hide()), f.el.triggerHandler("w-close"), f.button.attr("aria-expanded", "false")
                }
            }
            return n
        })
    });
    var tE = u(Qa => {
        "use strict";
        Object.defineProperty(Qa, "__esModule", {
            value: !0
        });
        Object.defineProperty(Qa, "default", {
            enumerable: !0,
            get: function() {
                return hC
            }
        });

        function hC(e, t, n, i, a, r, o, s, c, d, I, E, p) {
            return function(g) {
                e(g);
                var v = g.form,
                    m = {
                        name: v.attr("data-name") || v.attr("name") || "Untitled Form",
                        pageId: v.attr("data-wf-page-id") || "",
                        elementId: v.attr("data-wf-element-id") || "",
                        domain: E("html").attr("data-wf-domain") || null,
                        source: t.href,
                        test: n.env(),
                        fields: {},
                        fileUploads: {},
                        dolphin: /pass[\s-_]?(word|code)|secret|login|credentials/i.test(v.html()),
                        trackingCookies: i()
                    };
                let h = v.attr("data-wf-flow");
                h && (m.wfFlow = h), a(g);
                var T = r(v, m.fields);
                if (T) return o(T);
                if (m.fileUploads = s(v), c(g), !d) {
                    I(g);
                    return
                }
                E.ajax({
                    url: p,
                    type: "POST",
                    data: m,
                    dataType: "json",
                    crossDomain: !0
                }).done(function(A) {
                    A && A.code === 200 && (g.success = !0), I(g)
                }).fail(function() {
                    I(g)
                })
            }
        }
    });
    var iE = u((sM, nE) => {
        "use strict";
        var hi = Ue(),
            bC = (e, t, n, i) => {
                let a = document.createElement("div");
                t.appendChild(a), turnstile.render(a, {
                    sitekey: e,
                    callback: function(r) {
                        n(r)
                    },
                    "error-callback": function() {
                        i()
                    }
                })
            };
        hi.define("forms", nE.exports = function(e, t) {
            let n = "TURNSTILE_LOADED";
            var i = {},
                a = e(document),
                r, o = window.location,
                s = window.XDomainRequest && !window.atob,
                c = ".w-form",
                d, I = /e(-)?mail/i,
                E = /^\S+@\S+$/,
                p = window.alert,
                g = hi.env(),
                v, m, h;
            let T = a.find("[data-turnstile-sitekey]").data("turnstile-sitekey"),
                A;
            var b = /list-manage[1-9]?.com/i,
                N = t.debounce(function() {
                    p("Oops! This page has improperly configured forms. Please contact your website administrator to fix this issue.")
                }, 100);
            i.ready = i.design = i.preview = function() {
                C(), P(), !g && !v && X()
            };

            function P() {
                d = e("html").attr("data-wf-site"), m = "https://webflow.com/api/v1/form/" + d, s && m.indexOf("https://webflow.com") >= 0 && (m = m.replace("https://webflow.com", "https://formdata.webflow.com")), h = `${m}/signFile`, r = e(c + " form"), r.length && r.each(G)
            }

            function C() {
                T && (A = document.createElement("script"), A.src = "https://challenges.cloudflare.com/turnstile/v0/api.js", document.head.appendChild(A), A.onload = () => {
                    a.trigger(n)
                })
            }

            function G(L, k) {
                var Q = e(k),
                    U = e.data(k, c);
                U || (U = e.data(k, c, {
                    form: Q
                })), B(U);
                var ne = Q.closest("div.w-form");
                U.done = ne.find("> .w-form-done"), U.fail = ne.find("> .w-form-fail"), U.fileUploads = ne.find(".w-file-upload"), U.fileUploads.each(function(H) {
                    ve(H, U)
                }), T && (U.wait = !1, z(U), a.on(typeof turnstile < "u" ? "ready" : n, function() {
                    bC(T, k, H => {
                        U.turnstileToken = H, B(U)
                    }, () => {
                        z(U)
                    })
                }));
                var re = U.form.attr("aria-label") || U.form.attr("data-name") || "Form";
                U.done.attr("aria-label") || U.form.attr("aria-label", re), U.done.attr("tabindex", "-1"), U.done.attr("role", "region"), U.done.attr("aria-label") || U.done.attr("aria-label", re + " success"), U.fail.attr("tabindex", "-1"), U.fail.attr("role", "region"), U.fail.attr("aria-label") || U.fail.attr("aria-label", re + " failure");
                var oe = U.action = Q.attr("action");
                if (U.handler = null, U.redirect = Q.attr("data-redirect"), b.test(oe)) {
                    U.handler = ee;
                    return
                }
                if (!oe) {
                    if (d) {
                        U.handler = (() => {
                            let H = tE().default;
                            return H(B, o, hi, M, se, J, p, x, z, d, Z, e, m)
                        })();
                        return
                    }
                    N()
                }
            }

            function X() {
                v = !0, a.on("submit", c + " form", function(H) {
                    var f = e.data(this, c);
                    f.handler && (f.evt = H, f.handler(f))
                });
                let L = ".w-checkbox-input",
                    k = ".w-radio-input",
                    Q = "w--redirected-checked",
                    U = "w--redirected-focus",
                    ne = "w--redirected-focus-visible",
                    re = ":focus-visible, [data-wf-focus-visible]",
                    oe = [
                        ["checkbox", L],
                        ["radio", k]
                    ];
                a.on("change", c + ' form input[type="checkbox"]:not(' + L + ")", H => {
                    e(H.target).siblings(L).toggleClass(Q)
                }), a.on("change", c + ' form input[type="radio"]', H => {
                    e(`input[name="${H.target.name}"]:not(${L})`).map((F, W) => e(W).siblings(k).removeClass(Q));
                    let f = e(H.target);
                    f.hasClass("w-radio-input") || f.siblings(k).addClass(Q)
                }), oe.forEach(([H, f]) => {
                    a.on("focus", c + ` form input[type="${H}"]:not(` + f + ")", F => {
                        e(F.target).siblings(f).addClass(U), e(F.target).filter(re).siblings(f).addClass(ne)
                    }), a.on("blur", c + ` form input[type="${H}"]:not(` + f + ")", F => {
                        e(F.target).siblings(f).removeClass(`${U} ${ne}`)
                    })
                })
            }

            function B(L) {
                var k = L.btn = L.form.find(':input[type="submit"]');
                L.wait = L.btn.attr("data-wait") || null, L.success = !1, k.prop("disabled", !!(T && !L.turnstileToken)), L.label && k.val(L.label)
            }

            function z(L) {
                var k = L.btn,
                    Q = L.wait;
                k.prop("disabled", !0), Q && (L.label = k.val(), k.val(Q))
            }

            function J(L, k) {
                var Q = null;
                return k = k || {}, L.find(':input:not([type="submit"]):not([type="file"])').each(function(U, ne) {
                    var re = e(ne),
                        oe = re.attr("type"),
                        H = re.attr("data-name") || re.attr("name") || "Field " + (U + 1);
                    H = encodeURIComponent(H);
                    var f = re.val();
                    if (oe === "checkbox") f = re.is(":checked");
                    else if (oe === "radio") {
                        if (k[H] === null || typeof k[H] == "string") return;
                        f = L.find('input[name="' + re.attr("name") + '"]:checked').val() || null
                    }
                    typeof f == "string" && (f = e.trim(f)), k[H] = f, Q = Q || Y(re, oe, H, f)
                }), Q
            }

            function x(L) {
                var k = {};
                return L.find(':input[type="file"]').each(function(Q, U) {
                    var ne = e(U),
                        re = ne.attr("data-name") || ne.attr("name") || "File " + (Q + 1),
                        oe = ne.attr("data-value");
                    typeof oe == "string" && (oe = e.trim(oe)), k[re] = oe
                }), k
            }
            let O = {
                _mkto_trk: "marketo"
            };

            function M() {
                return document.cookie.split("; ").reduce(function(k, Q) {
                    let U = Q.split("="),
                        ne = U[0];
                    if (ne in O) {
                        let re = O[ne],
                            oe = U.slice(1).join("=");
                        k[re] = oe
                    }
                    return k
                }, {})
            }

            function Y(L, k, Q, U) {
                var ne = null;
                return k === "password" ? ne = "Passwords cannot be submitted." : L.attr("required") ? U ? I.test(L.attr("type")) && (E.test(U) || (ne = "Please enter a valid email address for: " + Q)) : ne = "Please fill out the required field: " + Q : Q === "g-recaptcha-response" && !U && (ne = "Please confirm you\u2019re not a robot."), ne
            }

            function q(L) {
                se(L), Z(L)
            }

            function ee(L) {
                B(L);
                var k = L.form,
                    Q = {};
                if (/^https/.test(o.href) && !/^https/.test(L.action)) {
                    k.attr("method", "post");
                    return
                }
                se(L);
                var U = J(k, Q);
                if (U) return p(U);
                z(L);
                var ne;
                t.each(Q, function(f, F) {
                    I.test(F) && (Q.EMAIL = f), /^((full[ _-]?)?name)$/i.test(F) && (ne = f), /^(first[ _-]?name)$/i.test(F) && (Q.FNAME = f), /^(last[ _-]?name)$/i.test(F) && (Q.LNAME = f)
                }), ne && !Q.FNAME && (ne = ne.split(" "), Q.FNAME = ne[0], Q.LNAME = Q.LNAME || ne[1]);
                var re = L.action.replace("/post?", "/post-json?") + "&c=?",
                    oe = re.indexOf("u=") + 2;
                oe = re.substring(oe, re.indexOf("&", oe));
                var H = re.indexOf("id=") + 3;
                H = re.substring(H, re.indexOf("&", H)), Q["b_" + oe + "_" + H] = "", e.ajax({
                    url: re,
                    data: Q,
                    dataType: "jsonp"
                }).done(function(f) {
                    L.success = f.result === "success" || /already/.test(f.msg), L.success || console.info("MailChimp error: " + f.msg), Z(L)
                }).fail(function() {
                    Z(L)
                })
            }

            function Z(L) {
                var k = L.form,
                    Q = L.redirect,
                    U = L.success;
                if (U && Q) {
                    hi.location(Q);
                    return
                }
                L.done.toggle(U), L.fail.toggle(!U), U ? L.done.focus() : L.fail.focus(), k.toggle(!U), B(L)
            }

            function se(L) {
                L.evt && L.evt.preventDefault(), L.evt = null
            }

            function ve(L, k) {
                if (!k.fileUploads || !k.fileUploads[L]) return;
                var Q, U = e(k.fileUploads[L]),
                    ne = U.find("> .w-file-upload-default"),
                    re = U.find("> .w-file-upload-uploading"),
                    oe = U.find("> .w-file-upload-success"),
                    H = U.find("> .w-file-upload-error"),
                    f = ne.find(".w-file-upload-input"),
                    F = ne.find(".w-file-upload-label"),
                    W = F.children(),
                    V = H.find(".w-file-upload-error-msg"),
                    de = oe.find(".w-file-upload-file"),
                    Je = oe.find(".w-file-remove-link"),
                    ke = de.find(".w-file-upload-file-name"),
                    l = V.attr("data-w-size-error"),
                    y = V.attr("data-w-type-error"),
                    _ = V.attr("data-w-generic-error");
                if (g || F.on("click keydown", function(K) {
                        K.type === "keydown" && K.which !== 13 && K.which !== 32 || (K.preventDefault(), f.click())
                    }), F.find(".w-icon-file-upload-icon").attr("aria-hidden", "true"), Je.find(".w-icon-file-upload-remove").attr("aria-hidden", "true"), g) f.on("click", function(K) {
                    K.preventDefault()
                }), F.on("click", function(K) {
                    K.preventDefault()
                }), W.on("click", function(K) {
                    K.preventDefault()
                });
                else {
                    Je.on("click keydown", function(K) {
                        if (K.type === "keydown") {
                            if (K.which !== 13 && K.which !== 32) return;
                            K.preventDefault()
                        }
                        f.removeAttr("data-value"), f.val(""), ke.html(""), ne.toggle(!0), oe.toggle(!1), F.focus()
                    }), f.on("change", function(K) {
                        Q = K.target && K.target.files && K.target.files[0], Q && (ne.toggle(!1), H.toggle(!1), re.toggle(!0), re.focus(), ke.text(Q.name), te() || z(k), k.fileUploads[L].uploading = !0, Ce(Q, R))
                    });
                    var S = F.outerHeight();
                    f.height(S), f.width(1)
                }

                function w(K) {
                    var D = K.responseJSON && K.responseJSON.msg,
                        ie = _;
                    typeof D == "string" && D.indexOf("InvalidFileTypeError") === 0 ? ie = y : typeof D == "string" && D.indexOf("MaxFileSizeError") === 0 && (ie = l), V.text(ie), f.removeAttr("data-value"), f.val(""), re.toggle(!1), ne.toggle(!0), H.toggle(!0), H.focus(), k.fileUploads[L].uploading = !1, te() || B(k)
                }

                function R(K, D) {
                    if (K) return w(K);
                    var ie = D.fileName,
                        ae = D.postData,
                        Ee = D.fileId,
                        we = D.s3Url;
                    f.attr("data-value", Ee), ye(we, ae, Q, ie, j)
                }

                function j(K) {
                    if (K) return w(K);
                    re.toggle(!1), oe.css("display", "inline-block"), oe.focus(), k.fileUploads[L].uploading = !1, te() || B(k)
                }

                function te() {
                    var K = k.fileUploads && k.fileUploads.toArray() || [];
                    return K.some(function(D) {
                        return D.uploading
                    })
                }
            }

            function Ce(L, k) {
                var Q = new URLSearchParams({
                    name: L.name,
                    size: L.size
                });
                e.ajax({
                    type: "GET",
                    url: `${h}?${Q}`,
                    crossDomain: !0
                }).done(function(U) {
                    k(null, U)
                }).fail(function(U) {
                    k(U)
                })
            }

            function ye(L, k, Q, U, ne) {
                var re = new FormData;
                for (var oe in k) re.append(oe, k[oe]);
                re.append("file", Q, U), e.ajax({
                    type: "POST",
                    url: L,
                    data: re,
                    processData: !1,
                    contentType: !1
                }).done(function() {
                    ne(null)
                }).fail(function(H) {
                    ne(H)
                })
            }
            return i
        })
    });
    so();
    uo();
    fo();
    Eo();
    yo();
    mo();
    _o();
    Hg();
    za();
    eE();
    iE();
    Webflow.require("ix2").init({
        events: {
            "e-11": {
                id: "e-11",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-15",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-16"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".showcase-image-link-container",
                    originalId: "5d82cb59cf90c934e34828b1|5057511c-c152-83b0-90e0-59919e703ba3",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".showcase-image-link-container",
                    originalId: "5d82cb59cf90c934e34828b1|5057511c-c152-83b0-90e0-59919e703ba3",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1612163621855
            },
            "e-16": {
                id: "e-16",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-13",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-11"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".showcase-image-link-container",
                    originalId: "5d82cb59cf90c934e34828b1|5057511c-c152-83b0-90e0-59919e703ba3",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".showcase-image-link-container",
                    originalId: "5d82cb59cf90c934e34828b1|5057511c-c152-83b0-90e0-59919e703ba3",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1612163621858
            },
            "e-22": {
                id: "e-22",
                name: "",
                animationType: "preset",
                eventTypeId: "MOUSE_MOVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-12",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium"],
                target: {
                    selector: ".project-2-container",
                    originalId: "678002b05def6cc3379be9dc|57207102-3d9b-e662-46c5-a29e0e849567",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-2-container",
                    originalId: "678002b05def6cc3379be9dc|57207102-3d9b-e662-46c5-a29e0e849567",
                    appliesTo: "CLASS"
                }],
                config: [{
                    continuousParameterGroupId: "a-12-p",
                    selectedAxis: "X_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 80,
                    restingState: 50
                }, {
                    continuousParameterGroupId: "a-12-p-2",
                    selectedAxis: "Y_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 80,
                    restingState: 50
                }],
                createdOn: 1648093356690
            },
            "e-49": {
                id: "e-49",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-17",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".project-hero-section",
                    originalId: "678002b05def6cc3379be99f|dede1bd6-94c1-cbe4-0231-5c2c56a84c91",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-hero-section",
                    originalId: "678002b05def6cc3379be99f|dede1bd6-94c1-cbe4-0231-5c2c56a84c91",
                    appliesTo: "CLASS"
                }],
                config: [{
                    continuousParameterGroupId: "a-17-p",
                    smoothing: 50,
                    startsEntering: !0,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1628480277280
            },
            "e-81": {
                id: "e-81",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-25",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-569"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".project-1-button",
                    originalId: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7279",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-1-button",
                    originalId: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7279",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1579915036589
            },
            "e-82": {
                id: "e-82",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-26",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-578"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".project-1-button",
                    originalId: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7279",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-1-button",
                    originalId: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7279",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1579915036589
            },
            "e-83": {
                id: "e-83",
                animationType: "custom",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-27",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".project-1-image-container",
                    originalId: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-1-image-container",
                    originalId: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288",
                    appliesTo: "CLASS"
                }],
                config: [{
                    continuousParameterGroupId: "a-27-p",
                    smoothing: 80,
                    startsEntering: !0,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1579824908741
            },
            "e-148": {
                id: "e-148",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-149"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|9cc63cc2-7c7d-3c44-28b7-18da8a1d33b8",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|9cc63cc2-7c7d-3c44-28b7-18da8a1d33b8",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-150": {
                id: "e-150",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-31",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-970"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|e451c0d0-b168-7909-ded7-fe76d1ae6429",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|e451c0d0-b168-7909-ded7-fe76d1ae6429",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-152": {
                id: "e-152",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-153"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|0e28282b-50e2-6af7-4102-7ad5abcbd006",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|0e28282b-50e2-6af7-4102-7ad5abcbd006",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-154": {
                id: "e-154",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-31",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-155"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|edb020c2-61dc-9803-761f-d602806f8da6",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|edb020c2-61dc-9803-761f-d602806f8da6",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-156": {
                id: "e-156",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-157"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|bc274b84-3b8b-78f4-15a0-7f32a59ff054",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|bc274b84-3b8b-78f4-15a0-7f32a59ff054",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-170": {
                id: "e-170",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-171"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|57207102-3d9b-e662-46c5-a29e0e84969e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|57207102-3d9b-e662-46c5-a29e0e84969e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-178": {
                id: "e-178",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-31",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-179"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|e19d1b95-38eb-f928-ed67-47e56aac48a2",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|e19d1b95-38eb-f928-ed67-47e56aac48a2",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-180": {
                id: "e-180",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-181"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|074d149f-9a32-9bc6-b9d6-569bc4bcd53c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|074d149f-9a32-9bc6-b9d6-569bc4bcd53c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697144837817
            },
            "e-275": {
                id: "e-275",
                name: "",
                animationType: "custom",
                eventTypeId: "SLIDER_ACTIVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-33",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1406"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1608421213051
            },
            "e-302": {
                id: "e-302",
                name: "",
                animationType: "custom",
                eventTypeId: "SLIDER_INACTIVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-34",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1405"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1608421213070
            },
            "e-324": {
                id: "e-324",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-40",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1432"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".skill-card",
                    originalId: "678002b05def6cc3379be9c2|12002675-1110-c77f-de93-9c9fa8ead540",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".skill-card",
                    originalId: "678002b05def6cc3379be9c2|12002675-1110-c77f-de93-9c9fa8ead540",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697669998180
            },
            "e-338": {
                id: "e-338",
                name: "",
                animationType: "custom",
                eventTypeId: "DROPDOWN_OPEN",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-41",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1269"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".nav-link.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".nav-link.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1694714876682
            },
            "e-339": {
                id: "e-339",
                name: "",
                animationType: "custom",
                eventTypeId: "DROPDOWN_CLOSE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-42",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1268"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".nav-link.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".nav-link.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1694714876682
            },
            "e-340": {
                id: "e-340",
                name: "",
                animationType: "preset",
                eventTypeId: "NAVBAR_OPEN",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-43",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-979"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "0d699ee9-bfec-d02b-d6ea-c3edeeae146e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "0d699ee9-bfec-d02b-d6ea-c3edeeae146e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697728674631
            },
            "e-341": {
                id: "e-341",
                name: "",
                animationType: "preset",
                eventTypeId: "NAVBAR_CLOSE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-44",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-340"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "0d699ee9-bfec-d02b-d6ea-c3edeeae146e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "0d699ee9-bfec-d02b-d6ea-c3edeeae146e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697728674631
            },
            "e-348": {
                id: "e-348",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-38",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-349"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be9c0|ccac70a0-55c0-9348-1762-24548454d772",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be9c0|ccac70a0-55c0-9348-1762-24548454d772",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1697816132199
            },
            "e-406": {
                id: "e-406",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-52",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-407"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".next-project",
                    originalId: "678002b05def6cc3379be99f|4b3be214-6ed9-47a0-8e61-5a12bd4f05eb",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".next-project",
                    originalId: "678002b05def6cc3379be99f|4b3be214-6ed9-47a0-8e61-5a12bd4f05eb",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569887201584
            },
            "e-407": {
                id: "e-407",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-53",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-406"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".next-project",
                    originalId: "678002b05def6cc3379be99f|4b3be214-6ed9-47a0-8e61-5a12bd4f05eb",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".next-project",
                    originalId: "678002b05def6cc3379be99f|4b3be214-6ed9-47a0-8e61-5a12bd4f05eb",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569887201584
            },
            "e-408": {
                id: "e-408",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-54",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1430"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".footer",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".footer",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569549215417
            },
            "e-409": {
                id: "e-409",
                animationType: "custom",
                eventTypeId: "SCROLL_OUT_OF_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-55",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1429"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".footer",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".footer",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569549215417
            },
            "e-412": {
                id: "e-412",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_CLICK",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-56",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-413"
                    }
                },
                mediaQueries: ["medium", "small", "tiny"],
                target: {
                    selector: ".navha-hamburger-button",
                    originalId: "65fadabfdb8e806c6eaaa82b|e4b4c55d-f67a-d4ae-dc26-d77cdbec588c",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".navha-hamburger-button",
                    originalId: "65fadabfdb8e806c6eaaa82b|e4b4c55d-f67a-d4ae-dc26-d77cdbec588c",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1694694313901
            },
            "e-413": {
                id: "e-413",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_SECOND_CLICK",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-57",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-412"
                    }
                },
                mediaQueries: ["medium", "small", "tiny"],
                target: {
                    selector: ".navha-hamburger-button",
                    originalId: "65fadabfdb8e806c6eaaa82b|e4b4c55d-f67a-d4ae-dc26-d77cdbec588c",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".navha-hamburger-button",
                    originalId: "65fadabfdb8e806c6eaaa82b|e4b4c55d-f67a-d4ae-dc26-d77cdbec588c",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1694694313901
            },
            "e-429": {
                id: "e-429",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-58",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-430"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be988|bd4ee877-ef3a-3071-5f72-700b8ee5e582",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be988|bd4ee877-ef3a-3071-5f72-700b8ee5e582",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569887201584
            },
            "e-430": {
                id: "e-430",
                animationType: "custom",
                eventTypeId: "SCROLL_OUT_OF_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-59",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-429"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be988|bd4ee877-ef3a-3071-5f72-700b8ee5e582",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be988|bd4ee877-ef3a-3071-5f72-700b8ee5e582",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569887201584
            },
            "e-641": {
                id: "e-641",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-69",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "bc9ed5d5-4657-8930-532c-fd5aa0800c74",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "bc9ed5d5-4657-8930-532c-fd5aa0800c74",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-69-p",
                    smoothing: 50,
                    startsEntering: !0,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1722628128459
            },
            "e-642": {
                id: "e-642",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-68",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "bc9ed5d5-4657-8930-532c-fd5aa0800c74",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "bc9ed5d5-4657-8930-532c-fd5aa0800c74",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-68-p",
                    smoothing: 50,
                    startsEntering: !0,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1722628128459
            },
            "e-647": {
                id: "e-647",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-76",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-648"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12727",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12727",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1722628128459
            },
            "e-659": {
                id: "e-659",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-660"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "40e063a9-af5d-fc8a-8071-1af5a561954f",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "40e063a9-af5d-fc8a-8071-1af5a561954f",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1722658837615
            },
            "e-726": {
                id: "e-726",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-49",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "ce70fe33-ec3e-c6b0-87f5-80267a5981bf",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "ce70fe33-ec3e-c6b0-87f5-80267a5981bf",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-49-p",
                    smoothing: 94,
                    startsEntering: !1,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1723044344328
            },
            "e-739": {
                id: "e-739",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-76",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-740"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "7e6e92c1-4af6-334e-3119-f78e5b9606b2",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "7e6e92c1-4af6-334e-3119-f78e5b9606b2",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723650201250
            },
            "e-774": {
                id: "e-774",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-775"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12728",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12728",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749864910
            },
            "e-776": {
                id: "e-776",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-31",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-777"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f1272a",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f1272a",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749872250
            },
            "e-778": {
                id: "e-778",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-38",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-779"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f1272c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f1272c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749877324
            },
            "e-780": {
                id: "e-780",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-96",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-781"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f1272e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f1272e",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749883424
            },
            "e-782": {
                id: "e-782",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-783"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12730",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12730",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749908726
            },
            "e-784": {
                id: "e-784",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-31",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-785"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12732",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12732",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749914799
            },
            "e-786": {
                id: "e-786",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-38",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-787"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12734",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12734",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749923733
            },
            "e-788": {
                id: "e-788",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-96",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-789"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12736",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "b42d0bd7-183a-2c4b-eaea-e429e2f12736",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723749930070
            },
            "e-804": {
                id: "e-804",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1404"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".awards-links-container",
                    originalId: "678002b05def6cc3379be9a5|6a7c253b-afa9-1726-ecaf-62df5838a6ea",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".awards-links-container",
                    originalId: "678002b05def6cc3379be9a5|6a7c253b-afa9-1726-ecaf-62df5838a6ea",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723750561211
            },
            "e-966": {
                id: "e-966",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_MOVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-109",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium"],
                target: {
                    selector: ".project__container",
                    originalId: "ab6208ff-4a19-f041-4d97-a6f56bc3b723",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project__container",
                    originalId: "ab6208ff-4a19-f041-4d97-a6f56bc3b723",
                    appliesTo: "CLASS"
                }],
                config: [{
                    continuousParameterGroupId: "a-109-p",
                    selectedAxis: "X_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 80,
                    restingState: 50
                }, {
                    continuousParameterGroupId: "a-109-p-2",
                    selectedAxis: "Y_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 80,
                    restingState: 50
                }],
                createdOn: 1543197824403
            },
            "e-981": {
                id: "e-981",
                name: "",
                animationType: "preset",
                eventTypeId: "MOUSE_MOVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-109",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium"],
                target: {
                    selector: ".project__container",
                    originalId: "678002b05def6cc3379be9aa|5a7b38f7-06dc-0a9b-58c4-cc79a326b7db",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project__container",
                    originalId: "678002b05def6cc3379be9aa|5a7b38f7-06dc-0a9b-58c4-cc79a326b7db",
                    appliesTo: "CLASS"
                }],
                config: [{
                    continuousParameterGroupId: "a-109-p",
                    selectedAxis: "X_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 80,
                    restingState: 50
                }, {
                    continuousParameterGroupId: "a-109-p-2",
                    selectedAxis: "Y_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 80,
                    restingState: 50
                }],
                createdOn: 1648093356690
            },
            "e-1268": {
                id: "e-1268",
                name: "",
                animationType: "custom",
                eventTypeId: "DROPDOWN_OPEN",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-125",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1269"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".nav-link-2.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".nav-link-2.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1694714876682
            },
            "e-1269": {
                id: "e-1269",
                name: "",
                animationType: "custom",
                eventTypeId: "DROPDOWN_CLOSE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-126",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1268"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".nav-link-2.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".nav-link-2.nav-item-dropdown",
                    originalId: "64fa21e164025f5e66000030|1fd6be2f-247d-af11-af97-dbc64b706ecd",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1694714876682
            },
            "e-1270": {
                id: "e-1270",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-128",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1271"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".templates_wrapper.templates_wrapper--3",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".templates_wrapper.templates_wrapper--3",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724883785653
            },
            "e-1271": {
                id: "e-1271",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-129",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1270"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".templates_wrapper.templates_wrapper--3",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".templates_wrapper.templates_wrapper--3",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724883785655
            },
            "e-1272": {
                id: "e-1272",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-128",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1273"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".templates_wrapper",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".templates_wrapper",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724884215761
            },
            "e-1273": {
                id: "e-1273",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-129",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1272"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".templates_wrapper",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".templates_wrapper",
                    originalId: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724884215762
            },
            "e-1276": {
                id: "e-1276",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-132",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1277"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".line",
                    originalId: "ebd6ca7e-3c25-d850-fa66-03c87a25add9",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".line",
                    originalId: "ebd6ca7e-3c25-d850-fa66-03c87a25add9",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724902780553
            },
            "e-1278": {
                id: "e-1278",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1279"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|75f9df8d-d740-4e46-a85f-e7fcf887d6c5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|75f9df8d-d740-4e46-a85f-e7fcf887d6c5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1280": {
                id: "e-1280",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1281"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|d7fc3e03-6dcc-0f85-d855-59ad6933d8aa",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|d7fc3e03-6dcc-0f85-d855-59ad6933d8aa",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1282": {
                id: "e-1282",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1283"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|0eed6af7-e400-935e-6e8e-968a9b9df5a5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|0eed6af7-e400-935e-6e8e-968a9b9df5a5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1284": {
                id: "e-1284",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1285"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|93776c11-a02e-5f25-0543-b14540c2f041",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|93776c11-a02e-5f25-0543-b14540c2f041",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1286": {
                id: "e-1286",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1287"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|f5ad4dca-13ae-cf70-40db-0f314f0816a6",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|f5ad4dca-13ae-cf70-40db-0f314f0816a6",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1288": {
                id: "e-1288",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-49",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|51eb88db-786d-09b0-1b82-cc48d89a17bf",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|51eb88db-786d-09b0-1b82-cc48d89a17bf",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-49-p",
                    smoothing: 94,
                    startsEntering: !1,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1724944418140
            },
            "e-1289": {
                id: "e-1289",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-49",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|18017e57-c402-7ce9-41f0-3495df10ec2d",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|18017e57-c402-7ce9-41f0-3495df10ec2d",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-49-p",
                    smoothing: 94,
                    startsEntering: !1,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1724944418140
            },
            "e-1291": {
                id: "e-1291",
                name: "",
                animationType: "preset",
                eventTypeId: "PAGE_START",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-93",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1292"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1296": {
                id: "e-1296",
                name: "",
                animationType: "preset",
                eventTypeId: "PAGE_START",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-103",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1297"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1316": {
                id: "e-1316",
                name: "",
                animationType: "preset",
                eventTypeId: "PAGE_SCROLL_UP",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-145",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1317"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1317": {
                id: "e-1317",
                name: "",
                animationType: "preset",
                eventTypeId: "PAGE_SCROLL_DOWN",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-146",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1316"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1724944418140
            },
            "e-1359": {
                id: "e-1359",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1360"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "28321352-92e1-d95e-9827-4e946bbdf6c7",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "28321352-92e1-d95e-9827-4e946bbdf6c7",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1725054496916
            },
            "e-1369": {
                id: "e-1369",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-141",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1370"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".nav_link-wrapper",
                    originalId: "3a236f56-b861-117b-a422-c26807786427",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".nav_link-wrapper",
                    originalId: "3a236f56-b861-117b-a422-c26807786427",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1725988529912
            },
            "e-1370": {
                id: "e-1370",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-142",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1369"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".nav_link-wrapper",
                    originalId: "3a236f56-b861-117b-a422-c26807786427",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".nav_link-wrapper",
                    originalId: "3a236f56-b861-117b-a422-c26807786427",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1725988529913
            },
            "e-1371": {
                id: "e-1371",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1372"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|75f9df8d-d740-4e46-a85f-e7fcf887d6c5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|75f9df8d-d740-4e46-a85f-e7fcf887d6c5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1373": {
                id: "e-1373",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1374"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|d7fc3e03-6dcc-0f85-d855-59ad6933d8aa",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|d7fc3e03-6dcc-0f85-d855-59ad6933d8aa",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1375": {
                id: "e-1375",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1376"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|0eed6af7-e400-935e-6e8e-968a9b9df5a5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|0eed6af7-e400-935e-6e8e-968a9b9df5a5",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1377": {
                id: "e-1377",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1378"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|93776c11-a02e-5f25-0543-b14540c2f041",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|93776c11-a02e-5f25-0543-b14540c2f041",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1379": {
                id: "e-1379",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1380"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|f5ad4dca-13ae-cf70-40db-0f314f0816a6",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|f5ad4dca-13ae-cf70-40db-0f314f0816a6",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1381": {
                id: "e-1381",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-49",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|51eb88db-786d-09b0-1b82-cc48d89a17bf",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|51eb88db-786d-09b0-1b82-cc48d89a17bf",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-49-p",
                    smoothing: 94,
                    startsEntering: !1,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1728268009872
            },
            "e-1382": {
                id: "e-1382",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLLING_IN_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-49",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|18017e57-c402-7ce9-41f0-3495df10ec2d",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|18017e57-c402-7ce9-41f0-3495df10ec2d",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-49-p",
                    smoothing: 94,
                    startsEntering: !1,
                    addStartOffset: !1,
                    addOffsetValue: 50,
                    startsExiting: !1,
                    addEndOffset: !1,
                    endOffsetValue: 50
                }],
                createdOn: 1728268009872
            },
            "e-1383": {
                id: "e-1383",
                name: "",
                animationType: "preset",
                eventTypeId: "MOUSE_MOVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-85",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|206cfd6a-49fd-5ed6-2e3d-dad029470d4c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|206cfd6a-49fd-5ed6-2e3d-dad029470d4c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-85-p",
                    selectedAxis: "X_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 90,
                    restingState: 50
                }, {
                    continuousParameterGroupId: "a-85-p-2",
                    selectedAxis: "Y_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 90,
                    restingState: 50
                }],
                createdOn: 1728268009872
            },
            "e-1388": {
                id: "e-1388",
                name: "",
                animationType: "preset",
                eventTypeId: "MOUSE_MOVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_CONTINUOUS_ACTION",
                    config: {
                        actionListId: "a-100",
                        affectedElements: {},
                        duration: 0
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be92e|f4b03645-252d-bc76-35f7-ac9c9e101da4",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|f4b03645-252d-bc76-35f7-ac9c9e101da4",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: [{
                    continuousParameterGroupId: "a-100-p",
                    selectedAxis: "X_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 96,
                    restingState: 50
                }, {
                    continuousParameterGroupId: "a-100-p-2",
                    selectedAxis: "Y_AXIS",
                    basedOn: "ELEMENT",
                    reverse: !1,
                    smoothing: 96,
                    restingState: 50
                }],
                createdOn: 1728268009872
            },
            "e-1395": {
                id: "e-1395",
                name: "",
                animationType: "preset",
                eventTypeId: "PAGE_SCROLL_UP",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-145",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1396"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be92e",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1396": {
                id: "e-1396",
                name: "",
                animationType: "preset",
                eventTypeId: "PAGE_SCROLL_DOWN",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-146",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1395"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be92e",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728268009872
            },
            "e-1403": {
                id: "e-1403",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1404"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".awards-links-wrapper",
                    originalId: "67034576bb1e4479a4c8b515|6a7c253b-afa9-1726-ecaf-62df5838a6ea",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".awards-links-wrapper",
                    originalId: "67034576bb1e4479a4c8b515|6a7c253b-afa9-1726-ecaf-62df5838a6ea",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1723750561211
            },
            "e-1405": {
                id: "e-1405",
                name: "",
                animationType: "custom",
                eventTypeId: "SLIDER_ACTIVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-147",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1406"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1608421213051
            },
            "e-1406": {
                id: "e-1406",
                name: "",
                animationType: "custom",
                eventTypeId: "SLIDER_INACTIVE",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-148",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1405"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".quote-slide",
                    originalId: "5fde8ec630b6112c71224f07|cfe13405-9ff7-686f-6582-e7dd656a30ec",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1608421213070
            },
            "e-1421": {
                id: "e-1421",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-31",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1422"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "09ff0c29-bc9e-9a51-1d53-9758abf334ff",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "09ff0c29-bc9e-9a51-1d53-9758abf334ff",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728270637452
            },
            "e-1425": {
                id: "e-1425",
                name: "",
                animationType: "custom",
                eventTypeId: "PAGE_START",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-149",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1426"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !0,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728314107567
            },
            "e-1427": {
                id: "e-1427",
                name: "",
                animationType: "preset",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-76",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1428"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be989|abd84362-5036-ea32-9d5b-86289504d94c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be989|abd84362-5036-ea32-9d5b-86289504d94c",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728315159876
            },
            "e-1429": {
                id: "e-1429",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-54",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1430"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".footer-alt",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".footer-alt",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569549215417
            },
            "e-1430": {
                id: "e-1430",
                animationType: "custom",
                eventTypeId: "SCROLL_OUT_OF_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-55",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1429"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    selector: ".footer-alt",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".footer-alt",
                    originalId: "5d990ac9574a7d61df204401|b7a966d8-cf39-d520-f55e-62e1c2cf0b3f",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1569549215417
            },
            "e-1433": {
                id: "e-1433",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-40",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1434"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".card.services",
                    originalId: "678002b05def6cc3379be92e|d9e078a3-4e43-6ea7-1d37-ee983a0fe32b",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".card.services",
                    originalId: "678002b05def6cc3379be92e|d9e078a3-4e43-6ea7-1d37-ee983a0fe32b",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728326382728
            },
            "e-1435": {
                id: "e-1435",
                name: "",
                animationType: "custom",
                eventTypeId: "SCROLL_INTO_VIEW",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-18",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1436"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    id: "678002b05def6cc3379be92e|206cfd6a-49fd-5ed6-2e3d-dad029470d44",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be92e|206cfd6a-49fd-5ed6-2e3d-dad029470d44",
                    appliesTo: "ELEMENT",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728326496156
            },
            "e-1439": {
                id: "e-1439",
                name: "",
                animationType: "custom",
                eventTypeId: "PAGE_SCROLL_UP",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-145",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1440"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be99d",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be99d",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728326580177
            },
            "e-1440": {
                id: "e-1440",
                name: "",
                animationType: "custom",
                eventTypeId: "PAGE_SCROLL_DOWN",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-146",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1439"
                    }
                },
                mediaQueries: ["main"],
                target: {
                    id: "678002b05def6cc3379be99d",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                },
                targets: [{
                    id: "678002b05def6cc3379be99d",
                    appliesTo: "PAGE",
                    styleBlockIds: []
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: 0,
                    scrollOffsetUnit: "%",
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728326580178
            },
            "e-1441": {
                id: "e-1441",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OVER",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-150",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1442"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".project-link-wrapper",
                    originalId: "678002b05def6cc3379be92e|e3b997b0-db7d-742f-bd6e-26281dcb2ea6",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-link-wrapper",
                    originalId: "678002b05def6cc3379be92e|e3b997b0-db7d-742f-bd6e-26281dcb2ea6",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728359090464
            },
            "e-1442": {
                id: "e-1442",
                name: "",
                animationType: "custom",
                eventTypeId: "MOUSE_OUT",
                action: {
                    id: "",
                    actionTypeId: "GENERAL_START_ACTION",
                    config: {
                        delay: 0,
                        easing: "",
                        duration: 0,
                        actionListId: "a-151",
                        affectedElements: {},
                        playInReverse: !1,
                        autoStopEventId: "e-1441"
                    }
                },
                mediaQueries: ["main", "medium", "small", "tiny"],
                target: {
                    selector: ".project-link-wrapper",
                    originalId: "678002b05def6cc3379be92e|e3b997b0-db7d-742f-bd6e-26281dcb2ea6",
                    appliesTo: "CLASS"
                },
                targets: [{
                    selector: ".project-link-wrapper",
                    originalId: "678002b05def6cc3379be92e|e3b997b0-db7d-742f-bd6e-26281dcb2ea6",
                    appliesTo: "CLASS"
                }],
                config: {
                    loop: !1,
                    playInReverse: !1,
                    scrollOffsetValue: null,
                    scrollOffsetUnit: null,
                    delay: null,
                    direction: null,
                    effectIn: null
                },
                createdOn: 1728359090465
            }
        },
        actionLists: {
            "a-15": {
                id: "a-15",
                title: "Showcase Link Hover In",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-15-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-15-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1612163625430
            },
            "a-13": {
                id: "a-13",
                title: "Showcase Link Hover Out",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-13-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1612163625430
            },
            "a-12": {
                id: "a-12",
                title: "Project 2 Hover",
                continuousParameterGroups: [{
                    id: "a-12-p",
                    type: "MOUSE_X",
                    parameterLabel: "Mouse X",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-12-n",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                yValue: -12,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-12-n-2",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                yValue: 12,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }]
                }, {
                    id: "a-12-p-2",
                    type: "MOUSE_Y",
                    parameterLabel: "Mouse Y",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-12-n-3",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 6,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-12-n-4",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: -6,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }]
                }],
                createdOn: 1543181021553
            },
            "a-17": {
                id: "a-17",
                title: "Nav homepage white animation",
                continuousParameterGroups: [{
                    id: "a-17-p",
                    type: "SCROLL_PROGRESS",
                    parameterLabel: "Scroll",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-17-n",
                            actionTypeId: "STYLE_TEXT_COLOR",
                            config: {
                                delay: 0,
                                easing: "ease",
                                duration: 500,
                                target: {},
                                globalSwatchId: "",
                                rValue: 255,
                                bValue: 255,
                                gValue: 255,
                                aValue: 1
                            }
                        }, {
                            id: "a-17-n-2",
                            actionTypeId: "STYLE_FILTER",
                            config: {
                                delay: 0,
                                easing: "ease",
                                duration: 500,
                                target: {},
                                filters: [{
                                    type: "invert",
                                    filterId: "4e54",
                                    value: 0,
                                    unit: "%"
                                }]
                            }
                        }, {
                            id: "a-17-n-3",
                            actionTypeId: "STYLE_BACKGROUND_COLOR",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                globalSwatchId: "",
                                rValue: 255,
                                bValue: 255,
                                gValue: 255,
                                aValue: 0
                            }
                        }]
                    }, {
                        keyframe: 95,
                        actionItems: [{
                            id: "a-17-n-4",
                            actionTypeId: "STYLE_TEXT_COLOR",
                            config: {
                                delay: 0,
                                easing: "ease",
                                duration: 500,
                                target: {},
                                globalSwatchId: "",
                                rValue: 255,
                                bValue: 255,
                                gValue: 255,
                                aValue: 1
                            }
                        }, {
                            id: "a-17-n-5",
                            actionTypeId: "STYLE_FILTER",
                            config: {
                                delay: 0,
                                easing: "ease",
                                duration: 500,
                                target: {},
                                filters: [{
                                    type: "invert",
                                    filterId: "4e54",
                                    value: 0,
                                    unit: "%"
                                }]
                            }
                        }, {
                            id: "a-17-n-6",
                            actionTypeId: "STYLE_BACKGROUND_COLOR",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                globalSwatchId: "",
                                rValue: 255,
                                bValue: 255,
                                gValue: 255,
                                aValue: 0
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-17-n-7",
                            actionTypeId: "STYLE_TEXT_COLOR",
                            config: {
                                delay: 0,
                                easing: "ease",
                                duration: 500,
                                target: {},
                                globalSwatchId: "",
                                rValue: 51,
                                bValue: 51,
                                gValue: 51,
                                aValue: 1
                            }
                        }, {
                            id: "a-17-n-8",
                            actionTypeId: "STYLE_FILTER",
                            config: {
                                delay: 0,
                                easing: "ease",
                                duration: 500,
                                target: {},
                                filters: [{
                                    type: "invert",
                                    filterId: "4e54",
                                    value: 78,
                                    unit: "%"
                                }]
                            }
                        }, {
                            id: "a-17-n-9",
                            actionTypeId: "STYLE_BACKGROUND_COLOR",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                globalSwatchId: "",
                                rValue: 255,
                                bValue: 255,
                                gValue: 255,
                                aValue: 1
                            }
                        }]
                    }]
                }],
                createdOn: 1628479612521
            },
            "a-25": {
                id: "a-25",
                title: "Project Button In",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-25-n",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            widthValue: 76,
                            widthUnit: "PX",
                            heightUnit: "PX",
                            locked: !1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1579915040290
            },
            "a-26": {
                id: "a-26",
                title: "Project Button Out",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-26-n",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            widthValue: 56,
                            widthUnit: "PX",
                            heightUnit: "PX",
                            locked: !1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1579915040290
            },
            "a-27": {
                id: "a-27",
                title: "Project 1 Rotate",
                continuousParameterGroups: [{
                    id: "a-27-p",
                    type: "SCROLL_PROGRESS",
                    parameterLabel: "Scroll",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-27-n",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: !0,
                                    id: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288"
                                },
                                zValue: 35,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }, {
                            id: "a-27-n-2",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: !0,
                                    id: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288"
                                },
                                xValue: -20,
                                yValue: null,
                                xUnit: "vw",
                                yUnit: "vw",
                                zUnit: "PX"
                            }
                        }]
                    }, {
                        keyframe: 50,
                        actionItems: [{
                            id: "a-27-n-6",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: !0,
                                    id: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288"
                                },
                                xValue: -12,
                                yValue: null,
                                xUnit: "vw",
                                yUnit: "vw",
                                zUnit: "PX"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-27-n-8",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: !0,
                                    id: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288"
                                },
                                zValue: -35,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }, {
                            id: "a-27-n-9",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: !0,
                                    id: "678002b05def6cc3379be9dc|77bace88-8bd1-763a-2937-4077c44c7288"
                                },
                                xValue: -20,
                                yValue: null,
                                xUnit: "vw",
                                yUnit: "vw",
                                zUnit: "PX"
                            }
                        }]
                    }]
                }],
                createdOn: 1579801964381
            },
            "a-18": {
                id: "a-18",
                title: "Fade in 1",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-18-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 40,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-18-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-18-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-18-n-4",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1575307041672
            },
            "a-31": {
                id: "a-31",
                title: "Fade in 2",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-31-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 40,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-31-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-31-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 200,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-31-n-4",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 200,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1575307041672
            },
            "a-33": {
                id: "a-33",
                title: "Quote Slider In View",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-33-n",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {},
                            xValue: 1,
                            yValue: 1,
                            locked: !0
                        }
                    }, {
                        id: "a-33-n-3",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1608421228415
            },
            "a-34": {
                id: "a-34",
                title: "Quote Slider Out View",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-34-n",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {},
                            xValue: .9,
                            yValue: .9,
                            locked: !0
                        }
                    }, {
                        id: "a-34-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1608421228415
            },
            "a-40": {
                id: "a-40",
                title: "Skill Card",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-40-n-3",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|12002675-1110-c77f-de93-9c9fa8ead540"
                            },
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-40-n-5",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|12002675-1110-c77f-de93-9c9fa8ead540"
                            },
                            xValue: .9,
                            yValue: .9,
                            locked: !0
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-40-n-4",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 100,
                            easing: "outCubic",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|12002675-1110-c77f-de93-9c9fa8ead540"
                            },
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-40-n-6",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 100,
                            easing: "outCubic",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|12002675-1110-c77f-de93-9c9fa8ead540"
                            },
                            xValue: 1,
                            yValue: 1,
                            locked: !0
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1697670005452
            },
            "a-41": {
                id: "a-41",
                title: "Nav Arrow Spin Open",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-41-n",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            zValue: -180,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1694714880340
            },
            "a-42": {
                id: "a-42",
                title: "Nav Arrow Spin Close",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-42-n",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            zValue: 0,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1694714880340
            },
            "a-43": {
                id: "a-43",
                title: "Navbar menu [Open]",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-43-n",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 200,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-middle",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c1e"]
                            },
                            widthValue: 0,
                            widthUnit: "px",
                            heightUnit: "PX",
                            locked: !1
                        }
                    }, {
                        id: "a-43-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 400,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-bottom",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c24"]
                            },
                            yValue: -8,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-43-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 400,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-top",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c1f"]
                            },
                            yValue: 8,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-43-n-4",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 600,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-top",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c1f"]
                            },
                            zValue: -45,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }, {
                        id: "a-43-n-6",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 600,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-bottom",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c24"]
                            },
                            zValue: 45,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1626168378054
            },
            "a-44": {
                id: "a-44",
                title: "Navbar menu [Close]",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-44-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 600,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-bottom",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c24"]
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-44-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 600,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-top",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c1f"]
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-44-n-3",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 400,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-bottom",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c24"]
                            },
                            zValue: 0,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }, {
                        id: "a-44-n-4",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "inOutQuint",
                            duration: 400,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-top",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c1f"]
                            },
                            zValue: 0,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }, {
                        id: "a-44-n-6",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 400,
                            easing: "inOutQuint",
                            duration: 200,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".menu-icon-line-middle",
                                selectorGuids: ["6c752efc-c0bd-07a1-bee3-1b8f06655c1e"]
                            },
                            widthValue: 24,
                            widthUnit: "px",
                            heightUnit: "PX",
                            locked: !1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1626168766736
            },
            "a-38": {
                id: "a-38",
                title: "Fade in 3",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-38-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 40,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-38-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-38-n-4",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 400,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-38-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 400,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1575307041672
            },
            "a-52": {
                id: "a-52",
                title: "Next Project Line In",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-52-n",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".next-project-line.line-inside",
                                selectorGuids: ["330bcca4-a3e6-581e-7999-aa3c8962acb5", "330bcca4-a3e6-581e-7999-aa3c8962acb7"]
                            },
                            heightValue: 0,
                            widthUnit: "PX",
                            heightUnit: "%",
                            locked: !1
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-52-n-2",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".next-project-line.line-inside",
                                selectorGuids: ["330bcca4-a3e6-581e-7999-aa3c8962acb5", "330bcca4-a3e6-581e-7999-aa3c8962acb7"]
                            },
                            heightValue: 100,
                            widthUnit: "PX",
                            heightUnit: "%",
                            locked: !1
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-52-n-3",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "bouncePast",
                            duration: 300,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".next-project-title",
                                selectorGuids: ["330bcca4-a3e6-581e-7999-aa3c8962acb6"]
                            },
                            xValue: 1.1,
                            yValue: 1.1,
                            locked: !0
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-52-n-4",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "bouncePast",
                            duration: 300,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".next-project-title",
                                selectorGuids: ["330bcca4-a3e6-581e-7999-aa3c8962acb6"]
                            },
                            xValue: 1,
                            yValue: 1,
                            locked: !0
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1569548626333
            },
            "a-53": {
                id: "a-53",
                title: "Next Project Line Out",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-53-n",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".next-project-line.line-inside",
                                selectorGuids: ["330bcca4-a3e6-581e-7999-aa3c8962acb5", "330bcca4-a3e6-581e-7999-aa3c8962acb7"]
                            },
                            heightValue: 0,
                            widthUnit: "PX",
                            heightUnit: "%",
                            locked: !1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1569548626333
            },
            "a-54": {
                id: "a-54",
                title: "Nav Out",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-54-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {},
                            yValue: -100,
                            xUnit: "PX",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1569549218976
            },
            "a-55": {
                id: "a-55",
                title: "Nav In",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-55-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {},
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1569549218976
            },
            "a-56": {
                id: "a-56",
                title: "Nav Button First Click",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-56-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-56-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1513580504824
            },
            "a-57": {
                id: "a-57",
                title: "Nav Button Second Click",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-57-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-57-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1513580504824
            },
            "a-58": {
                id: "a-58",
                title: "nav links",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-58-n",
                        actionTypeId: "STYLE_TEXT_COLOR",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 0,
                            target: {},
                            globalSwatchId: "",
                            rValue: 255,
                            bValue: 255,
                            gValue: 255,
                            aValue: 1
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-58-n-2",
                        actionTypeId: "STYLE_TEXT_COLOR",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 0,
                            target: {},
                            globalSwatchId: "",
                            rValue: 255,
                            bValue: 255,
                            gValue: 255,
                            aValue: 1
                        }
                    }, {
                        id: "a-58-n-3",
                        actionTypeId: "STYLE_BACKGROUND_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 200,
                            target: {},
                            globalSwatchId: "9eb384dc",
                            rValue: 255,
                            bValue: 255,
                            gValue: 255,
                            aValue: 1
                        }
                    }, {
                        id: "a-58-n-4",
                        actionTypeId: "STYLE_BACKGROUND_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 200,
                            target: {},
                            globalSwatchId: "9eb384dc",
                            rValue: 255,
                            bValue: 255,
                            gValue: 255,
                            aValue: 1
                        }
                    }, {
                        id: "a-58-n-5",
                        actionTypeId: "STYLE_BACKGROUND_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 200,
                            target: {},
                            globalSwatchId: "9eb384dc",
                            rValue: 255,
                            bValue: 255,
                            gValue: 255,
                            aValue: 1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1569549839899
            },
            "a-59": {
                id: "a-59",
                title: "nav links out",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-59-n",
                        actionTypeId: "STYLE_TEXT_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 0,
                            target: {},
                            globalSwatchId: "",
                            rValue: 0,
                            bValue: 0,
                            gValue: 0,
                            aValue: .8
                        }
                    }, {
                        id: "a-59-n-2",
                        actionTypeId: "STYLE_BACKGROUND_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 200,
                            target: {},
                            globalSwatchId: "9f5b84b7",
                            rValue: 0,
                            bValue: 0,
                            gValue: 0,
                            aValue: 1
                        }
                    }, {
                        id: "a-59-n-3",
                        actionTypeId: "STYLE_BACKGROUND_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 200,
                            target: {},
                            globalSwatchId: "9f5b84b7",
                            rValue: 0,
                            bValue: 0,
                            gValue: 0,
                            aValue: 1
                        }
                    }, {
                        id: "a-59-n-4",
                        actionTypeId: "STYLE_BACKGROUND_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 200,
                            target: {},
                            globalSwatchId: "9f5b84b7",
                            rValue: 0,
                            bValue: 0,
                            gValue: 0,
                            aValue: 1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1569549839899
            },
            "a-69": {
                id: "a-69",
                title: "Process slider",
                continuousParameterGroups: [{
                    id: "a-69-p",
                    type: "SCROLL_PROGRESS",
                    parameterLabel: "Scroll",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-69-n",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 35,
                        actionItems: [{
                            id: "a-69-n-2",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 0,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }]
                    }, {
                        keyframe: 43,
                        actionItems: [{
                            id: "a-69-n-3",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-4",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 0,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-5",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 100,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }, {
                            id: "a-69-n-6",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-7",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-8",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .35,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-9",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .1,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 45,
                        actionItems: [{
                            id: "a-69-n-10",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 0,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-11",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-12",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 0,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }, {
                            id: "a-69-n-13",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-14",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-15",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-16",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .35,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 53,
                        actionItems: [{
                            id: "a-69-n-17",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-18",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 0,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-19",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 100,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }, {
                            id: "a-69-n-20",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-21",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-22",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-23",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .35,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 55,
                        actionItems: [{
                            id: "a-69-n-24",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 0,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-25",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-26",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 0,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }, {
                            id: "a-69-n-27",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .35,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-28",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-29",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-30",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 63,
                        actionItems: [{
                            id: "a-69-n-31",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-32",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 0,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-33",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 100,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }, {
                            id: "a-69-n-34",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .35,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-35",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-36",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-37",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 65,
                        actionItems: [{
                            id: "a-69-n-38",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 0,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-39",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-40",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 0,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }, {
                            id: "a-69-n-41",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .1,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-42",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .35,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-43",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }, {
                            id: "a-69-n-44",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 73,
                        actionItems: [{
                            id: "a-69-n-45",
                            actionTypeId: "STYLE_SIZE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                widthValue: 100,
                                widthUnit: "%",
                                heightUnit: "PX",
                                locked: !1
                            }
                        }]
                    }]
                }],
                createdOn: 1673619465022
            },
            "a-68": {
                id: "a-68",
                title: "Move nav 1",
                continuousParameterGroups: [{
                    id: "a-68-p",
                    type: "SCROLL_PROGRESS",
                    parameterLabel: "Scroll",
                    continuousActionGroups: [{
                        keyframe: 25,
                        actionItems: [{
                            id: "a-68-n",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                yValue: 0,
                                xUnit: "PX",
                                yUnit: "em",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-68-n-2",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: 1,
                                unit: ""
                            }
                        }]
                    }, {
                        keyframe: 28,
                        actionItems: [{
                            id: "a-68-n-3",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                yValue: -1.5,
                                xUnit: "PX",
                                yUnit: "em",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-68-n-4",
                            actionTypeId: "STYLE_OPACITY",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: .6,
                                unit: ""
                            }
                        }]
                    }]
                }],
                createdOn: 1673378068171
            },
            "a-76": {
                id: "a-76",
                title: "(Global) Slide In  from Bottom 1",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-76-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 1.5,
                            xUnit: "PX",
                            yUnit: "rem",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-76-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-76-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "rem",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-76-n-4",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "5df968491a855afc4d71c715|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1575307041672
            },
            "a-49": {
                id: "a-49",
                title: "Hero  3 Heading Text Shift",
                continuousParameterGroups: [{
                    id: "a-49-p",
                    type: "SCROLL_PROGRESS",
                    parameterLabel: "Scroll",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-49-n",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 0,
                                xUnit: "vw",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-49-n-2",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 0,
                                xUnit: "vw",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-49-n-5",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-description",
                                    selectorGuids: ["8b929be9-0a97-987c-ba02-84a8d4d65ae3"]
                                },
                                xValue: 0,
                                xUnit: "vw",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-49-n-3",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: -15,
                                xUnit: "vw",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-49-n-4",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 15,
                                xUnit: "vw",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-49-n-6",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-description",
                                    selectorGuids: ["8b929be9-0a97-987c-ba02-84a8d4d65ae3"]
                                },
                                xValue: -7.5,
                                xUnit: "vw",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }]
                    }]
                }],
                createdOn: 1696980435646
            },
            "a-96": {
                id: "a-96",
                title: "Fade in 4",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-96-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 40,
                            xUnit: "PX",
                            yUnit: "px",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-96-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-96-n-3",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 600,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-96-n-4",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 600,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be9c2|032d3360-4382-55b6-a075-f4c86c95b7b2"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1575307041672
            },
            "a-109": {
                id: "a-109",
                title: "project-hover",
                continuousParameterGroups: [{
                    id: "a-109-p",
                    type: "MOUSE_X",
                    parameterLabel: "Mouse X",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-109-n",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                yValue: -12,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-109-n-2",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                yValue: 12,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }]
                }, {
                    id: "a-109-p-2",
                    type: "MOUSE_Y",
                    parameterLabel: "Mouse Y",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-109-n-3",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 6,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-109-n-4",
                            actionTypeId: "TRANSFORM_ROTATE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: -6,
                                xUnit: "DEG",
                                yUnit: "DEG",
                                zUnit: "DEG"
                            }
                        }]
                    }]
                }],
                createdOn: 1543181021553
            },
            "a-125": {
                id: "a-125",
                title: "Nav Arrow Spin Open 2",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-125-n",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            zValue: -180,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1694714880340
            },
            "a-126": {
                id: "a-126",
                title: "Nav Arrow Spin Close 2",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-126-n",
                        actionTypeId: "TRANSFORM_ROTATE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            zValue: 0,
                            xUnit: "DEG",
                            yUnit: "DEG",
                            zUnit: "deg"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1694714880340
            },
            "a-128": {
                id: "a-128",
                title: "Template Hover on",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-128-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "SIBLINGS",
                                selector: ".templates_wrapper",
                                selectorGuids: ["16a6c1f2-4e74-fcb6-875e-72d7f506034e"]
                            },
                            value: .33,
                            unit: ""
                        }
                    }, {
                        id: "a-128-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be99e|9e65bb1a-bc8d-049d-41e2-5133b0b6447c"
                            },
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1724883802479
            },
            "a-129": {
                id: "a-129",
                title: "Template Hover off",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-129-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "SIBLINGS",
                                selector: ".templates_wrapper",
                                selectorGuids: ["16a6c1f2-4e74-fcb6-875e-72d7f506034e"]
                            },
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1724883802479
            },
            "a-132": {
                id: "a-132",
                title: "Line load",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-132-n",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "ebd6ca7e-3c25-d850-fa66-03c87a25add9"
                            },
                            xValue: 0,
                            locked: !1
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-132-n-2",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 100,
                            easing: "outQuad",
                            duration: 400,
                            target: {
                                useEventTarget: !0,
                                id: "ebd6ca7e-3c25-d850-fa66-03c87a25add9"
                            },
                            xValue: 1,
                            locked: !1
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1724902789411
            },
            "a-93": {
                id: "a-93",
                title: "Homepage Hero Load",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-93-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {},
                            yValue: 5,
                            xUnit: "PX",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {},
                            yValue: 5,
                            xUnit: "PX",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-7",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-93-n-8",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 500,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-93-n-11",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 800,
                            target: {
                                selector: ".hero-description",
                                selectorGuids: ["8b929be9-0a97-987c-ba02-84a8d4d65ae3"]
                            },
                            xValue: 3,
                            yValue: 2,
                            xUnit: "vw",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-12",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 800,
                            target: {
                                selector: ".hero-description",
                                selectorGuids: ["8b929be9-0a97-987c-ba02-84a8d4d65ae3"]
                            },
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-93-n-15",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 800,
                            target: {},
                            xValue: null,
                            yValue: 1,
                            xUnit: "vw",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-16",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 800,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-93-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 2e3,
                            easing: "outQuad",
                            duration: 600,
                            target: {},
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-5",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 2e3,
                            easing: "outQuad",
                            duration: 600,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-93-n-9",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 2200,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                selector: ".hero-description",
                                selectorGuids: ["8b929be9-0a97-987c-ba02-84a8d4d65ae3"]
                            },
                            xValue: 0,
                            yValue: 0,
                            xUnit: "vw",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-10",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 2200,
                            easing: "outQuad",
                            duration: 600,
                            target: {
                                selector: ".hero-description",
                                selectorGuids: ["8b929be9-0a97-987c-ba02-84a8d4d65ae3"]
                            },
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-93-n-4",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 2400,
                            easing: "outQuad",
                            duration: 600,
                            target: {},
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-6",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 2400,
                            easing: "outQuad",
                            duration: 600,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }, {
                        id: "a-93-n-13",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 2600,
                            easing: "outQuad",
                            duration: 400,
                            target: {},
                            xValue: null,
                            yValue: 0,
                            xUnit: "vw",
                            yUnit: "vw",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-93-n-14",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 2600,
                            easing: "outQuad",
                            duration: 400,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1723738152530
            },
            "a-103": {
                id: "a-103",
                title: "Homepage Loader",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-103-n",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "inOutSine",
                            duration: 500,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-103-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "inOutSine",
                            duration: 500,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-103-n-3",
                        actionTypeId: "GENERAL_DISPLAY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 0,
                            target: {},
                            value: "flex"
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-103-n-4",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-103-n-5",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 300,
                            target: {},
                            value: 1,
                            unit: ""
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-103-n-6",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 200,
                            easing: "inSine",
                            duration: 200,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-103-n-7",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 200,
                            easing: "inSine",
                            duration: 200,
                            target: {},
                            yValue: -2,
                            xUnit: "PX",
                            yUnit: "em",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-103-n-8",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 200,
                            easing: "inSine",
                            duration: 200,
                            target: {},
                            value: 0,
                            unit: ""
                        }
                    }, {
                        id: "a-103-n-9",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 200,
                            easing: "inSine",
                            duration: 200,
                            target: {},
                            yValue: -2,
                            xUnit: "PX",
                            yUnit: "em",
                            zUnit: "PX"
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-103-n-10",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 0,
                            easing: "outQuart",
                            duration: 1e3,
                            target: {},
                            heightValue: 0,
                            widthUnit: "px",
                            heightUnit: "%",
                            locked: !1
                        }
                    }, {
                        id: "a-103-n-11",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 100,
                            easing: "outQuart",
                            duration: 900,
                            target: {},
                            heightValue: 0,
                            widthUnit: "px",
                            heightUnit: "%",
                            locked: !1
                        }
                    }, {
                        id: "a-103-n-12",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 200,
                            easing: "outQuart",
                            duration: 800,
                            target: {},
                            heightValue: 0,
                            widthUnit: "px",
                            heightUnit: "%",
                            locked: !1
                        }
                    }, {
                        id: "a-103-n-13",
                        actionTypeId: "STYLE_SIZE",
                        config: {
                            delay: 200,
                            easing: "outQuart",
                            duration: 900,
                            target: {},
                            heightValue: 0,
                            widthUnit: "px",
                            heightUnit: "%",
                            locked: !1
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-103-n-14",
                        actionTypeId: "GENERAL_DISPLAY",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 0,
                            target: {},
                            value: "none"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1665995358766
            },
            "a-145": {
                id: "a-145",
                title: "Nav Show",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-145-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                id: "678002b05def6cc3379be92e|0d699ee9-bfec-d02b-d6ea-c3edeeae146e"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1724701459539
            },
            "a-146": {
                id: "a-146",
                title: "Nav Hide",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-146-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                id: "678002b05def6cc3379be92e|0d699ee9-bfec-d02b-d6ea-c3edeeae146e"
                            },
                            yValue: -100,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1724701459539
            },
            "a-141": {
                id: "a-141",
                title: "Nav Link Hover on",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-141-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 400,
                            target: {},
                            yValue: 100,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-141-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 300,
                            target: {},
                            yValue: -100,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-141-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 300,
                            target: {},
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !0,
                createdOn: 1725988539953
            },
            "a-142": {
                id: "a-142",
                title: "Nav Link Hover off",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-142-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 300,
                            target: {},
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }, {
                        id: "a-142-n-3",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "outQuad",
                            duration: 300,
                            target: {},
                            yValue: 100,
                            xUnit: "PX",
                            yUnit: "%",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1725988539953
            },
            "a-85": {
                id: "a-85",
                title: "Circle Button",
                continuousParameterGroups: [{
                    id: "a-85-p",
                    type: "MOUSE_X",
                    parameterLabel: "Mouse X",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-85-n",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: -6,
                                yValue: null,
                                xUnit: "rem",
                                yUnit: "px",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-2",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: -1.5,
                                yValue: null,
                                xUnit: "rem",
                                yUnit: "px",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-3",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: -2.5,
                                yValue: null,
                                xUnit: "vw",
                                yUnit: "px",
                                zUnit: "PX"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-85-n-4",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 6,
                                yValue: null,
                                xUnit: "rem",
                                yUnit: "%",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-5",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 2.5,
                                yValue: null,
                                xUnit: "vw",
                                yUnit: "%",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-6",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: 1.5,
                                yValue: null,
                                xUnit: "rem",
                                yUnit: "%",
                                zUnit: "PX"
                            }
                        }]
                    }]
                }, {
                    id: "a-85-p-2",
                    type: "MOUSE_Y",
                    parameterLabel: "Mouse Y",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-85-n-7",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: null,
                                yValue: -6,
                                xUnit: "rem",
                                yUnit: "rem",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-8",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: null,
                                yValue: -1,
                                xUnit: "rem",
                                yUnit: "rem",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-9",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: null,
                                yValue: -2.5,
                                xUnit: "rem",
                                yUnit: "rem",
                                zUnit: "PX"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-85-n-10",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: null,
                                yValue: 6,
                                xUnit: "rem",
                                yUnit: "rem",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-11",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: null,
                                yValue: 2.5,
                                xUnit: "rem",
                                yUnit: "rem",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-85-n-12",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                xValue: null,
                                yValue: 1,
                                xUnit: "rem",
                                yUnit: "rem",
                                zUnit: "PX"
                            }
                        }]
                    }]
                }],
                createdOn: 1702431808885
            },
            "a-100": {
                id: "a-100",
                title: "Orb move 3",
                continuousParameterGroups: [{
                    id: "a-100-p",
                    type: "MOUSE_X",
                    parameterLabel: "Mouse X",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-100-n",
                            actionTypeId: "PLUGIN_SPLINE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: {
                                    rotationX: null,
                                    rotationY: -1
                                }
                            }
                        }, {
                            id: "a-100-n-2",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-background",
                                    selectorGuids: ["522945a5-6f62-6e3a-4457-210de173d2ee"]
                                },
                                xValue: -.5,
                                xUnit: "%",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-100-n-3",
                            actionTypeId: "TRANSFORM_SCALE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-background",
                                    selectorGuids: ["522945a5-6f62-6e3a-4457-210de173d2ee"]
                                },
                                xValue: 1.01,
                                yValue: 1.01,
                                locked: !0
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-100-n-4",
                            actionTypeId: "PLUGIN_SPLINE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: {
                                    rotationX: null,
                                    rotationY: 1
                                }
                            }
                        }, {
                            id: "a-100-n-5",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-background",
                                    selectorGuids: ["522945a5-6f62-6e3a-4457-210de173d2ee"]
                                },
                                xValue: .5,
                                xUnit: "%",
                                yUnit: "PX",
                                zUnit: "PX"
                            }
                        }, {
                            id: "a-100-n-6",
                            actionTypeId: "TRANSFORM_SCALE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-background",
                                    selectorGuids: ["522945a5-6f62-6e3a-4457-210de173d2ee"]
                                },
                                xValue: 1.01,
                                yValue: 1.01,
                                locked: !0
                            }
                        }]
                    }]
                }, {
                    id: "a-100-p-2",
                    type: "MOUSE_Y",
                    parameterLabel: "Mouse Y",
                    continuousActionGroups: [{
                        keyframe: 0,
                        actionItems: [{
                            id: "a-100-n-7",
                            actionTypeId: "PLUGIN_SPLINE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: {
                                    rotationX: -.5,
                                    rotationY: null
                                }
                            }
                        }, {
                            id: "a-100-n-8",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-background",
                                    selectorGuids: ["522945a5-6f62-6e3a-4457-210de173d2ee"]
                                },
                                xValue: null,
                                yValue: -1,
                                xUnit: "vw",
                                yUnit: "%",
                                zUnit: "PX"
                            }
                        }]
                    }, {
                        keyframe: 100,
                        actionItems: [{
                            id: "a-100-n-9",
                            actionTypeId: "PLUGIN_SPLINE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {},
                                value: {
                                    rotationX: .5,
                                    rotationY: null
                                }
                            }
                        }, {
                            id: "a-100-n-10",
                            actionTypeId: "TRANSFORM_MOVE",
                            config: {
                                delay: 0,
                                easing: "",
                                duration: 500,
                                target: {
                                    useEventTarget: "CHILDREN",
                                    selector: ".hero-background",
                                    selectorGuids: ["522945a5-6f62-6e3a-4457-210de173d2ee"]
                                },
                                xValue: null,
                                yValue: 1,
                                xUnit: "vw",
                                yUnit: "%",
                                zUnit: "PX"
                            }
                        }]
                    }]
                }],
                createdOn: 1720638735168
            },
            "a-147": {
                id: "a-147",
                title: "Quote Slider In View 2",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-147-n",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".quote-card",
                                selectorGuids: ["7cbac9ff-2319-d9a6-d316-3bc2b6f7ec96"]
                            },
                            xValue: 1,
                            yValue: 1,
                            locked: !0
                        }
                    }, {
                        id: "a-147-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".quote-text-wrapper",
                                selectorGuids: ["7cbac9ff-2319-d9a6-d316-3bc2b6f7ec99"]
                            },
                            value: 1,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1608421228415
            },
            "a-148": {
                id: "a-148",
                title: "Quote Slider Out View 2",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-148-n",
                        actionTypeId: "TRANSFORM_SCALE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".quote-card",
                                selectorGuids: ["7cbac9ff-2319-d9a6-d316-3bc2b6f7ec96"]
                            },
                            xValue: .9,
                            yValue: .9,
                            locked: !0
                        }
                    }, {
                        id: "a-148-n-2",
                        actionTypeId: "STYLE_OPACITY",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".quote-text-wrapper",
                                selectorGuids: ["7cbac9ff-2319-d9a6-d316-3bc2b6f7ec99"]
                            },
                            value: 0,
                            unit: ""
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1608421228415
            },
            "a-149": {
                id: "a-149",
                title: "Logos Loop on Load",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-149-n",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 0,
                            target: {
                                selector: ".scrolling-logo-container",
                                selectorGuids: ["1aeff7a4-1ad6-33f5-f12d-eaa44e8b21f9"]
                            },
                            xValue: 0,
                            xUnit: "%",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }]
                }, {
                    actionItems: [{
                        id: "a-149-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "",
                            duration: 3e4,
                            target: {
                                selector: ".scrolling-logo-container",
                                selectorGuids: ["1aeff7a4-1ad6-33f5-f12d-eaa44e8b21f9"]
                            },
                            xValue: -100,
                            xUnit: "%",
                            yUnit: "PX",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1728314112121
            },
            "a-150": {
                id: "a-150",
                title: "Project Card Hover On",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-150-n",
                        actionTypeId: "STYLE_TEXT_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".project-heading",
                                selectorGuids: ["94b7560f-e48b-7412-8457-6c71953fd164"]
                            },
                            globalSwatchId: "--theme--primary-color",
                            rValue: 226,
                            bValue: 118,
                            gValue: 195,
                            aValue: 1
                        }
                    }, {
                        id: "a-150-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be92e|e3b997b0-db7d-742f-bd6e-26281dcb2ea6"
                            },
                            yValue: -.5,
                            xUnit: "PX",
                            yUnit: "rem",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1728359094038
            },
            "a-151": {
                id: "a-151",
                title: "Project Card Hover Off",
                actionItemGroups: [{
                    actionItems: [{
                        id: "a-151-n",
                        actionTypeId: "STYLE_TEXT_COLOR",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: "CHILDREN",
                                selector: ".project-heading",
                                selectorGuids: ["94b7560f-e48b-7412-8457-6c71953fd164"]
                            },
                            globalSwatchId: "--white",
                            rValue: 255,
                            bValue: 255,
                            gValue: 255,
                            aValue: 1
                        }
                    }, {
                        id: "a-151-n-2",
                        actionTypeId: "TRANSFORM_MOVE",
                        config: {
                            delay: 0,
                            easing: "ease",
                            duration: 500,
                            target: {
                                useEventTarget: !0,
                                id: "678002b05def6cc3379be92e|e3b997b0-db7d-742f-bd6e-26281dcb2ea6"
                            },
                            yValue: 0,
                            xUnit: "PX",
                            yUnit: "rem",
                            zUnit: "PX"
                        }
                    }]
                }],
                useFirstGroupAsInitialState: !1,
                createdOn: 1728359094038
            }
        },
        site: {
            mediaQueries: [{
                key: "main",
                min: 992,
                max: 1e4
            }, {
                key: "medium",
                min: 768,
                max: 991
            }, {
                key: "small",
                min: 480,
                max: 767
            }, {
                key: "tiny",
                min: 0,
                max: 479
            }]
        }
    });
})();
/*!
 * tram.js v0.8.2-global
 * Cross-browser CSS3 transitions in JavaScript
 * https://github.com/bkwld/tram
 * MIT License
 */
/*!
 * Webflow._ (aka) Underscore.js 1.6.0 (custom build)
 *
 * http://underscorejs.org
 * (c) 2009-2013 Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 * Underscore may be freely distributed under the MIT license.
 * @license MIT
 */
/*! Bundled license information:

timm/lib/timm.js:
  (*!
   * Timm
   *
   * Immutability helpers with fast reads and acceptable writes.
   *
   * @copyright Guillermo Grau Panea 2016
   * @license MIT
   *)
*/